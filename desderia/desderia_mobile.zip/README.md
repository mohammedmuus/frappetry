# Desderia mobile app (Flutter, Android and iOS)

The customer app for Desderia Bureau De Change. Same ink, gold and ivory glass design as the website, built on the same server API. Customers sign in with email plus a one time code, request exchanges at live rates, negotiate, pay, receive, chat with the desk, upload identity documents and follow every step.

How the app talks to the server is documented in `API.md` inside the web project. How the business runs on both apps is in `OPERATIONS.md` there.

## Run it

Requires Flutter 3.35 or newer (built and analysed with Flutter 3.47, Dart 3.13).

```bash
flutter pub get
# Android emulator, local Django server on your laptop:
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:8000/api/v1
# iOS simulator:
flutter run --dart-define=API_BASE_URL=http://127.0.0.1:8000/api/v1
```

Start the server with `python manage.py runserver 0.0.0.0:8000` and seed it with `python manage.py seed_desderia --demo`. Sign in codes print in the server terminal during development.

## Release builds

```bash
flutter build appbundle --release --dart-define=API_BASE_URL=https://desderia.co.tz/api/v1
flutter build ipa --release --dart-define=API_BASE_URL=https://desderia.co.tz/api/v1
```

- Release builds refuse a non https server address.
- Android: set up signing in `android/key.properties` as described in the Flutter docs before publishing. Package id `tz.co.desderia.desderia`, min SDK 23.
- iOS: open `ios/Runner.xcworkspace` in Xcode, set your team and bundle id, deployment target iOS 15.
- App icons are generated from `assets/images/app_icon.png` with `dart run flutter_launcher_icons`.

## Structure

```
lib/
  main.dart, app.dart         start up, theme, sign in gate, background auto sign out
  config/env.dart             server address and timeouts (from --dart-define)
  theme/                      Desderia colours and Material theme
  core/
    api_client.dart           HTTPS JSON client, bearer token, timeouts, readable errors
    session.dart              who is signed in, two step login, verification, sign out
    secure_store.dart         token in iOS Keychain or Android Keystore
    models.dart, format.dart  API data classes, money and date formatting
  widgets/                    glass background and cards, buttons, fields, status pills
  screens/
    auth/                     welcome, sign in, one time code, register, verify, forgot password
    home/                     tab shell and dashboard (recent requests, live rates)
    exchange/                 new request with live quote, request list, request detail
    beneficiaries/            saved payout accounts
    chat/                     conversations and live chat
    account/                  account, KYC upload, notifications
```

## Security in the app

- Token stored only in the platform secure storage, never in plain preferences.
- Signs out automatically after 15 minutes in the background.
- Android: `FLAG_SECURE` blocks screenshots, screen recording and recent apps previews; cleartext traffic is disabled (debug builds allow only the local emulator host); app data backup is off.
- A 401 from the server clears the session and returns to sign in.
- Every money action button locks while the call runs. New requests carry an idempotency key and chat messages a client id, so retries never create duplicates.
- Optional hardening for later: certificate pinning, biometric unlock (`local_auth`), jailbreak and root detection.

## Checks

```bash
flutter analyze    # no issues
flutter test       # model and formatting tests
```

Screenshots of the main screens are in `docs/screenshots/`.
