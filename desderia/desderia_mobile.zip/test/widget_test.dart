import 'package:desderia/core/format.dart';
import 'package:desderia/core/models.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('money formatting keeps two decimals and the code', () {
    expect(money('2615000', 'TZS'), 'TZS 2,615,000.00');
    expect(money(12.5), '12.50');
  });

  test('request detail parses server json', () {
    final r = RequestDetail({
      'reference': 'DSD-ABCD2345',
      'direction': 'buy',
      'currency': 'USD',
      'foreign_amount': '1000.00',
      'effective_rate': '2615.0000',
      'local_amount': '2615000.00',
      'status': 'approved',
      'board_rate': '2615.0000',
      'funding_method': 'bank_transfer',
      'payout_method': 'cash_pickup',
      'pay_amount': {'amount': '2615000.00', 'currency': 'TZS'},
      'receive_amount': {'amount': '1000.00', 'currency': 'USD'},
      'offers': [],
      'events': [],
    });
    expect(r.isOpen, isTrue);
    expect(r.cancellable, isTrue);
    expect(r.pay['currency'], 'TZS');
  });
}
