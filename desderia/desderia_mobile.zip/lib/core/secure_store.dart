import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Token storage in the iOS Keychain and Android Keystore backed storage.
/// Nothing sensitive is ever written to shared preferences or files.
class SecureStore {
  static const _storage = FlutterSecureStorage(
    // Version 11 encrypts with keys held in the Android Keystore by default.
    aOptions: AndroidOptions(),
    iOptions: IOSOptions(accessibility: KeychainAccessibility.first_unlock_this_device),
  );
  static const _tokenKey = 'dsd_token';

  Future<String?> readToken() => _storage.read(key: _tokenKey);
  Future<void> writeToken(String token) => _storage.write(key: _tokenKey, value: token);
  Future<void> clear() => _storage.delete(key: _tokenKey);
}
