// Plain data classes mirroring the API JSON. Money stays as strings from the
// server and is parsed only for display, so no rounding happens on device.

class AppUser {
  AppUser(this.json);
  final Map<String, dynamic> json;
  String get id => json['id'] as String;
  String get email => json['email'] as String? ?? '';
  String get phone => json['phone'] as String? ?? '';
  String get fullName => json['full_name'] as String? ?? '';
  String get firstName => fullName.split(' ').first;
  String get role => json['role'] as String? ?? 'customer';
  bool get emailVerified => json['email_verified'] == true;
  bool get phoneVerified => json['phone_verified'] == true;
  bool get fullyVerified => emailVerified && phoneVerified;
  bool get notifyEmail => json['notify_email'] == true;
  String get kycStatus => json['kyc_status'] as String? ?? 'not_submitted';
  int get unread => json['unread_notifications'] as int? ?? 0;
}

class Rate {
  Rate(this.json);
  final Map<String, dynamic> json;
  String get code => json['code'] as String;
  String get name => json['name'] as String? ?? '';
  String get buy => json['buy'] as String;
  String get sell => json['sell'] as String;
  String get updated => json['updated'] as String? ?? '';
  String get minNegotiable => json['min_negotiable'] as String? ?? '0';
}

class RequestSummary {
  RequestSummary(this.json);
  final Map<String, dynamic> json;
  String get reference => json['reference'] as String;
  String get direction => json['direction'] as String;
  String get directionLabel => json['direction_label'] as String? ?? '';
  String get currency => json['currency'] as String;
  String get foreignAmount => json['foreign_amount'] as String;
  String get effectiveRate => json['effective_rate'] as String;
  String get localAmount => json['local_amount'] as String;
  String get status => json['status'] as String;
  String get statusLabel => json['status_label'] as String? ?? status;
  String get tone => json['status_tone'] as String? ?? 'muted';
  String get createdAt => json['created_at'] as String? ?? '';
}

class Offer {
  Offer(this.json);
  final Map<String, dynamic> json;
  String get id => json['id'] as String;
  String get side => json['side'] as String;
  String get rate => json['rate'] as String;
  String get message => json['message'] as String? ?? '';
  String get status => json['status'] as String;
  String get createdAt => json['created_at'] as String? ?? '';
}

class TimelineEvent {
  TimelineEvent(this.json);
  final Map<String, dynamic> json;
  String get label => json['label'] as String? ?? '';
  String get note => json['note'] as String? ?? '';
  String get at => json['at'] as String? ?? '';
}

class RequestDetail extends RequestSummary {
  RequestDetail(super.json);
  String? get agreedRate => json['agreed_rate'] as String?;
  String get boardRate => json['board_rate'] as String;
  String get quoteExpiresAt => json['quote_expires_at'] as String? ?? '';
  String get fundingMethod => json['funding_method'] as String;
  String get payoutMethod => json['payout_method'] as String;
  String get purpose => json['purpose'] as String? ?? '';
  String? get fundingDeadline => json['funding_deadline'] as String?;
  String get fundingReference => json['funding_reference'] as String? ?? '';
  String get payoutReference => json['payout_reference'] as String? ?? '';
  String get closedReason => json['closed_reason'] as String? ?? '';
  Map<String, dynamic> get pay => Map<String, dynamic>.from(json['pay_amount'] as Map);
  Map<String, dynamic> get receive => Map<String, dynamic>.from(json['receive_amount'] as Map);
  String? get conversationId => json['conversation_id'] as String?;
  Map<String, dynamic>? get payment => json['payment'] == null ? null : Map<String, dynamic>.from(json['payment'] as Map);
  Map<String, dynamic>? get bank => json['bank_details'] == null ? null : Map<String, dynamic>.from(json['bank_details'] as Map);
  Map<String, dynamic>? get beneficiary =>
      json['beneficiary'] == null ? null : Map<String, dynamic>.from(json['beneficiary'] as Map);
  bool get canNegotiate => json['can_negotiate'] == true;
  List<Offer> get offers => (json['offers'] as List? ?? []).map((e) => Offer(Map<String, dynamic>.from(e as Map))).toList();
  List<TimelineEvent> get events =>
      (json['events'] as List? ?? []).map((e) => TimelineEvent(Map<String, dynamic>.from(e as Map))).toList();
  bool get isOpen => const ['submitted', 'negotiating', 'approved', 'funded', 'paid_out'].contains(status);
  bool get cancellable => const ['submitted', 'negotiating', 'approved'].contains(status);
}

class Beneficiary {
  Beneficiary(this.json);
  final Map<String, dynamic> json;
  String get id => json['id'] as String;
  String get kind => json['kind'] as String;
  String get label => json['label'] as String;
  String get currency => json['currency'] as String;
  String get display => json['display'] as String? ?? label;
  String get accountName => json['account_name'] as String? ?? '';
}

class Conversation {
  Conversation(this.json);
  final Map<String, dynamic> json;
  String get id => json['id'] as String;
  String get subject => json['subject'] as String? ?? '';
  String get status => json['status'] as String? ?? 'open';
  int get unread => json['unread'] as int? ?? 0;
  String? get reference => json['reference'] as String?;
  String get lastMessageAt => json['last_message_at'] as String? ?? '';
}

class ChatMessage {
  ChatMessage(this.json);
  final Map<String, dynamic> json;
  String get id => json['id'] as String;
  String get kind => json['kind'] as String? ?? 'text';
  String get body => json['body'] as String? ?? '';
  bool get mine => json['mine'] == true;
  String get sender => json['sender'] as String? ?? '';
  String get at => json['at'] as String? ?? '';
}

class AppNotification {
  AppNotification(this.json);
  final Map<String, dynamic> json;
  String get title => json['title'] as String? ?? '';
  String get body => json['body'] as String? ?? '';
  String get link => json['link'] as String? ?? '';
  bool get read => json['read_at'] != null;
  String get createdAt => json['created_at'] as String? ?? '';
}

/// Reference data from /options/ used to build forms.
class Options {
  Options(this.json);
  final Map<String, dynamic> json;
  List<Map<String, dynamic>> get currencies =>
      (json['currencies'] as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  String get base => json['base'] as String? ?? 'TZS';
  List<String> funding(String direction) => List<String>.from((json['funding'] as Map)[direction] as List);
  List<String> payout(String direction) => List<String>.from((json['payout'] as Map)[direction] as List);
  String fundingLabel(String key) => (json['funding_labels'] as Map)[key]?.toString() ?? key;
  String payoutLabel(String key) => (json['payout_labels'] as Map)[key]?.toString() ?? key;
  List<List<String>> _pairs(String key) =>
      (json[key] as List).map((e) => (e as List).map((x) => x.toString()).toList()).toList();
  List<List<String>> get purposes => _pairs('purposes');
  List<List<String>> get networks => _pairs('networks');
  List<List<String>> get idTypes => _pairs('id_types');
  int get kycLimitUsd => json['kyc_limit_usd'] as int? ?? 1000;
}
