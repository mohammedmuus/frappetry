import 'package:intl/intl.dart';

final _money = NumberFormat('#,##0.00', 'en_US');
final _whole = NumberFormat('#,##0', 'en_US');
final _date = DateFormat('d MMM yyyy, HH:mm');
final _short = DateFormat('d MMM');
final _time = DateFormat('HH:mm');

String money(dynamic v, [String? code]) {
  final n = v is num ? v : double.tryParse('$v') ?? 0;
  return code == null ? _money.format(n) : '$code ${_money.format(n)}';
}

String whole(dynamic v) => _whole.format(v is num ? v : double.tryParse('$v') ?? 0);

DateTime? parseDate(dynamic v) => v == null ? null : DateTime.tryParse('$v')?.toLocal();

String dateTime(dynamic v) {
  final d = parseDate(v);
  return d == null ? '' : _date.format(d);
}

String shortDate(dynamic v) {
  final d = parseDate(v);
  return d == null ? '' : _short.format(d);
}

String clock(dynamic v) {
  final d = parseDate(v);
  return d == null ? '' : _time.format(d);
}
