import 'package:flutter/foundation.dart';

import 'api_client.dart';
import 'models.dart';
import 'secure_store.dart';

enum AuthState { unknown, signedOut, needsVerification, signedIn }

/// Single source of truth for who is signed in. Screens listen to it.
class Session extends ChangeNotifier {
  Session(this.api, this.store) {
    api.onUnauthorised = _expired;
  }

  final ApiClient api;
  final SecureStore store;
  AuthState state = AuthState.unknown;
  AppUser? user;
  Options? options;
  String? pendingChallenge;
  String pendingChannel = 'email';

  Future<void> restore() async {
    final token = await store.readToken();
    if (token == null) {
      _set(AuthState.signedOut);
      return;
    }
    api.token = token;
    try {
      await refreshUser();
    } on ApiException catch (e) {
      if (e.isUnauthorised) return;
      // Offline at launch: keep the session and let screens retry.
      _set(AuthState.signedIn);
    }
  }

  Future<void> refreshUser() async {
    final data = await api.get('me/') as Map<String, dynamic>;
    user = AppUser(data);
    _set(user!.fullyVerified ? AuthState.signedIn : AuthState.needsVerification);
  }

  Future<Options> loadOptions() async {
    if (options != null) return options!;
    options = Options(await api.get('options/') as Map<String, dynamic>);
    return options!;
  }

  /// Step one. Returns true when a one time code was sent.
  Future<bool> login(String email, String password, {String channel = 'email'}) async {
    final data = await api.post('auth/login/', {
      'email': email.trim(),
      'password': password,
      'channel': channel,
      'device_name': _deviceName(),
    }) as Map<String, dynamic>;
    if (data['otp_required'] == true) {
      pendingChallenge = data['challenge'] as String;
      pendingChannel = data['channel'] as String? ?? 'email';
      return true;
    }
    await _accept(data);
    return false;
  }

  Future<void> verifyLogin(String code) async {
    final data = await api.post('auth/login/verify/', {
      'challenge': pendingChallenge,
      'code': code.trim(),
      'device_name': _deviceName(),
    }) as Map<String, dynamic>;
    pendingChallenge = null;
    await _accept(data);
  }

  Future<void> resendLoginCode() => api.post('auth/login/resend/', {'challenge': pendingChallenge});

  Future<void> register(Map<String, dynamic> body) async {
    final data = await api.post('auth/register/', {...body, 'device_name': _deviceName()}) as Map<String, dynamic>;
    await _accept(data);
  }

  Future<void> verifyChannel(String which, String code) async {
    final data = await api.post('auth/verify/', {'which': which, 'code': code.trim()}) as Map<String, dynamic>;
    user = AppUser(Map<String, dynamic>.from(data['user'] as Map));
    _set(user!.fullyVerified ? AuthState.signedIn : AuthState.needsVerification);
  }

  Future<void> resendChannel(String which) => api.post('auth/verify/', {'which': which, 'resend': true});

  Future<void> logout() async {
    try {
      await api.post('auth/logout/');
    } on ApiException {
      // Signing out locally still happens even if the server is unreachable.
    }
    await _clear();
  }

  Future<void> _accept(Map<String, dynamic> data) async {
    final token = data['token'] as String;
    api.token = token;
    await store.writeToken(token);
    user = AppUser(Map<String, dynamic>.from(data['user'] as Map));
    _set(user!.fullyVerified ? AuthState.signedIn : AuthState.needsVerification);
  }

  void _expired() {
    if (state == AuthState.signedIn || state == AuthState.needsVerification || state == AuthState.unknown) {
      _clear();
    }
  }

  Future<void> _clear() async {
    api.token = null;
    user = null;
    options = null;
    await store.clear();
    _set(AuthState.signedOut);
  }

  void _set(AuthState s) {
    state = s;
    notifyListeners();
  }

  String _deviceName() {
    switch (defaultTargetPlatform) {
      case TargetPlatform.iOS:
        return 'iPhone app';
      case TargetPlatform.android:
        return 'Android app';
      default:
        return 'Mobile app';
    }
  }
}
