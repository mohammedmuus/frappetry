import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import '../config/env.dart';

/// Raised for any failed call. [message] is safe to show to the customer.
class ApiException implements Exception {
  ApiException(this.message, {this.status = 0, this.retryAfter});
  final String message;
  final int status;
  final int? retryAfter;

  bool get isUnauthorised => status == 401;

  @override
  String toString() => message;
}

/// Thin JSON client for the Desderia REST API (see API.md in the web project).
///
/// - Bearer token on every call once signed in
/// - 20 second timeout, one quiet retry for idempotent GETs
/// - server messages surfaced as [ApiException.message]
/// - a 401 calls [onUnauthorised] so the app returns to sign in
class ApiClient {
  ApiClient({http.Client? client}) : _http = client ?? http.Client();

  final http.Client _http;
  String? token;
  void Function()? onUnauthorised;

  Uri _uri(String path, [Map<String, String>? query]) {
    final base = Env.apiBaseUrl.endsWith('/') ? Env.apiBaseUrl : '${Env.apiBaseUrl}/';
    final clean = path.startsWith('/') ? path.substring(1) : path;
    return Uri.parse(base + clean).replace(queryParameters: query);
  }

  Map<String, String> get _headers => {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'X-Client': 'desderia-mobile/1.0',
        if (token != null) 'Authorization': 'Bearer $token',
      };

  Future<dynamic> get(String path, {Map<String, String>? query}) async {
    try {
      return await _send(() => _http.get(_uri(path, query), headers: _headers));
    } on ApiException catch (e) {
      if (e.status == 0) {
        // Network blip: GET is safe to repeat once.
        return _send(() => _http.get(_uri(path, query), headers: _headers));
      }
      rethrow;
    }
  }

  Future<dynamic> post(String path, [Map<String, dynamic>? body]) =>
      _send(() => _http.post(_uri(path), headers: _headers, body: jsonEncode(body ?? {})));

  Future<dynamic> patch(String path, Map<String, dynamic> body) =>
      _send(() => _http.patch(_uri(path), headers: _headers, body: jsonEncode(body)));

  Future<dynamic> delete(String path) => _send(() => _http.delete(_uri(path), headers: _headers));

  /// Multipart upload (KYC document photo).
  Future<dynamic> upload(String path, Map<String, String> fields, String fileField, File file) {
    return _send(() async {
      final req = http.MultipartRequest('POST', _uri(path))
        ..headers.addAll({
          'Accept': 'application/json',
          if (token != null) 'Authorization': 'Bearer $token',
        })
        ..fields.addAll(fields)
        ..files.add(await http.MultipartFile.fromPath(fileField, file.path));
      final streamed = await req.send();
      return http.Response.fromStream(streamed);
    });
  }

  Future<dynamic> _send(Future<http.Response> Function() call) async {
    http.Response res;
    try {
      res = await call().timeout(Env.requestTimeout);
    } on TimeoutException {
      throw ApiException('The server took too long to answer. Check your connection and try again.');
    } on SocketException {
      throw ApiException('No internet connection.');
    } on HttpException {
      throw ApiException('Connection problem. Please try again.');
    }
    dynamic data;
    if (res.body.isNotEmpty) {
      try {
        data = jsonDecode(utf8.decode(res.bodyBytes));
      } on FormatException {
        data = null;
      }
    }
    if (res.statusCode >= 200 && res.statusCode < 300) {
      return data;
    }
    if (res.statusCode == 401) {
      onUnauthorised?.call();
    }
    String message = 'Something went wrong (${res.statusCode}).';
    int? retry;
    if (data is Map) {
      if (data['detail'] is String) {
        message = data['detail'] as String;
      } else if (data.isNotEmpty) {
        final first = data.values.first;
        if (first is List && first.isNotEmpty) message = first.first.toString();
        if (first is String) message = first;
      }
      if (data['retry_after'] is int) retry = data['retry_after'] as int;
    }
    if (res.statusCode == 429 && message.startsWith('Something')) {
      message = 'Too many attempts. Please wait a moment.';
    }
    throw ApiException(message, status: res.statusCode, retryAfter: retry);
  }
}
