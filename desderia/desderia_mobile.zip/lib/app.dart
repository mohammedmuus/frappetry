import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'config/env.dart';
import 'core/session.dart';
import 'screens/auth/verify_screen.dart';
import 'screens/auth/welcome_screen.dart';
import 'screens/home/home_shell.dart';
import 'theme/colors.dart';
import 'theme/theme.dart';
import 'widgets/common.dart';
import 'widgets/glass.dart';

class DesderiaApp extends StatefulWidget {
  const DesderiaApp({super.key});

  @override
  State<DesderiaApp> createState() => _DesderiaAppState();
}

class _DesderiaAppState extends State<DesderiaApp> with WidgetsBindingObserver {
  DateTime? _pausedAt;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  /// Sign out after a long time in the background, so a lost phone left
  /// unlocked does not stay inside the account.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _pausedAt = DateTime.now();
    } else if (state == AppLifecycleState.resumed && _pausedAt != null) {
      if (DateTime.now().difference(_pausedAt!) > Env.backgroundLock) {
        context.read<Session>().logout();
      }
      _pausedAt = null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Desderia',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      builder: (context, child) => MediaQuery(
        // Keep text scaling readable but stop layouts breaking at huge sizes.
        data: MediaQuery.of(context).copyWith(
          textScaler: MediaQuery.of(context).textScaler.clamp(minScaleFactor: .9, maxScaleFactor: 1.3),
        ),
        child: child!,
      ),
      home: const _Gate(),
    );
  }
}

class _Gate extends StatelessWidget {
  const _Gate();

  @override
  Widget build(BuildContext context) {
    final state = context.watch<Session>().state;
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 250),
      child: switch (state) {
        AuthState.unknown => const _Splash(),
        AuthState.signedOut => const WelcomeScreen(),
        AuthState.needsVerification => const VerifyScreen(),
        AuthState.signedIn => const HomeShell(),
      },
    );
  }
}

class _Splash extends StatelessWidget {
  const _Splash();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: GlassBackground(
        child: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Brand(size: 56),
            SizedBox(height: 24),
            SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: DsdColors.gold)),
          ]),
        ),
      ),
    );
  }
}
