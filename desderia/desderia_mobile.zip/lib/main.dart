import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'config/env.dart';
import 'core/api_client.dart';
import 'core/secure_store.dart';
import 'core/session.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  Env.assertSecure();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    statusBarBrightness: Brightness.dark,
    systemNavigationBarColor: Color(0xFF0C1014),
  ));
  final session = Session(ApiClient(), SecureStore())..restore();
  runApp(ChangeNotifierProvider.value(value: session, child: const DesderiaApp()));
}
