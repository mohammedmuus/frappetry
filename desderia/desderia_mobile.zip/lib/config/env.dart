/// Build time configuration. Pass values with --dart-define, for example:
///   flutter run --dart-define=API_BASE_URL=https://desderia.co.tz/api/v1
/// Release builds refuse plain http so tokens never travel unencrypted.
class Env {
  static const String apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2:8000/api/v1',
  );

  static const Duration requestTimeout = Duration(seconds: 20);

  /// Signed out automatically after this long in the background.
  static const Duration backgroundLock = Duration(minutes: 15);

  static const bool isRelease = bool.fromEnvironment('dart.vm.product');

  static void assertSecure() {
    if (isRelease && !apiBaseUrl.startsWith('https://')) {
      throw StateError('Release builds must use an https API_BASE_URL');
    }
  }
}
