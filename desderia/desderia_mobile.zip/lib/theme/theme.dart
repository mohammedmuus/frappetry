import 'package:flutter/material.dart';

import 'colors.dart';

ThemeData buildTheme() {
  const scheme = ColorScheme.dark(
    primary: DsdColors.gold,
    onPrimary: DsdColors.ink,
    secondary: DsdColors.gold2,
    onSecondary: DsdColors.ink,
    surface: DsdColors.ink2,
    onSurface: DsdColors.text,
    error: DsdColors.bad,
    onError: DsdColors.ink,
  );
  final base = ThemeData(useMaterial3: true, colorScheme: scheme, brightness: Brightness.dark);
  final text = base.textTheme.apply(bodyColor: DsdColors.text, displayColor: DsdColors.ivory);
  OutlineInputBorder border(Color c) => OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: c),
      );
  return base.copyWith(
    scaffoldBackgroundColor: DsdColors.ink,
    textTheme: text.copyWith(
      headlineSmall: text.headlineSmall?.copyWith(fontSize: 22, fontWeight: FontWeight.w700, color: DsdColors.ivory),
      titleLarge: text.titleLarge?.copyWith(fontSize: 18, fontWeight: FontWeight.w700, color: DsdColors.ivory),
      titleMedium: text.titleMedium?.copyWith(fontSize: 15, fontWeight: FontWeight.w600, color: DsdColors.ivory),
      bodyMedium: text.bodyMedium?.copyWith(fontSize: 14, color: DsdColors.text),
      bodySmall: text.bodySmall?.copyWith(fontSize: 12, color: DsdColors.muted),
      labelLarge: text.labelLarge?.copyWith(fontSize: 14, fontWeight: FontWeight.w600),
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      foregroundColor: DsdColors.ivory,
      titleTextStyle: text.titleLarge?.copyWith(fontSize: 17, fontWeight: FontWeight.w700, color: DsdColors.ivory),
    ),
    inputDecorationTheme: InputDecorationTheme(
      isDense: true,
      filled: true,
      fillColor: DsdColors.field,
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      labelStyle: text.bodyMedium?.copyWith(color: DsdColors.muted, fontSize: 13),
      hintStyle: text.bodyMedium?.copyWith(color: DsdColors.faint, fontSize: 14),
      border: border(DsdColors.line2),
      enabledBorder: border(DsdColors.line2),
      focusedBorder: border(DsdColors.gold3),
      errorBorder: border(DsdColors.bad),
      focusedErrorBorder: border(DsdColors.bad),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: DsdColors.gold,
        foregroundColor: DsdColors.ink,
        minimumSize: const Size(0, 44),
        textStyle: text.labelLarge?.copyWith(fontSize: 14, fontWeight: FontWeight.w700),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: DsdColors.ivory,
        minimumSize: const Size(0, 44),
        side: const BorderSide(color: DsdColors.line),
        textStyle: text.labelLarge?.copyWith(fontSize: 14, fontWeight: FontWeight.w600),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(foregroundColor: DsdColors.gold2, textStyle: text.labelLarge?.copyWith(fontWeight: FontWeight.w600)),
    ),
    snackBarTheme: SnackBarThemeData(
      backgroundColor: DsdColors.ink3,
      contentTextStyle: text.bodyMedium?.copyWith(color: DsdColors.ivory),
      behavior: SnackBarBehavior.floating,
    ),
    dividerTheme: const DividerThemeData(color: DsdColors.line2, thickness: 1, space: 1),
    iconTheme: const IconThemeData(size: 20, color: DsdColors.muted),
    progressIndicatorTheme: const ProgressIndicatorThemeData(color: DsdColors.gold),
  );
}
