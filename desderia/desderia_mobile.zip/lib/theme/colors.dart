import 'package:flutter/material.dart';

/// Palette taken from the Desderia logo: ink, gold and ivory.
class DsdColors {
  static const ink = Color(0xFF0C1014);
  static const ink2 = Color(0xFF11161C);
  static const ink3 = Color(0xFF171D24);
  static const gold = Color(0xFFACA578);
  static const gold2 = Color(0xFFC9BD8C);
  static const gold3 = Color(0xFF857D52);
  static const ivory = Color(0xFFF4F1E6);
  static const text = Color(0xFFE9E6DA);
  static const muted = Color(0xFF9B998D);
  static const faint = Color(0xFF6C6B63);
  static const line = Color(0x29C9BD8C);
  static const line2 = Color(0x12FFFFFF);
  static const glass = Color(0x0AFFFFFF);
  static const glass2 = Color(0x12FFFFFF);
  static const glassGold = Color(0x1AACA578);
  static const field = Color(0x40000000);
  static const good = Color(0xFF79C79A);
  static const bad = Color(0xFFE58A7F);
  static const info = Color(0xFF93B6DC);
  static const pending = Color(0xFFDCBC6C);
}
