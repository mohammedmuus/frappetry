import 'package:flutter/material.dart';

import '../core/api_client.dart';
import '../theme/colors.dart';

class Brand extends StatelessWidget {
  const Brand({super.key, this.size = 34, this.showSub = true});
  final double size;
  final bool showSub;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        ClipOval(child: Image.asset(size > 48 ? 'assets/images/logo_round.png' : 'assets/images/logo_icon.png', width: size, height: size)),
        const SizedBox(width: 10),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            RichText(
              text: const TextSpan(
                style: TextStyle(fontFamily: 'Oswald', fontWeight: FontWeight.w600, fontSize: 18, letterSpacing: 1.4, color: DsdColors.gold, height: 1),
                children: [TextSpan(text: 'DE'), TextSpan(text: r'$', style: TextStyle(color: DsdColors.ivory)), TextSpan(text: 'DERIA')],
              ),
            ),
            if (showSub)
              const Padding(
                padding: EdgeInsets.only(top: 3),
                child: Text('BUREAU DE CHANGE', style: TextStyle(fontSize: 8.5, letterSpacing: 2.4, color: DsdColors.muted)),
              ),
          ],
        ),
      ],
    );
  }
}

/// Status pill with the same tones as the web app.
class StatusPill extends StatelessWidget {
  const StatusPill(this.label, {super.key, this.tone = 'muted'});
  final String label;
  final String tone;

  Color get _color => switch (tone) {
        'good' => DsdColors.good,
        'bad' => DsdColors.bad,
        'info' => DsdColors.info,
        'pending' => DsdColors.pending,
        _ => DsdColors.muted,
      };

  @override
  Widget build(BuildContext context) {
    final c = _color;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: Color.fromARGB(26, (c.r * 255).round(), (c.g * 255).round(), (c.b * 255).round()),
        borderRadius: BorderRadius.circular(99),
        border: Border.all(color: Color.fromARGB(51, (c.r * 255).round(), (c.g * 255).round(), (c.b * 255).round())),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 6, height: 6, decoration: BoxDecoration(color: c, shape: BoxShape.circle)),
        const SizedBox(width: 6),
        Flexible(
          child: Text(label,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: c, fontSize: 11, fontWeight: FontWeight.w600)),
        ),
      ]),
    );
  }
}

class CurrencyChip extends StatelessWidget {
  const CurrencyChip(this.code, {super.key});
  final String code;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 36,
      height: 36,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: DsdColors.glassGold,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: DsdColors.line),
      ),
      child: Text(code, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: DsdColors.gold2, letterSpacing: .4)),
    );
  }
}

class KeyValue extends StatelessWidget {
  const KeyValue(this.label, this.value, {super.key, this.mono = false});
  final String label;
  final String value;
  final bool mono;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(flex: 4, child: Text(label, style: const TextStyle(color: DsdColors.faint, fontSize: 13))),
        Expanded(
          flex: 6,
          child: Text(value,
              textAlign: TextAlign.right,
              style: TextStyle(
                  color: DsdColors.ivory,
                  fontSize: 13,
                  fontFamily: mono ? 'monospace' : null,
                  fontFeatures: const [FontFeature.tabularFigures()])),
        ),
      ]),
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState(this.text, {super.key, this.icon = Icons.inbox_outlined, this.action});
  final String text;
  final IconData icon;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 12),
      child: Column(children: [
        Icon(icon, size: 22, color: DsdColors.gold3),
        const SizedBox(height: 10),
        Text(text, textAlign: TextAlign.center, style: const TextStyle(color: DsdColors.muted)),
        if (action != null) ...[const SizedBox(height: 12), action!],
      ]),
    );
  }
}

class ErrorRetry extends StatelessWidget {
  const ErrorRetry(this.error, {super.key, required this.onRetry});
  final Object error;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return EmptyState(error is ApiException ? error.toString() : 'Something went wrong.',
        icon: Icons.wifi_off_rounded, action: OutlinedButton(onPressed: onRetry, child: const Text('Try again')));
  }
}

/// Primary button that shows a spinner and blocks double taps (no double entries).
class BusyButton extends StatelessWidget {
  const BusyButton({super.key, required this.label, required this.busy, required this.onPressed, this.icon, this.outlined = false});
  final String label;
  final bool busy;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool outlined;

  @override
  Widget build(BuildContext context) {
    final child = busy
        ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
        : Row(mainAxisSize: MainAxisSize.min, children: [
            if (icon != null) ...[Icon(icon, size: 18), const SizedBox(width: 8)],
            Flexible(child: Text(label, overflow: TextOverflow.ellipsis)),
          ]);
    final action = busy ? null : onPressed;
    return outlined ? OutlinedButton(onPressed: action, child: child) : FilledButton(onPressed: action, child: child);
  }
}

void toast(BuildContext context, String message) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message)));
}

String errorText(Object e) => e is ApiException ? e.message : 'Something went wrong. Please try again.';

/// Shared labelled text field with compact sizing.
class Field extends StatelessWidget {
  const Field({
    super.key,
    required this.controller,
    required this.label,
    this.hint,
    this.keyboard,
    this.obscure = false,
    this.validator,
    this.autofill,
    this.maxLength,
    this.maxLines = 1,
    this.textAlign = TextAlign.start,
    this.style,
    this.onChanged,
  });

  final TextEditingController controller;
  final String label;
  final String? hint;
  final TextInputType? keyboard;
  final bool obscure;
  final String? Function(String?)? validator;
  final Iterable<String>? autofill;
  final int? maxLength;
  final int maxLines;
  final TextAlign textAlign;
  final TextStyle? style;
  final ValueChanged<String>? onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: DsdColors.muted)),
        const SizedBox(height: 6),
        TextFormField(
          controller: controller,
          keyboardType: keyboard,
          obscureText: obscure,
          validator: validator,
          autofillHints: autofill,
          maxLength: maxLength,
          maxLines: maxLines,
          textAlign: textAlign,
          onChanged: onChanged,
          style: style ?? Theme.of(context).textTheme.bodyMedium?.copyWith(fontSize: 14, color: DsdColors.ivory),
          decoration: InputDecoration(hintText: hint, counterText: ''),
        ),
      ]),
    );
  }
}

class Dropdown<T> extends StatelessWidget {
  const Dropdown({super.key, required this.label, required this.value, required this.items, required this.onChanged});
  final String label;
  final T? value;
  final List<DropdownMenuItem<T>> items;
  final ValueChanged<T?> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: DsdColors.muted)),
        const SizedBox(height: 6),
        DropdownButtonFormField<T>(
          // Rebuild when the parent changes the value (dependent dropdowns).
          key: ValueKey<Object?>(value),
          initialValue: value,
          items: items,
          onChanged: onChanged,
          isExpanded: true,
          dropdownColor: DsdColors.ink3,
          iconEnabledColor: DsdColors.gold,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontSize: 14, color: DsdColors.ivory),
        ),
      ]),
    );
  }
}
