import 'dart:ui';

import 'package:flutter/material.dart';

import '../../theme/colors.dart';
import '../../widgets/glass.dart';
import '../account/account_screen.dart';
import '../chat/conversations_screen.dart';
import '../exchange/new_request_screen.dart';
import '../exchange/request_list_screen.dart';
import 'dashboard_screen.dart';

/// Signed in shell: four tabs plus a centre action, as in the web app.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  final _keys = List.generate(4, (_) => GlobalKey());

  void _go(int i) => setState(() => _index = i);

  Future<void> _newRequest() async {
    final ref = await Navigator.of(context).push<String>(MaterialPageRoute(builder: (_) => const NewRequestScreen()));
    if (ref != null && mounted) _go(1);
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardScreen(key: _keys[0], onNewRequest: _newRequest, onSeeRequests: () => _go(1)),
      RequestListScreen(key: _keys[1]),
      ConversationsScreen(key: _keys[2]),
      AccountScreen(key: _keys[3]),
    ];
    return Scaffold(
      extendBody: true,
      body: GlassBackground(child: IndexedStack(index: _index, children: pages)),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.fromLTRB(10, 0, 10, 10),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
            child: Container(
              height: 62,
              decoration: BoxDecoration(
                color: const Color(0xCC11161C),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: DsdColors.line),
              ),
              child: Row(children: [
                _Tab(icon: Icons.home_outlined, label: 'Home', on: _index == 0, onTap: () => _go(0)),
                _Tab(icon: Icons.receipt_long_outlined, label: 'Requests', on: _index == 1, onTap: () => _go(1)),
                Expanded(
                  child: Center(
                    child: Semantics(
                      button: true,
                      label: 'New exchange',
                      child: InkWell(
                        onTap: _newRequest,
                        borderRadius: BorderRadius.circular(12),
                        child: Container(
                          width: 44,
                          height: 40,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            gradient: const LinearGradient(
                                begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [DsdColors.gold2, DsdColors.gold]),
                          ),
                          child: const Icon(Icons.add, color: DsdColors.ink, size: 22),
                        ),
                      ),
                    ),
                  ),
                ),
                _Tab(icon: Icons.chat_bubble_outline, label: 'Chat', on: _index == 2, onTap: () => _go(2)),
                _Tab(icon: Icons.person_outline, label: 'Account', on: _index == 3, onTap: () => _go(3)),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

class _Tab extends StatelessWidget {
  const _Tab({required this.icon, required this.label, required this.on, required this.onTap});
  final IconData icon;
  final String label;
  final bool on;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = on ? DsdColors.gold2 : DsdColors.faint;
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, size: 20, color: color),
          const SizedBox(height: 3),
          Text(label, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w600, color: color)),
        ]),
      ),
    );
  }
}
