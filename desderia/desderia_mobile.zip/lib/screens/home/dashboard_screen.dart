import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/format.dart';
import '../../core/models.dart';
import '../../core/session.dart';
import '../../theme/colors.dart';
import '../../widgets/common.dart';
import '../../widgets/glass.dart';
import '../account/kyc_screen.dart';
import '../account/notifications_screen.dart';
import '../exchange/request_detail_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key, required this.onNewRequest, required this.onSeeRequests});
  final VoidCallback onNewRequest;
  final VoidCallback onSeeRequests;

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late Future<_Data> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<_Data> _load() async {
    final session = context.read<Session>();
    final results = await Future.wait([
      session.api.get('rates/'),
      session.api.get('requests/'),
      session.refreshUser().then((_) => null),
    ]);
    final rates = ((results[0] as Map)['rates'] as List).map((e) => Rate(Map<String, dynamic>.from(e as Map))).toList();
    final reqs = ((results[1] as Map)['results'] as List)
        .map((e) => RequestSummary(Map<String, dynamic>.from(e as Map)))
        .toList();
    return _Data(rates, reqs);
  }

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future;
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<Session>().user;
    return SafeArea(
      bottom: false,
      child: RefreshIndicator(
        onRefresh: _refresh,
        child: FutureBuilder<_Data>(
          future: _future,
          builder: (context, snap) {
            return ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
              children: [
                Row(children: [
                  const Brand(),
                  const Spacer(),
                  IconButton(
                    tooltip: 'Notifications',
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NotificationsScreen())),
                    icon: Badge(
                      isLabelVisible: (user?.unread ?? 0) > 0,
                      label: Text('${user?.unread ?? 0}'),
                      backgroundColor: DsdColors.gold,
                      textColor: DsdColors.ink,
                      child: const Icon(Icons.notifications_none_rounded),
                    ),
                  ),
                ]),
                const SizedBox(height: 16),
                Text('Hello, ${user?.firstName ?? ''}', style: Theme.of(context).textTheme.headlineSmall),
                const SizedBox(height: 4),
                const Text('Your exchanges and today\'s rates.', style: TextStyle(color: DsdColors.muted)),
                const SizedBox(height: 16),
                if (user != null && user.kycStatus != 'approved') ...[
                  GlassCard(
                    highlight: true,
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const KycScreen())),
                    child: Row(children: [
                      const Icon(Icons.badge_outlined, color: DsdColors.gold),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          user.kycStatus == 'pending'
                              ? 'Your identity documents are under review.'
                              : 'Verify your identity to exchange more than USD 1,000.',
                          style: const TextStyle(fontSize: 13),
                        ),
                      ),
                      const Icon(Icons.chevron_right, color: DsdColors.muted),
                    ]),
                  ),
                  const SizedBox(height: 12),
                ],
                FilledButton.icon(
                  onPressed: widget.onNewRequest,
                  icon: const Icon(Icons.swap_horiz_rounded, size: 18),
                  label: const Text('New exchange'),
                ),
                const SizedBox(height: 16),
                if (snap.hasError)
                  GlassCard(child: ErrorRetry(snap.error!, onRetry: _refresh))
                else if (!snap.hasData)
                  const Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator(strokeWidth: 2)))
                else ...[
                  _RecentCard(items: snap.data!.requests.take(5).toList(), onSeeAll: widget.onSeeRequests, onChanged: _refresh),
                  const SizedBox(height: 12),
                  _RatesCard(rates: snap.data!.rates),
                ],
              ],
            );
          },
        ),
      ),
    );
  }
}

class _Data {
  _Data(this.rates, this.requests);
  final List<Rate> rates;
  final List<RequestSummary> requests;
}

class _RecentCard extends StatelessWidget {
  const _RecentCard({required this.items, required this.onSeeAll, required this.onChanged});
  final List<RequestSummary> items;
  final VoidCallback onSeeAll;
  final VoidCallback onChanged;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: Column(children: [
        SectionTitle('Recent requests', icon: Icons.receipt_long_outlined,
            trailing: TextButton(onPressed: onSeeAll, child: const Text('View all'))),
        if (items.isEmpty) const EmptyState('No requests yet. Tap New exchange to start.', icon: Icons.swap_horiz_rounded),
        for (final r in items) RequestTile(r, onReturn: onChanged),
      ]),
    );
  }
}

class RequestTile extends StatelessWidget {
  const RequestTile(this.r, {super.key, this.onReturn});
  final RequestSummary r;
  final VoidCallback? onReturn;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () async {
        await Navigator.of(context).push(MaterialPageRoute(builder: (_) => RequestDetailScreen(reference: r.reference)));
        onReturn?.call();
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Row(children: [
          CurrencyChip(r.currency),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(r.directionLabel, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w600, color: DsdColors.ivory)),
              Text('${r.reference}  ${shortDate(r.createdAt)}',
                  style: const TextStyle(fontSize: 12, color: DsdColors.faint, fontFamily: 'monospace')),
            ]),
          ),
          const SizedBox(width: 8),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 150),
            child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text(money(r.foreignAmount, r.currency),
                  style: const TextStyle(fontWeight: FontWeight.w700, color: DsdColors.ivory, fontSize: 13)),
              const SizedBox(height: 4),
              StatusPill(r.statusLabel, tone: r.tone),
            ]),
          ),
        ]),
      ),
    );
  }
}

class _RatesCard extends StatelessWidget {
  const _RatesCard({required this.rates});
  final List<Rate> rates;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: Column(children: [
        const SectionTitle('Live rates', icon: Icons.trending_up_rounded,
            trailing: Text('TZS per unit', style: TextStyle(fontSize: 11, color: DsdColors.faint))),
        const Padding(
          padding: EdgeInsets.only(bottom: 6),
          child: Row(children: [
            Expanded(child: Text('CURRENCY', style: TextStyle(fontSize: 10.5, letterSpacing: 1, color: DsdColors.faint))),
            SizedBox(width: 90, child: Text('WE BUY', textAlign: TextAlign.right, style: TextStyle(fontSize: 10.5, letterSpacing: 1, color: DsdColors.faint))),
            SizedBox(width: 90, child: Text('WE SELL', textAlign: TextAlign.right, style: TextStyle(fontSize: 10.5, letterSpacing: 1, color: DsdColors.faint))),
          ]),
        ),
        for (final r in rates)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(children: [
              CurrencyChip(r.code),
              const SizedBox(width: 10),
              Expanded(child: Text(r.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: DsdColors.ivory))),
              SizedBox(width: 90, child: Text(money(r.buy), textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w600))),
              SizedBox(width: 90, child: Text(money(r.sell), textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w600))),
            ]),
          ),
      ]),
    );
  }
}
