import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/session.dart';
import '../../theme/colors.dart';
import '../../widgets/common.dart';
import '../../widgets/glass.dart';
import 'forgot_screen.dart';
import 'otp_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _form = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();
  String _channel = 'email';
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    final session = context.read<Session>();
    try {
      final needsCode = await session.login(_email.text, _password.text, channel: _channel);
      if (!mounted) return;
      if (needsCode) {
        await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const OtpScreen()));
      }
      if (mounted && session.state != AuthState.signedOut) {
        Navigator.of(context).popUntil((r) => r.isFirst);
      }
    } catch (e) {
      setState(() => _error = errorText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(),
      body: GlassBackground(
        child: SafeArea(
          child: ListView(padding: const EdgeInsets.all(20), children: [
            const SizedBox(height: 8),
            Text('Welcome back', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 6),
            const Text('Sign in with your email. We will send a one time code to confirm it is you.',
                style: TextStyle(color: DsdColors.muted)),
            const SizedBox(height: 20),
            GlassCard(
              child: Form(
                key: _form,
                child: AutofillGroup(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    if (_error != null) _ErrorBox(_error!),
                    Field(
                      controller: _email,
                      label: 'Email',
                      keyboard: TextInputType.emailAddress,
                      autofill: const [AutofillHints.email],
                      validator: (v) => (v ?? '').contains('@') ? null : 'Enter your email',
                    ),
                    Field(
                      controller: _password,
                      label: 'Password',
                      obscure: true,
                      autofill: const [AutofillHints.password],
                      validator: (v) => (v ?? '').isEmpty ? 'Enter your password' : null,
                    ),
                    SegmentedButton<String>(
                      segments: const [
                        ButtonSegment(value: 'email', label: Text('Code by email')),
                        ButtonSegment(value: 'sms', label: Text('Code by SMS')),
                      ],
                      selected: {_channel},
                      showSelectedIcon: false,
                      onSelectionChanged: (s) => setState(() => _channel = s.first),
                    ),
                    const SizedBox(height: 16),
                    BusyButton(label: 'Continue', icon: Icons.lock_outline, busy: _busy, onPressed: _submit),
                  ]),
                ),
              ),
            ),
            const SizedBox(height: 12),
            TextButton(
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ForgotScreen())),
              child: const Text('Forgot password?'),
            ),
          ]),
        ),
      ),
    );
  }
}

class _ErrorBox extends StatelessWidget {
  const _ErrorBox(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0x1AE58A7F),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0x59E58A7F)),
      ),
      child: Text(text, style: const TextStyle(color: Color(0xFFF2C3BD), fontSize: 13)),
    );
  }
}
