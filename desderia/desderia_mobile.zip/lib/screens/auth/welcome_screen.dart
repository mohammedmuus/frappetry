import 'package:flutter/material.dart';

import '../../theme/colors.dart';
import '../../widgets/common.dart';
import '../../widgets/glass.dart';
import 'login_screen.dart';
import 'register_screen.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GlassBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              const Align(alignment: Alignment.centerLeft, child: Brand()),
              const Spacer(),
              Center(child: ClipOval(child: Image.asset('assets/images/logo_round.png', width: 132, height: 132))),
              const SizedBox(height: 28),
              const Text('LICENSED BUREAU DE CHANGE',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 11, letterSpacing: 2, fontWeight: FontWeight.w700, color: DsdColors.gold)),
              const SizedBox(height: 10),
              Text('Exchange at live rates, negotiate, and receive it wired.',
                  textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 10),
              const Text('Every step recorded, verified and traceable.',
                  textAlign: TextAlign.center, style: TextStyle(color: DsdColors.muted)),
              const Spacer(),
              FilledButton(
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const RegisterScreen())),
                child: const Text('Open a free account'),
              ),
              const SizedBox(height: 10),
              OutlinedButton(
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const LoginScreen())),
                child: const Text('Sign in'),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
