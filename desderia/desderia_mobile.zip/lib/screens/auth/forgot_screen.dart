import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/session.dart';
import '../../theme/colors.dart';
import '../../widgets/common.dart';
import '../../widgets/glass.dart';

class ForgotScreen extends StatefulWidget {
  const ForgotScreen({super.key});

  @override
  State<ForgotScreen> createState() => _ForgotScreenState();
}

class _ForgotScreenState extends State<ForgotScreen> {
  final _email = TextEditingController();
  bool _busy = false;
  bool _sent = false;

  @override
  void dispose() {
    _email.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    setState(() => _busy = true);
    try {
      await context.read<Session>().api.post('auth/password-reset/', {'email': _email.text.trim()});
      setState(() => _sent = true);
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(),
      body: GlassBackground(
        child: SafeArea(
          child: ListView(padding: const EdgeInsets.all(20), children: [
            Text('Reset your password', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 6),
            const Text('We email a secure link. You choose the new password on our website.',
                style: TextStyle(color: DsdColors.muted)),
            const SizedBox(height: 20),
            GlassCard(
              child: _sent
                  ? const Text('If that email has an account, a reset link is on its way.')
                  : Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      Field(controller: _email, label: 'Email', keyboard: TextInputType.emailAddress),
                      BusyButton(label: 'Send reset link', busy: _busy, onPressed: _send),
                    ]),
            ),
          ]),
        ),
      ),
    );
  }
}
