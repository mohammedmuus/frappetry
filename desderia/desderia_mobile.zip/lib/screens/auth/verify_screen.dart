import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/session.dart';
import '../../theme/colors.dart';
import '../../widgets/common.dart';
import '../../widgets/glass.dart';

/// Both email and phone must be verified before trading.
class VerifyScreen extends StatelessWidget {
  const VerifyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final session = context.watch<Session>();
    final user = session.user;
    return Scaffold(
      body: GlassBackground(
        child: SafeArea(
          child: ListView(padding: const EdgeInsets.all(20), children: [
            Row(children: [
              const Brand(),
              const Spacer(),
              TextButton(onPressed: session.logout, child: const Text('Sign out')),
            ]),
            const SizedBox(height: 24),
            Text('Verify your account', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 6),
            const Text('Confirm your email and phone number to start exchanging.', style: TextStyle(color: DsdColors.muted)),
            const SizedBox(height: 20),
            _Channel(which: 'email', icon: Icons.mail_outline, title: 'Email', subtitle: user?.email ?? '',
                done: user?.emailVerified ?? false),
            const SizedBox(height: 12),
            _Channel(which: 'phone', icon: Icons.phone_iphone, title: 'Phone', subtitle: user?.phone ?? '',
                done: user?.phoneVerified ?? false),
          ]),
        ),
      ),
    );
  }
}

class _Channel extends StatefulWidget {
  const _Channel({required this.which, required this.icon, required this.title, required this.subtitle, required this.done});
  final String which;
  final IconData icon;
  final String title;
  final String subtitle;
  final bool done;

  @override
  State<_Channel> createState() => _ChannelState();
}

class _ChannelState extends State<_Channel> {
  final _code = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  Future<void> _verify() async {
    setState(() => _busy = true);
    try {
      await context.read<Session>().verifyChannel(widget.which, _code.text);
      if (mounted) toast(context, '${widget.title} verified.');
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _resend() async {
    try {
      await context.read<Session>().resendChannel(widget.which);
      if (mounted) toast(context, 'A new code was sent.');
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          Icon(widget.icon, color: DsdColors.gold),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(widget.title, style: const TextStyle(fontWeight: FontWeight.w600, color: DsdColors.ivory)),
              Text(widget.subtitle, style: const TextStyle(color: DsdColors.muted, fontSize: 12)),
            ]),
          ),
          if (widget.done) const StatusPill('Verified', tone: 'good'),
        ]),
        if (!widget.done) ...[
          const SizedBox(height: 14),
          TextField(
            controller: _code,
            keyboardType: TextInputType.number,
            autofillHints: const [AutofillHints.oneTimeCode],
            inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(6)],
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 20, letterSpacing: 8, fontWeight: FontWeight.w700, color: DsdColors.ivory),
            decoration: const InputDecoration(hintText: '000000'),
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: BusyButton(label: 'Verify', busy: _busy, onPressed: _verify)),
            const SizedBox(width: 8),
            TextButton(onPressed: _resend, child: Text(widget.which == 'phone' ? 'Resend SMS' : 'Resend')),
          ]),
        ],
      ]),
    );
  }
}
