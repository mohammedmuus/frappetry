import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/session.dart';
import '../../theme/colors.dart';
import '../../widgets/common.dart';
import '../../widgets/glass.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _phone = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  bool _terms = false;
  bool _busy = false;

  @override
  void dispose() {
    for (final c in [_name, _email, _phone, _password, _confirm]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    if (!_terms) {
      toast(context, 'Please accept the terms and privacy policy.');
      return;
    }
    setState(() => _busy = true);
    try {
      await context.read<Session>().register({
        'full_name': _name.text.trim(),
        'email': _email.text.trim(),
        'phone': _phone.text.trim(),
        'password': _password.text,
        'accept_terms': true,
      });
      if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(),
      body: GlassBackground(
        child: SafeArea(
          child: ListView(padding: const EdgeInsets.all(20), children: [
            Text('Open your account', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 6),
            const Text('You will verify your email and phone number next.', style: TextStyle(color: DsdColors.muted)),
            const SizedBox(height: 20),
            GlassCard(
              child: Form(
                key: _form,
                child: AutofillGroup(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    Field(controller: _name, label: 'Full name', autofill: const [AutofillHints.name],
                        validator: (v) => (v ?? '').trim().length < 3 ? 'Enter your full name' : null),
                    Field(controller: _email, label: 'Email', keyboard: TextInputType.emailAddress,
                        autofill: const [AutofillHints.email],
                        validator: (v) => RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch((v ?? '').trim()) ? null : 'Enter a valid email'),
                    Field(controller: _phone, label: 'Phone number', hint: '+255 7XX XXX XXX', keyboard: TextInputType.phone,
                        autofill: const [AutofillHints.telephoneNumber],
                        validator: (v) => (v ?? '').replaceAll(RegExp(r'\D'), '').length < 9 ? 'Enter your phone number' : null),
                    Field(controller: _password, label: 'Password', obscure: true, autofill: const [AutofillHints.newPassword],
                        validator: (v) => (v ?? '').length < 10 ? 'At least 10 characters' : null),
                    Field(controller: _confirm, label: 'Confirm password', obscure: true,
                        validator: (v) => v != _password.text ? 'The passwords do not match' : null),
                    CheckboxListTile(
                      value: _terms,
                      onChanged: (v) => setState(() => _terms = v ?? false),
                      contentPadding: EdgeInsets.zero,
                      controlAffinity: ListTileControlAffinity.leading,
                      dense: true,
                      title: const Text('I accept the terms and privacy policy', style: TextStyle(fontSize: 13)),
                    ),
                    const SizedBox(height: 8),
                    BusyButton(label: 'Create account', busy: _busy, onPressed: _submit),
                  ]),
                ),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
