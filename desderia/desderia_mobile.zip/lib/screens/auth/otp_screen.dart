import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../core/session.dart';
import '../../theme/colors.dart';
import '../../widgets/common.dart';
import '../../widgets/glass.dart';

/// Step two of sign in: the six digit code.
class OtpScreen extends StatefulWidget {
  const OtpScreen({super.key});

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  final _code = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  Future<void> _verify() async {
    if (_code.text.trim().length != 6) {
      toast(context, 'Enter the six digit code.');
      return;
    }
    setState(() => _busy = true);
    try {
      await context.read<Session>().verifyLogin(_code.text);
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _resend() async {
    try {
      await context.read<Session>().resendLoginCode();
      if (mounted) toast(context, 'A new code was sent.');
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final channel = context.read<Session>().pendingChannel;
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(),
      body: GlassBackground(
        child: SafeArea(
          child: ListView(padding: const EdgeInsets.all(20), children: [
            Text('Enter your code', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 6),
            Text('We sent a six digit code by ${channel == 'sms' ? 'SMS' : 'email'}. It expires in 10 minutes.',
                style: const TextStyle(color: DsdColors.muted)),
            const SizedBox(height: 20),
            GlassCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                TextField(
                  controller: _code,
                  autofocus: true,
                  keyboardType: TextInputType.number,
                  autofillHints: const [AutofillHints.oneTimeCode],
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(6)],
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 22, letterSpacing: 10, fontWeight: FontWeight.w700, color: DsdColors.ivory),
                  decoration: const InputDecoration(hintText: '000000'),
                  onSubmitted: (_) => _verify(),
                ),
                const SizedBox(height: 16),
                BusyButton(label: 'Verify and sign in', busy: _busy, onPressed: _verify),
                TextButton(onPressed: _resend, child: const Text('Send a new code')),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}
