import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/format.dart';
import '../../core/models.dart';
import '../../core/session.dart';
import '../../theme/colors.dart';
import '../../widgets/common.dart';
import '../../widgets/glass.dart';
import '../chat/chat_screen.dart';

class RequestDetailScreen extends StatefulWidget {
  const RequestDetailScreen({super.key, required this.reference});
  final String reference;

  @override
  State<RequestDetailScreen> createState() => _RequestDetailScreenState();
}

class _RequestDetailScreenState extends State<RequestDetailScreen> {
  RequestDetail? _r;
  Object? _error;
  bool _busy = false;
  final _rate = TextEditingController();
  final _offerNote = TextEditingController();
  final _paidRef = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _rate.dispose();
    _offerNote.dispose();
    _paidRef.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      await context.read<Session>().loadOptions();
      if (!mounted) return;
      final data = await context.read<Session>().api.get('requests/${widget.reference}/');
      setState(() {
        _r = RequestDetail(Map<String, dynamic>.from(data as Map));
        _error = null;
      });
    } catch (e) {
      setState(() => _error = e);
    }
  }

  /// Every action goes through here: one at a time, the button is locked
  /// while the call runs, and the screen shows the server's fresh state.
  Future<void> _act(String action, [Map<String, dynamic>? body, String? done]) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final data = await context.read<Session>().api.post('requests/${widget.reference}/$action/', body);
      setState(() => _r = RequestDetail(Map<String, dynamic>.from(data as Map)));
      if (done != null && mounted) toast(context, done);
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _pay() async {
    await _act('pay');
    final url = _r?.payment?['checkout_url'] as String?;
    if (url != null && url.startsWith('https://')) {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } else if (mounted && _r?.fundingMethod == 'cashpay') {
      toast(context, 'Approve the CashPay prompt on your phone.');
    }
  }

  Future<void> _confirmCancel() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: DsdColors.ink3,
        title: const Text('Cancel this request?'),
        content: const Text('This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Keep it')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Cancel request')),
        ],
      ),
    );
    if (ok == true) await _act('cancel', {'reason': 'Cancelled in the app'}, 'Request cancelled.');
  }

  @override
  Widget build(BuildContext context) {
    final r = _r;
    return Scaffold(
      appBar: AppBar(title: Text(widget.reference, style: const TextStyle(fontFamily: 'monospace', fontSize: 16))),
      floatingActionButton: r?.conversationId == null
          ? null
          : FloatingActionButton.small(
              backgroundColor: DsdColors.gold,
              foregroundColor: DsdColors.ink,
              tooltip: 'Chat about this request',
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => ChatScreen(conversationId: r!.conversationId!, title: 'Request ${r.reference}'))),
              child: const Icon(Icons.chat_bubble_outline, size: 18),
            ),
      body: GlassBackground(
        child: SafeArea(
          child: _error != null
              ? ErrorRetry(_error!, onRetry: _load)
              : r == null
                  ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
                  : RefreshIndicator(
                      onRefresh: _load,
                      child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 80), children: [
                        Row(children: [
                          Expanded(child: Text(r.directionLabel, style: const TextStyle(color: DsdColors.muted))),
                          StatusPill(r.statusLabel, tone: r.tone),
                        ]),
                        const SizedBox(height: 12),
                        Row(children: [
                          Expanded(child: _Amount('You pay', r.pay)),
                          const SizedBox(width: 10),
                          Expanded(child: _Amount('You receive', r.receive)),
                        ]),
                        const SizedBox(height: 12),
                        GlassCard(
                          child: Column(children: [
                            KeyValue(r.agreedRate != null ? 'Agreed rate' : 'Locked rate', '${money(r.effectiveRate)} TZS'),
                            if (r.agreedRate == null && r.isOpen) KeyValue('Lock expires', clock(r.quoteExpiresAt)),
                            KeyValue('Funding', _label(r.fundingMethod)),
                            KeyValue('Payout', _label(r.payoutMethod)),
                            if (r.beneficiary != null) KeyValue('Send to', r.beneficiary!['display']?.toString() ?? ''),
                            if (r.fundingDeadline != null && r.status == 'approved') KeyValue('Fund before', dateTime(r.fundingDeadline)),
                            if (r.fundingReference.isNotEmpty) KeyValue('Funding ref', r.fundingReference, mono: true),
                            if (r.payoutReference.isNotEmpty) KeyValue('Payout ref', r.payoutReference, mono: true),
                            if (r.closedReason.isNotEmpty) KeyValue('Note', r.closedReason),
                          ]),
                        ),
                        if (r.status == 'approved') ...[const SizedBox(height: 12), _paymentCard(r)],
                        if (r.status == 'paid_out') ...[
                          const SizedBox(height: 12),
                          GlassCard(
                            highlight: true,
                            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                              const Text('Did you receive your money?'),
                              const SizedBox(height: 10),
                              BusyButton(label: 'Confirm receipt', busy: _busy,
                                  onPressed: () => _act('received', null, 'Thank you. The request is complete.')),
                            ]),
                          ),
                        ],
                        if (r.offers.isNotEmpty || r.canNegotiate) ...[const SizedBox(height: 12), _negotiation(r)],
                        const SizedBox(height: 12),
                        GlassCard(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            const SectionTitle('Timeline', icon: Icons.schedule_rounded),
                            for (final e in r.events) _TimelineRow(e),
                          ]),
                        ),
                        if (r.cancellable) ...[
                          const SizedBox(height: 12),
                          OutlinedButton(
                            style: OutlinedButton.styleFrom(foregroundColor: DsdColors.bad, side: const BorderSide(color: Color(0x4DE58A7F))),
                            onPressed: _busy ? null : _confirmCancel,
                            child: const Text('Cancel request'),
                          ),
                        ],
                      ]),
                    ),
        ),
      ),
    );
  }

  String _label(String key) {
    final o = context.read<Session>().options;
    if (o == null) return key.replaceAll('_', ' ');
    const funding = ['cashpay', 'bank_transfer', 'cash'];
    return funding.contains(key) ? o.fundingLabel(key) : o.payoutLabel(key);
  }

  Widget _paymentCard(RequestDetail r) {
    final payment = r.payment;
    final bank = r.bank;
    return GlassCard(
      highlight: true,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const SectionTitle('Complete your payment', icon: Icons.account_balance_wallet_outlined),
        if (r.fundingMethod == 'cashpay') ...[
          const Text('Pay securely with CashPay. You will approve it on your phone.', style: TextStyle(color: DsdColors.muted)),
          const SizedBox(height: 12),
          BusyButton(label: 'Pay with CashPay', icon: Icons.payments_outlined, busy: _busy, onPressed: _pay),
        ] else if (bank != null) ...[
          KeyValue('Bank', '${bank['bank']}'),
          KeyValue('Account name', '${bank['account_name']}'),
          KeyValue('Account', '${r.direction == 'buy' ? bank['account_number_tzs'] : bank['account_number_usd']}', mono: true),
          KeyValue('SWIFT', '${bank['swift']}', mono: true),
          Row(children: [
            Expanded(child: KeyValue('Reference', r.reference, mono: true)),
            IconButton(
              tooltip: 'Copy reference',
              icon: const Icon(Icons.copy_rounded, size: 18),
              onPressed: () {
                Clipboard.setData(ClipboardData(text: r.reference));
                toast(context, 'Reference copied.');
              },
            ),
          ]),
        ] else
          Text('Bring the amount to our branch and quote ${r.reference}. The teller confirms it here.',
              style: const TextStyle(color: DsdColors.muted)),
        if (r.fundingMethod != 'cash') ...[
          const SizedBox(height: 12),
          if (payment != null && (payment['customer_reference'] ?? '').toString().isNotEmpty)
            Text('You reported reference ${payment['customer_reference']}. We are confirming it.',
                style: const TextStyle(color: DsdColors.info, fontSize: 13))
          else ...[
            Field(controller: _paidRef, label: 'Payment reference', hint: 'Bank or mobile money reference', maxLength: 64),
            BusyButton(
              label: 'I have paid',
              outlined: true,
              busy: _busy,
              onPressed: () => _act('paid', {'reference': _paidRef.text.trim()}, 'Thank you. We will confirm shortly.'),
            ),
          ],
        ],
      ]),
    );
  }

  Widget _negotiation(RequestDetail r) {
    return GlassCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const SectionTitle('Negotiation', icon: Icons.sell_outlined),
        for (final o in r.offers)
          Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: o.status == 'pending' ? DsdColors.glassGold : const Color(0x33000000),
              border: Border.all(color: o.status == 'pending' ? DsdColors.line : DsdColors.line2),
            ),
            child: Row(children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${o.side == 'bureau' ? 'Desderia offer' : 'Your offer'}, ${shortDate(o.createdAt)} ${clock(o.createdAt)}',
                      style: const TextStyle(fontSize: 12, color: DsdColors.muted)),
                  Text('${money(o.rate)} TZS', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: DsdColors.ivory)),
                  if (o.message.isNotEmpty) Text(o.message, style: const TextStyle(fontSize: 12.5)),
                ]),
              ),
              if (o.status == 'pending' && o.side == 'bureau')
                Column(children: [
                  FilledButton(
                    style: FilledButton.styleFrom(minimumSize: const Size(84, 34)),
                    onPressed: _busy ? null : () => _act('respond', {'offer_id': o.id, 'accept': true}, 'Offer accepted. Your rate is fixed.'),
                    child: const Text('Accept'),
                  ),
                  const SizedBox(height: 6),
                  OutlinedButton(
                    style: OutlinedButton.styleFrom(minimumSize: const Size(84, 34)),
                    onPressed: _busy ? null : () => _act('respond', {'offer_id': o.id, 'accept': false}, 'Offer declined.'),
                    child: const Text('Decline'),
                  ),
                ])
              else
                StatusPill(o.status[0].toUpperCase() + o.status.substring(1),
                    tone: o.status == 'accepted' ? 'good' : (o.status == 'pending' ? 'pending' : 'muted')),
            ]),
          ),
        if (r.canNegotiate) ...[
          const SizedBox(height: 4),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(
              child: Field(controller: _rate, label: 'Your rate', keyboard: const TextInputType.numberWithOptions(decimal: true)),
            ),
            const SizedBox(width: 10),
            Expanded(child: Field(controller: _offerNote, label: 'Note', maxLength: 300)),
          ]),
          BusyButton(
            label: 'Propose this rate',
            outlined: true,
            icon: Icons.send_rounded,
            busy: _busy,
            onPressed: () => _act('offer', {'rate': _rate.text.trim(), 'message': _offerNote.text.trim()}, 'Your offer was sent.'),
          ),
        ],
      ]),
    );
  }
}

class _Amount extends StatelessWidget {
  const _Amount(this.label, this.data);
  final String label;
  final Map<String, dynamic> data;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontSize: 12, color: DsdColors.muted)),
        const SizedBox(height: 4),
        FittedBox(
          fit: BoxFit.scaleDown,
          alignment: Alignment.centerLeft,
          child: Text(money(data['amount'], data['currency']?.toString()),
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: DsdColors.ivory)),
        ),
      ]),
    );
  }
}

class _TimelineRow extends StatelessWidget {
  const _TimelineRow(this.e);
  final TimelineEvent e;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
            margin: const EdgeInsets.only(top: 5),
            width: 8,
            height: 8,
            decoration: const BoxDecoration(color: DsdColors.gold, shape: BoxShape.circle)),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(e.label, style: const TextStyle(fontWeight: FontWeight.w600, color: DsdColors.ivory, fontSize: 13)),
            if (e.note.isNotEmpty) Text(e.note, style: const TextStyle(fontSize: 12.5, color: DsdColors.muted)),
            Text(dateTime(e.at), style: const TextStyle(fontSize: 11.5, color: DsdColors.faint)),
          ]),
        ),
      ]),
    );
  }
}
