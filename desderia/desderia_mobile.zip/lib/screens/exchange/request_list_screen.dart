import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/models.dart';
import '../../core/session.dart';
import '../../widgets/common.dart';
import '../../widgets/glass.dart';
import '../home/dashboard_screen.dart';

class RequestListScreen extends StatefulWidget {
  const RequestListScreen({super.key});

  @override
  State<RequestListScreen> createState() => _RequestListScreenState();
}

class _RequestListScreenState extends State<RequestListScreen> {
  bool _openOnly = false;
  late Future<List<RequestSummary>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<RequestSummary>> _load() async {
    final data = await context.read<Session>().api.get('requests/', query: _openOnly ? {'status': 'open'} : null);
    return ((data as Map)['results'] as List).map((e) => RequestSummary(Map<String, dynamic>.from(e as Map))).toList();
  }

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future;
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: RefreshIndicator(
        onRefresh: _refresh,
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 100), children: [
          Text('My requests', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 12),
          SegmentedButton<bool>(
            segments: const [ButtonSegment(value: false, label: Text('All')), ButtonSegment(value: true, label: Text('Open'))],
            selected: {_openOnly},
            showSelectedIcon: false,
            onSelectionChanged: (s) {
              _openOnly = s.first;
              _refresh();
            },
          ),
          const SizedBox(height: 12),
          FutureBuilder<List<RequestSummary>>(
            future: _future,
            builder: (context, snap) {
              if (snap.hasError) return GlassCard(child: ErrorRetry(snap.error!, onRetry: _refresh));
              if (!snap.hasData) {
                return const Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator(strokeWidth: 2)));
              }
              final items = snap.data!;
              return GlassCard(
                child: items.isEmpty
                    ? const EmptyState('No requests here yet.', icon: Icons.receipt_long_outlined)
                    : Column(children: [for (final r in items) RequestTile(r, onReturn: _refresh)]),
              );
            },
          ),
        ]),
      ),
    );
  }
}
