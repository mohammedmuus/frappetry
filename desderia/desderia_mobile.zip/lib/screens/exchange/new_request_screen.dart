import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

import '../../core/format.dart';
import '../../core/models.dart';
import '../../core/session.dart';
import '../../theme/colors.dart';
import '../../widgets/common.dart';
import '../../widgets/glass.dart';
import '../beneficiaries/beneficiary_form_screen.dart';
import 'request_detail_screen.dart';

class NewRequestScreen extends StatefulWidget {
  const NewRequestScreen({super.key});

  @override
  State<NewRequestScreen> createState() => _NewRequestScreenState();
}

class _NewRequestScreenState extends State<NewRequestScreen> {
  // One key per form opening: a retried submit returns the same request.
  final String _idempotencyKey = const Uuid().v4();
  final _amount = TextEditingController(text: '1000');
  final _source = TextEditingController();
  final _note = TextEditingController();
  Options? _options;
  List<Beneficiary> _beneficiaries = [];
  String _direction = 'buy';
  String? _currency;
  String? _funding;
  String? _payout;
  String? _beneficiary;
  String? _purpose;
  Map<String, dynamic>? _quote;
  String? _quoteError;
  Timer? _debounce;
  bool _busy = false;
  Object? _loadError;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _amount.dispose();
    _source.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final session = context.read<Session>();
    try {
      final options = await session.loadOptions();
      final bens = await session.api.get('beneficiaries/');
      setState(() {
        _options = options;
        _beneficiaries = ((bens as Map)['results'] as List).map((e) => Beneficiary(Map<String, dynamic>.from(e as Map))).toList();
        _currency = options.currencies.firstWhere((c) => c['code'] != options.base, orElse: () => options.currencies.first)['code'] as String;
        _purpose = options.purposes.first.first;
        _syncMethods();
        _loadError = null;
      });
      _requote();
    } catch (e) {
      setState(() => _loadError = e);
    }
  }

  void _syncMethods() {
    final o = _options!;
    final funding = o.funding(_direction);
    final payout = o.payout(_direction);
    if (!funding.contains(_funding)) _funding = funding.first;
    if (!payout.contains(_payout)) _payout = payout.first;
    if (!_eligible.any((b) => b.id == _beneficiary)) _beneficiary = null;
  }

  /// Beneficiaries that can receive this payout (right currency and kind).
  List<Beneficiary> get _eligible {
    final o = _options;
    if (o == null) return [];
    final currency = _direction == 'buy' ? _currency : o.base;
    final kind = _payout == 'mobile_money' ? 'mobile' : 'bank';
    return _beneficiaries.where((b) => b.currency == currency && b.kind == kind).toList();
  }

  void _requote() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 300), () async {
      final amount = double.tryParse(_amount.text.replaceAll(',', ''));
      if (amount == null || amount <= 0 || _currency == null) {
        setState(() => _quote = null);
        return;
      }
      try {
        final q = await context.read<Session>().api.get('quote/', query: {
          'currency': _currency!,
          'direction': _direction,
          'amount': amount.toStringAsFixed(2),
        });
        if (mounted) {
          setState(() {
            _quote = Map<String, dynamic>.from(q as Map);
            _quoteError = null;
          });
        }
      } catch (e) {
        if (mounted) setState(() => _quoteError = errorText(e));
      }
    });
  }

  Future<void> _submit() async {
    if (_source.text.trim().isEmpty) {
      toast(context, 'Tell us the source of funds.');
      return;
    }
    if (_payout != 'cash_pickup' && _beneficiary == null) {
      toast(context, 'Choose where we should send the money.');
      return;
    }
    setState(() => _busy = true);
    try {
      final data = await context.read<Session>().api.post('requests/', {
        'direction': _direction,
        'currency': _currency,
        'amount': double.parse(_amount.text.replaceAll(',', '')).toStringAsFixed(2),
        'funding_method': _funding,
        'payout_method': _payout,
        'beneficiary': _payout == 'cash_pickup' ? null : _beneficiary,
        'purpose': _purpose,
        'source_of_funds': _source.text.trim(),
        'note': _note.text.trim(),
        'idempotency_key': _idempotencyKey,
      });
      final ref = (data as Map)['reference'] as String;
      if (!mounted) return;
      await Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => RequestDetailScreen(reference: ref)));
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final o = _options;
    return Scaffold(
      appBar: AppBar(title: const Text('New exchange')),
      body: GlassBackground(
        child: SafeArea(
          child: _loadError != null
              ? ErrorRetry(_loadError!, onRetry: _load)
              : o == null
                  ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
                  : ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
                      SegmentedButton<String>(
                        segments: const [
                          ButtonSegment(value: 'buy', label: Text('Buy foreign')),
                          ButtonSegment(value: 'sell', label: Text('Sell foreign')),
                        ],
                        selected: {_direction},
                        showSelectedIcon: false,
                        onSelectionChanged: (s) {
                          setState(() {
                            _direction = s.first;
                            _syncMethods();
                          });
                          _requote();
                        },
                      ),
                      const SizedBox(height: 14),
                      _QuoteCard(quote: _quote, error: _quoteError),
                      const SizedBox(height: 14),
                      GlassCard(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Expanded(
                              child: Dropdown<String>(
                                label: 'Currency',
                                value: _currency,
                                items: [
                                  for (final c in o.currencies.where((c) => c['code'] != o.base))
                                    DropdownMenuItem(value: c['code'] as String, child: Text(c['code'] as String)),
                                ],
                                onChanged: (v) {
                                  setState(() {
                                    _currency = v;
                                    _syncMethods();
                                  });
                                  _requote();
                                },
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Field(
                                controller: _amount,
                                label: 'Amount',
                                keyboard: const TextInputType.numberWithOptions(decimal: true),
                                onChanged: (_) => _requote(),
                              ),
                            ),
                          ]),
                          Dropdown<String>(
                            label: 'How you will pay us',
                            value: _funding,
                            items: [for (final f in o.funding(_direction)) DropdownMenuItem(value: f, child: Text(o.fundingLabel(f)))],
                            onChanged: (v) => setState(() => _funding = v),
                          ),
                          Dropdown<String>(
                            label: 'How you receive',
                            value: _payout,
                            items: [for (final p in o.payout(_direction)) DropdownMenuItem(value: p, child: Text(o.payoutLabel(p)))],
                            onChanged: (v) => setState(() {
                              _payout = v;
                              _syncMethods();
                            }),
                          ),
                          if (_payout != 'cash_pickup') ...[
                            Dropdown<String>(
                              label: 'Send to',
                              value: _beneficiary,
                              items: [for (final b in _eligible) DropdownMenuItem(value: b.id, child: Text(b.display, overflow: TextOverflow.ellipsis))],
                              onChanged: (v) => setState(() => _beneficiary = v),
                            ),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: TextButton.icon(
                                onPressed: () async {
                                  final added = await Navigator.of(context)
                                      .push<bool>(MaterialPageRoute(builder: (_) => const BeneficiaryFormScreen()));
                                  if (added == true) _load();
                                },
                                icon: const Icon(Icons.add, size: 18),
                                label: const Text('Add a beneficiary'),
                              ),
                            ),
                          ],
                          Dropdown<String>(
                            label: 'Purpose',
                            value: _purpose,
                            items: [for (final p in o.purposes) DropdownMenuItem(value: p[0], child: Text(p[1]))],
                            onChanged: (v) => setState(() => _purpose = v),
                          ),
                          Field(controller: _source, label: 'Source of funds', hint: 'Salary, business income, savings', maxLength: 160),
                          Field(controller: _note, label: 'Note for our desk (optional)', maxLines: 2, maxLength: 500),
                          Text('Requests above USD ${o.kycLimitUsd} equivalent need approved identity documents.',
                              style: const TextStyle(fontSize: 12, color: DsdColors.faint)),
                          const SizedBox(height: 14),
                          BusyButton(label: 'Submit request', icon: Icons.check, busy: _busy, onPressed: _submit),
                        ]),
                      ),
                    ]),
        ),
      ),
    );
  }
}

class _QuoteCard extends StatelessWidget {
  const _QuoteCard({required this.quote, required this.error});
  final Map<String, dynamic>? quote;
  final String? error;

  @override
  Widget build(BuildContext context) {
    final q = quote;
    return GlassCard(
      highlight: true,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Total in Tanzanian shillings', style: TextStyle(fontSize: 12, color: DsdColors.muted)),
        const SizedBox(height: 4),
        Text(q == null ? 'TZS 0.00' : money(q['local_amount'], 'TZS'),
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: DsdColors.ivory)),
        const SizedBox(height: 4),
        Text(q == null ? 'Rate -' : 'Rate ${money(q['rate'])} TZS per unit, locked when you submit',
            style: const TextStyle(fontSize: 12, color: DsdColors.muted)),
        if (q != null && q['negotiable'] == true)
          const Padding(
            padding: EdgeInsets.only(top: 6),
            child: Text('This amount qualifies for rate negotiation.', style: TextStyle(fontSize: 12, color: DsdColors.gold2)),
          ),
        if (error != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(error!, style: const TextStyle(color: DsdColors.bad, fontSize: 12))),
      ]),
    );
  }
}
