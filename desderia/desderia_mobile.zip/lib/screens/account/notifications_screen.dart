import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/format.dart';
import '../../core/models.dart';
import '../../core/session.dart';
import '../../theme/colors.dart';
import '../../widgets/common.dart';
import '../../widgets/glass.dart';
import '../exchange/request_detail_screen.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  late Future<List<AppNotification>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<AppNotification>> _load({bool markRead = false}) async {
    final api = context.read<Session>().api;
    final data = markRead ? await api.post('notifications/') : await api.get('notifications/');
    return ((data as Map)['results'] as List).map((e) => AppNotification(Map<String, dynamic>.from(e as Map))).toList();
  }

  void _open(AppNotification n) {
    final match = RegExp(r'/exchange/r/([A-Z0-9-]+)/').firstMatch(n.link);
    if (match != null) {
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => RequestDetailScreen(reference: match.group(1)!)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Notifications'), actions: [
        TextButton(
          onPressed: () async {
            setState(() => _future = _load(markRead: true));
            await _future;
            if (context.mounted) await context.read<Session>().refreshUser();
          },
          child: const Text('Mark all read'),
        ),
      ]),
      body: GlassBackground(
        child: SafeArea(
          child: FutureBuilder<List<AppNotification>>(
            future: _future,
            builder: (context, snap) {
              if (snap.hasError) return ErrorRetry(snap.error!, onRetry: () => setState(() => _future = _load()));
              if (!snap.hasData) return const Center(child: CircularProgressIndicator(strokeWidth: 2));
              final items = snap.data!;
              return ListView(padding: const EdgeInsets.all(16), children: [
                GlassCard(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                  child: items.isEmpty
                      ? const EmptyState('Nothing here yet.', icon: Icons.notifications_none_rounded)
                      : Column(children: [
                          for (final n in items)
                            ListTile(
                              onTap: () => _open(n),
                              leading: Icon(Icons.notifications_none_rounded, color: n.read ? DsdColors.faint : DsdColors.gold),
                              title: Text(n.title, style: const TextStyle(color: DsdColors.ivory, fontWeight: FontWeight.w600, fontSize: 14)),
                              subtitle: Text('${n.body}\n${dateTime(n.createdAt)}', style: const TextStyle(fontSize: 12.5)),
                              isThreeLine: true,
                            ),
                        ]),
                ),
              ]);
            },
          ),
        ),
      ),
    );
  }
}
