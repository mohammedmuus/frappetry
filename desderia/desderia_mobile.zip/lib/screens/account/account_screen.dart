import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../config/env.dart';
import '../../core/session.dart';
import '../../theme/colors.dart';
import '../../widgets/common.dart';
import '../../widgets/glass.dart';
import '../beneficiaries/beneficiaries_screen.dart';
import 'kyc_screen.dart';
import 'notifications_screen.dart';

class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key});

  String _kycLabel(String s) => switch (s) {
        'approved' => 'Approved',
        'pending' => 'Pending review',
        'rejected' => 'Rejected',
        _ => 'Not submitted',
      };

  @override
  Widget build(BuildContext context) {
    final session = context.watch<Session>();
    final u = session.user;
    return SafeArea(
      bottom: false,
      child: ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 100), children: [
        Text('Account', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 14),
        GlassCard(
          child: Row(children: [
            CircleAvatar(
              radius: 22,
              backgroundColor: DsdColors.gold,
              child: Text((u?.fullName ?? '?').substring(0, 1).toUpperCase(),
                  style: const TextStyle(color: DsdColors.ink, fontWeight: FontWeight.w800)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(u?.fullName ?? '', style: const TextStyle(fontWeight: FontWeight.w700, color: DsdColors.ivory)),
                Text(u?.email ?? '', style: const TextStyle(fontSize: 12.5, color: DsdColors.muted)),
                Text(u?.phone ?? '', style: const TextStyle(fontSize: 12.5, color: DsdColors.muted)),
              ]),
            ),
          ]),
        ),
        const SizedBox(height: 12),
        GlassCard(
          padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
          child: Column(children: [
            _Item(
              icon: Icons.badge_outlined,
              title: 'Identity (KYC)',
              trailing: StatusPill(_kycLabel(u?.kycStatus ?? ''),
                  tone: u?.kycStatus == 'approved' ? 'good' : (u?.kycStatus == 'rejected' ? 'bad' : 'pending')),
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const KycScreen())),
            ),
            _Item(
              icon: Icons.account_balance_outlined,
              title: 'Beneficiaries',
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BeneficiariesScreen())),
            ),
            _Item(
              icon: Icons.notifications_none_rounded,
              title: 'Notifications',
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NotificationsScreen())),
            ),
            SwitchListTile(
              value: u?.notifyEmail ?? true,
              activeThumbColor: DsdColors.gold,
              secondary: const Icon(Icons.mail_outline),
              title: const Text('Email me on every update', style: TextStyle(fontSize: 14)),
              onChanged: (v) async {
                try {
                  await session.api.patch('me/', {'notify_email': v});
                  await session.refreshUser();
                } catch (e) {
                  if (context.mounted) toast(context, errorText(e));
                }
              },
            ),
          ]),
        ),
        const SizedBox(height: 12),
        GlassCard(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const SectionTitle('Security', icon: Icons.shield_outlined),
            const Text('Sign in uses your password plus a one time code. This device signs out automatically after '
                '15 minutes in the background. Change your password on the website to sign out every device.',
                style: TextStyle(fontSize: 12.5, color: DsdColors.muted)),
            const SizedBox(height: 8),
            Text('Server: ${Uri.parse(Env.apiBaseUrl).host}', style: const TextStyle(fontSize: 11.5, color: DsdColors.faint)),
          ]),
        ),
        const SizedBox(height: 16),
        OutlinedButton.icon(
          onPressed: session.logout,
          icon: const Icon(Icons.logout_rounded, size: 18),
          label: const Text('Sign out'),
        ),
      ]),
    );
  }
}

class _Item extends StatelessWidget {
  const _Item({required this.icon, required this.title, required this.onTap, this.trailing});
  final IconData icon;
  final String title;
  final VoidCallback onTap;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title, style: const TextStyle(fontSize: 14, color: DsdColors.ivory)),
      trailing: trailing ?? const Icon(Icons.chevron_right),
      onTap: onTap,
    );
  }
}
