import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../core/models.dart';
import '../../core/session.dart';
import '../../theme/colors.dart';
import '../../widgets/common.dart';
import '../../widgets/glass.dart';

class KycScreen extends StatefulWidget {
  const KycScreen({super.key});

  @override
  State<KycScreen> createState() => _KycScreenState();
}

class _KycScreenState extends State<KycScreen> {
  final _legal = TextEditingController();
  final _idNumber = TextEditingController();
  final _nationality = TextEditingController(text: 'Tanzanian');
  final _address = TextEditingController();
  final _occupation = TextEditingController();
  DateTime? _dob;
  String? _idType;
  File? _photo;
  Options? _options;
  Map<String, dynamic>? _current;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in [_legal, _idNumber, _nationality, _address, _occupation]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    final session = context.read<Session>();
    final o = await session.loadOptions();
    final k = await session.api.get('kyc/');
    if (!mounted) return;
    setState(() {
      _options = o;
      _current = Map<String, dynamic>.from(k as Map);
      _idType = o.idTypes.first.first;
    });
  }

  Future<void> _pick(ImageSource source) async {
    final x = await ImagePicker().pickImage(source: source, maxWidth: 2400, imageQuality: 85);
    if (x != null) setState(() => _photo = File(x.path));
  }

  Future<void> _submit() async {
    if (_dob == null || _photo == null) {
      toast(context, 'Add your date of birth and a photo of the document.');
      return;
    }
    setState(() => _busy = true);
    final d = _dob!;
    try {
      final session = context.read<Session>();
      await session.api.upload('kyc/', {
        'legal_name': _legal.text.trim(),
        'id_type': _idType ?? '',
        'id_number': _idNumber.text.trim(),
        'nationality': _nationality.text.trim(),
        'date_of_birth': '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}',
        'address': _address.text.trim(),
        'occupation': _occupation.text.trim(),
      }, 'id_document', _photo!);
      await session.refreshUser();
      if (mounted) {
        toast(context, 'Thank you. Our team will review your documents shortly.');
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final o = _options;
    final status = _current?['status'] as String? ?? 'not_submitted';
    return Scaffold(
      appBar: AppBar(title: const Text('Identity verification')),
      body: GlassBackground(
        child: SafeArea(
          child: o == null
              ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
              : ListView(padding: const EdgeInsets.all(16), children: [
                  Text('Required for requests above USD ${o.kycLimitUsd} equivalent, under Bank of Tanzania rules.',
                      style: const TextStyle(color: DsdColors.muted)),
                  const SizedBox(height: 12),
                  if (status == 'approved')
                    const GlassCard(child: Text('Your identity is verified. Higher limits are active.'))
                  else ...[
                    if (status == 'pending')
                      const Padding(
                        padding: EdgeInsets.only(bottom: 12),
                        child: StatusPill('Under review. You can resubmit if something changed.', tone: 'pending'),
                      ),
                    if (status == 'rejected' && (_current?['review_note'] ?? '').toString().isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Text('${_current!['review_note']}', style: const TextStyle(color: DsdColors.bad)),
                      ),
                    GlassCard(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                        Field(controller: _legal, label: 'Legal name', maxLength: 150),
                        Dropdown<String>(
                          label: 'ID type',
                          value: _idType,
                          items: [for (final t in o.idTypes) DropdownMenuItem(value: t[0], child: Text(t[1]))],
                          onChanged: (v) => setState(() => _idType = v),
                        ),
                        Field(controller: _idNumber, label: 'ID number', maxLength: 40),
                        const Text('Date of birth', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: DsdColors.muted)),
                        const SizedBox(height: 6),
                        OutlinedButton(
                          onPressed: () async {
                            final now = DateTime.now();
                            final picked = await showDatePicker(
                              context: context,
                              initialDate: DateTime(now.year - 30),
                              firstDate: DateTime(now.year - 110),
                              lastDate: DateTime(now.year - 18, now.month, now.day),
                            );
                            if (picked != null) setState(() => _dob = picked);
                          },
                          child: Text(_dob == null ? 'Choose date' : '${_dob!.day}/${_dob!.month}/${_dob!.year}'),
                        ),
                        const SizedBox(height: 12),
                        Field(controller: _nationality, label: 'Nationality', maxLength: 60),
                        Field(controller: _occupation, label: 'Occupation', maxLength: 100),
                        Field(controller: _address, label: 'Address', maxLength: 255),
                        const Text('Photo of the ID document', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: DsdColors.muted)),
                        const SizedBox(height: 6),
                        if (_photo != null)
                          ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.file(_photo!, height: 160, fit: BoxFit.cover)),
                        Row(children: [
                          Expanded(
                            child: OutlinedButton.icon(
                                onPressed: () => _pick(ImageSource.camera),
                                icon: const Icon(Icons.photo_camera_outlined, size: 18),
                                label: const Text('Camera')),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: OutlinedButton.icon(
                                onPressed: () => _pick(ImageSource.gallery),
                                icon: const Icon(Icons.photo_library_outlined, size: 18),
                                label: const Text('Gallery')),
                          ),
                        ]),
                        const SizedBox(height: 8),
                        const Text('Photos are re-encoded on our servers and stored privately.',
                            style: TextStyle(fontSize: 11.5, color: DsdColors.faint)),
                        const SizedBox(height: 14),
                        BusyButton(label: 'Submit for review', busy: _busy, onPressed: _submit),
                      ]),
                    ),
                  ],
                ]),
        ),
      ),
    );
  }
}
