import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

import '../../core/format.dart';
import '../../core/models.dart';
import '../../core/session.dart';
import '../../theme/colors.dart';
import '../../widgets/common.dart';
import '../../widgets/glass.dart';

/// Live chat with the Desderia desk. Polls every 4 seconds while open; each
/// send carries a client id so a retry after a timeout never posts twice.
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.conversationId, required this.title});
  final String conversationId;
  final String title;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> with WidgetsBindingObserver {
  final _messages = <ChatMessage>[];
  final _seen = <String>{};
  final _input = TextEditingController();
  final _scroll = ScrollController();
  Timer? _timer;
  String? _last;
  bool _sending = false;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _poll();
    _timer = Timer.periodic(const Duration(seconds: 4), (_) => _poll());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // No polling while the app is in the background.
    if (state == AppLifecycleState.resumed) {
      _timer ??= Timer.periodic(const Duration(seconds: 4), (_) => _poll());
      _poll();
    } else if (state == AppLifecycleState.paused) {
      _timer?.cancel();
      _timer = null;
    }
  }

  Future<void> _poll() async {
    try {
      final data = await context.read<Session>().api.get('conversations/${widget.conversationId}/messages/',
          query: _last == null ? null : {'after': _last!});
      final list = ((data as Map)['messages'] as List).map((e) => ChatMessage(Map<String, dynamic>.from(e as Map)));
      _add(list);
    } catch (_) {
      // Quiet: the next poll retries.
    } finally {
      if (mounted && _loading) setState(() => _loading = false);
    }
  }

  void _add(Iterable<ChatMessage> items) {
    var added = false;
    for (final m in items) {
      if (_seen.add(m.id)) {
        _messages.add(m);
        _last = m.at;
        added = true;
      }
    }
    if (added && mounted) {
      setState(() {});
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scroll.hasClients) {
          _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
        }
      });
    }
  }

  Future<void> _send() async {
    final body = _input.text.trim();
    if (body.isEmpty || _sending) return;
    setState(() => _sending = true);
    final clientId = const Uuid().v4();
    try {
      final data = await context.read<Session>().api.post('conversations/${widget.conversationId}/messages/', {
        'body': body,
        'client_id': clientId,
      });
      _input.clear();
      _add([ChatMessage(Map<String, dynamic>.from(data as Map))]);
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis)),
      body: GlassBackground(
        child: SafeArea(
          child: Column(children: [
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
                  : ListView.builder(
                      controller: _scroll,
                      padding: const EdgeInsets.fromLTRB(14, 8, 14, 8),
                      itemCount: _messages.length,
                      itemBuilder: (_, i) => _Bubble(_messages[i]),
                    ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
              decoration: const BoxDecoration(border: Border(top: BorderSide(color: DsdColors.line2))),
              child: Row(children: [
                Expanded(
                  child: TextField(
                    controller: _input,
                    minLines: 1,
                    maxLines: 4,
                    maxLength: 2000,
                    textCapitalization: TextCapitalization.sentences,
                    decoration: const InputDecoration(hintText: 'Write a message', counterText: ''),
                  ),
                ),
                const SizedBox(width: 8),
                SizedBox(
                  width: 44,
                  height: 44,
                  child: FilledButton(
                    style: FilledButton.styleFrom(padding: EdgeInsets.zero, minimumSize: const Size(44, 44)),
                    onPressed: _sending ? null : _send,
                    child: _sending
                        ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.send_rounded, size: 18),
                  ),
                ),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble(this.m);
  final ChatMessage m;

  @override
  Widget build(BuildContext context) {
    if (m.kind == 'system') {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 16),
        child: Text(m.body, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: DsdColors.faint)),
      );
    }
    final mine = m.mine;
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .78),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 4),
          padding: const EdgeInsets.fromLTRB(12, 9, 12, 7),
          decoration: BoxDecoration(
            color: mine ? const Color(0x38C9BD8C) : DsdColors.glass2,
            border: Border.all(color: mine ? DsdColors.line : DsdColors.line2),
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(14),
              topRight: const Radius.circular(14),
              bottomLeft: Radius.circular(mine ? 14 : 4),
              bottomRight: Radius.circular(mine ? 4 : 14),
            ),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SelectableText(m.body, style: const TextStyle(fontSize: 14, color: DsdColors.ivory, height: 1.4)),
            const SizedBox(height: 3),
            Text('${mine ? 'You' : m.sender}, ${clock(m.at)}', style: const TextStyle(fontSize: 10.5, color: DsdColors.muted)),
          ]),
        ),
      ),
    );
  }
}
