import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/format.dart';
import '../../core/models.dart';
import '../../core/session.dart';
import '../../theme/colors.dart';
import '../../widgets/common.dart';
import '../../widgets/glass.dart';
import 'chat_screen.dart';

class ConversationsScreen extends StatefulWidget {
  const ConversationsScreen({super.key});

  @override
  State<ConversationsScreen> createState() => _ConversationsScreenState();
}

class _ConversationsScreenState extends State<ConversationsScreen> {
  late Future<List<Conversation>> _future;
  final _subject = TextEditingController();
  final _body = TextEditingController();
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  @override
  void dispose() {
    _subject.dispose();
    _body.dispose();
    super.dispose();
  }

  Future<List<Conversation>> _load() async {
    final data = await context.read<Session>().api.get('conversations/');
    return ((data as Map)['results'] as List).map((e) => Conversation(Map<String, dynamic>.from(e as Map))).toList();
  }

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future;
  }

  Future<void> _start() async {
    setState(() => _busy = true);
    try {
      final data = await context.read<Session>().api.post('conversations/', {
        'subject': _subject.text.trim(),
        'body': _body.text.trim(),
      });
      final c = Conversation(Map<String, dynamic>.from(data as Map));
      _subject.clear();
      _body.clear();
      if (!mounted) return;
      await Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChatScreen(conversationId: c.id, title: c.subject)));
      _refresh();
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: RefreshIndicator(
        onRefresh: _refresh,
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 100), children: [
          Text('Chat with Desderia', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 4),
          const Text('Each request has its own thread. Start a general one below.', style: TextStyle(color: DsdColors.muted)),
          const SizedBox(height: 14),
          FutureBuilder<List<Conversation>>(
            future: _future,
            builder: (context, snap) {
              if (snap.hasError) return GlassCard(child: ErrorRetry(snap.error!, onRetry: _refresh));
              if (!snap.hasData) {
                return const Padding(padding: EdgeInsets.all(32), child: Center(child: CircularProgressIndicator(strokeWidth: 2)));
              }
              final items = snap.data!;
              return GlassCard(
                child: items.isEmpty
                    ? const EmptyState('No conversations yet.', icon: Icons.chat_bubble_outline)
                    : Column(children: [
                        for (final c in items)
                          ListTile(
                            contentPadding: EdgeInsets.zero,
                            onTap: () async {
                              await Navigator.of(context)
                                  .push(MaterialPageRoute(builder: (_) => ChatScreen(conversationId: c.id, title: c.subject)));
                              _refresh();
                            },
                            leading: const CircleAvatar(
                              radius: 18,
                              backgroundColor: DsdColors.glassGold,
                              child: Icon(Icons.forum_outlined, size: 18, color: DsdColors.gold2),
                            ),
                            title: Text(c.subject,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(color: DsdColors.ivory, fontWeight: FontWeight.w600)),
                            subtitle: Text('${shortDate(c.lastMessageAt)} ${clock(c.lastMessageAt)}${c.status == 'closed' ? ', closed' : ''}'),
                            trailing: c.unread > 0
                                ? Badge(label: Text('${c.unread}'), backgroundColor: DsdColors.gold, textColor: DsdColors.ink)
                                : const Icon(Icons.chevron_right),
                          ),
                      ]),
              );
            },
          ),
          const SizedBox(height: 14),
          GlassCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              const SectionTitle('Start a conversation', icon: Icons.add_comment_outlined),
              Field(controller: _subject, label: 'Subject', maxLength: 120),
              Field(controller: _body, label: 'Message', maxLines: 3, maxLength: 2000),
              BusyButton(label: 'Send', icon: Icons.send_rounded, busy: _busy, onPressed: _start),
            ]),
          ),
        ]),
      ),
    );
  }
}
