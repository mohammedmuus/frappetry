import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/models.dart';
import '../../core/session.dart';
import '../../widgets/common.dart';
import '../../widgets/glass.dart';

class BeneficiaryFormScreen extends StatefulWidget {
  const BeneficiaryFormScreen({super.key});

  @override
  State<BeneficiaryFormScreen> createState() => _BeneficiaryFormScreenState();
}

class _BeneficiaryFormScreenState extends State<BeneficiaryFormScreen> {
  final _label = TextEditingController();
  final _name = TextEditingController();
  final _bank = TextEditingController();
  final _account = TextEditingController();
  final _swift = TextEditingController();
  final _branch = TextEditingController();
  String _kind = 'bank';
  String _currency = 'TZS';
  String? _network;
  Options? _options;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    context.read<Session>().loadOptions().then((o) {
      if (mounted) setState(() => _options = o);
    });
  }

  @override
  void dispose() {
    for (final c in [_label, _name, _bank, _account, _swift, _branch]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    setState(() => _busy = true);
    try {
      await context.read<Session>().api.post('beneficiaries/', {
        'kind': _kind,
        'label': _label.text.trim(),
        'currency': _kind == 'mobile' ? 'TZS' : _currency,
        'account_name': _name.text.trim(),
        'bank_name': _kind == 'bank' ? _bank.text.trim() : '',
        'account_number': _account.text.trim(),
        'swift_code': _kind == 'bank' ? _swift.text.trim() : '',
        'branch': _kind == 'bank' ? _branch.text.trim() : '',
        'mobile_network': _kind == 'mobile' ? (_network ?? '') : '',
      });
      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final o = _options;
    return Scaffold(
      appBar: AppBar(title: const Text('Add beneficiary')),
      body: GlassBackground(
        child: SafeArea(
          child: o == null
              ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
              : ListView(padding: const EdgeInsets.all(16), children: [
                  SegmentedButton<String>(
                    segments: const [
                      ButtonSegment(value: 'bank', label: Text('Bank account')),
                      ButtonSegment(value: 'mobile', label: Text('Mobile money')),
                    ],
                    selected: {_kind},
                    showSelectedIcon: false,
                    onSelectionChanged: (s) => setState(() => _kind = s.first),
                  ),
                  const SizedBox(height: 14),
                  GlassCard(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      Field(controller: _label, label: 'Label', hint: 'For example: My CRDB USD', maxLength: 60),
                      if (_kind == 'bank')
                        Dropdown<String>(
                          label: 'Currency',
                          value: _currency,
                          items: [
                            for (final c in o.currencies) DropdownMenuItem(value: c['code'] as String, child: Text(c['code'] as String)),
                          ],
                          onChanged: (v) => setState(() => _currency = v ?? 'TZS'),
                        ),
                      Field(controller: _name, label: 'Account holder name', maxLength: 120),
                      Field(
                        controller: _account,
                        label: _kind == 'bank' ? 'Account number' : 'Mobile number',
                        keyboard: _kind == 'bank' ? TextInputType.text : TextInputType.phone,
                        maxLength: 40,
                      ),
                      if (_kind == 'bank') ...[
                        Field(controller: _bank, label: 'Bank name', maxLength: 120),
                        Field(controller: _swift, label: 'SWIFT or BIC (required for foreign currency)', maxLength: 11),
                        Field(controller: _branch, label: 'Branch (optional)', maxLength: 80),
                      ] else
                        Dropdown<String>(
                          label: 'Mobile network',
                          value: _network,
                          items: [for (final n in o.networks) DropdownMenuItem(value: n[0], child: Text(n[1]))],
                          onChanged: (v) => setState(() => _network = v),
                        ),
                      const SizedBox(height: 6),
                      BusyButton(label: 'Save beneficiary', busy: _busy, onPressed: _save),
                    ]),
                  ),
                ]),
        ),
      ),
    );
  }
}
