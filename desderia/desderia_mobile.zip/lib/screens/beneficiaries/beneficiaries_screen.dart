import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/models.dart';
import '../../core/session.dart';
import '../../theme/colors.dart';
import '../../widgets/common.dart';
import '../../widgets/glass.dart';
import 'beneficiary_form_screen.dart';

class BeneficiariesScreen extends StatefulWidget {
  const BeneficiariesScreen({super.key});

  @override
  State<BeneficiariesScreen> createState() => _BeneficiariesScreenState();
}

class _BeneficiariesScreenState extends State<BeneficiariesScreen> {
  late Future<List<Beneficiary>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Beneficiary>> _load() async {
    final data = await context.read<Session>().api.get('beneficiaries/');
    return ((data as Map)['results'] as List).map((e) => Beneficiary(Map<String, dynamic>.from(e as Map))).toList();
  }

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future;
  }

  Future<void> _remove(Beneficiary b) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: DsdColors.ink3,
        title: const Text('Remove beneficiary?'),
        content: Text(b.display),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Keep')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Remove')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    try {
      await context.read<Session>().api.delete('beneficiaries/${b.id}/');
      _refresh();
    } catch (e) {
      if (mounted) toast(context, errorText(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Beneficiaries')),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: DsdColors.gold,
        foregroundColor: DsdColors.ink,
        onPressed: () async {
          final added = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => const BeneficiaryFormScreen()));
          if (added == true) _refresh();
        },
        icon: const Icon(Icons.add, size: 18),
        label: const Text('Add'),
      ),
      body: GlassBackground(
        child: SafeArea(
          child: RefreshIndicator(
            onRefresh: _refresh,
            child: FutureBuilder<List<Beneficiary>>(
              future: _future,
              builder: (context, snap) {
                if (snap.hasError) return ErrorRetry(snap.error!, onRetry: _refresh);
                if (!snap.hasData) return const Center(child: CircularProgressIndicator(strokeWidth: 2));
                final items = snap.data!;
                return ListView(padding: const EdgeInsets.all(16), children: [
                  GlassCard(
                    child: items.isEmpty
                        ? const EmptyState('No beneficiaries yet.', icon: Icons.account_balance_outlined)
                        : Column(children: [
                            for (final b in items)
                              ListTile(
                                contentPadding: EdgeInsets.zero,
                                leading: CurrencyChip(b.currency),
                                title: Text(b.label, style: const TextStyle(color: DsdColors.ivory, fontWeight: FontWeight.w600)),
                                subtitle: Text(b.display, maxLines: 1, overflow: TextOverflow.ellipsis),
                                trailing: IconButton(
                                  tooltip: 'Remove',
                                  icon: const Icon(Icons.delete_outline, color: DsdColors.bad),
                                  onPressed: () => _remove(b),
                                ),
                              ),
                          ]),
                  ),
                ]);
              },
            ),
          ),
        ),
      ),
    );
  }
}
