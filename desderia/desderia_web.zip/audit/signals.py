from django.contrib.auth.signals import user_logged_in, user_logged_out, user_login_failed
from django.dispatch import receiver

from .services import record


@receiver(user_logged_in)
def on_login(sender, request, user, **kwargs):
    record("auth.login", user, f"{user.email} signed in", actor=user, request=request)


@receiver(user_logged_out)
def on_logout(sender, request, user, **kwargs):
    if user is not None:
        record("auth.logout", user, f"{user.email} signed out", actor=user, request=request)


@receiver(user_login_failed)
def on_login_failed(sender, credentials, request=None, **kwargs):
    who = (credentials or {}).get("username", "")
    record("auth.login_failed", None, f"Failed sign in for {who}"[:255], data={"username": who},
           request=request)
