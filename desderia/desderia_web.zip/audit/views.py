import csv

from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, render
from django.utils import timezone
from django.utils.dateparse import parse_date

from desk.views import csv_safe

from .models import AuditEntry
from .services import record, verify_chain


def _filtered(request):
    qs = AuditEntry.objects.select_related("actor")
    q = request.GET.get("q", "").strip()[:80]
    action = request.GET.get("action", "").strip()[:64]
    start = parse_date(request.GET.get("from", "") or "")
    end = parse_date(request.GET.get("to", "") or "")
    if q:
        qs = qs.filter(Q(summary__icontains=q) | Q(actor_label__icontains=q) | Q(object_id__icontains=q)
                       | Q(ip_address__icontains=q))
    if action:
        qs = qs.filter(action__startswith=action)
    if start:
        qs = qs.filter(at__date__gte=start)
    if end:
        qs = qs.filter(at__date__lte=end)
    return qs


@login_required
def audit_list(request):
    qs = _filtered(request)
    if request.GET.get("export") == "csv":
        record("export.audit", None, "Audit trail exported", data={"filter": request.GET.dict()})
        response = HttpResponse(content_type="text/csv")
        response["Content-Disposition"] = f'attachment; filename="desderia-audit-{timezone.localdate()}.csv"'
        w = csv.writer(response)
        w.writerow(["Seq", "Time", "Actor", "Role", "Channel", "IP", "Action", "Object", "Summary", "Hash"])
        for e in qs[:20000]:
            w.writerow([csv_safe(x) for x in (e.seq, timezone.localtime(e.at).isoformat(), e.actor_label,
                                               e.actor_role, e.channel, e.ip_address, e.action,
                                               f"{e.object_type} {e.object_id}", e.summary, e.hash)])
        return response
    page = Paginator(qs, 40).get_page(request.GET.get("page"))
    actions = ["auth", "account", "kyc", "request", "offer", "payment", "rate", "chat", "export", "otp"]
    return render(request, "audit_list.html", {"page": page, "actions": actions, "params": request.GET})


@login_required
def audit_detail(request, seq):
    entry = get_object_or_404(AuditEntry, seq=seq)
    return render(request, "audit_detail.html", {"e": entry, "valid": entry.compute_hash() == entry.hash})


@login_required
def audit_verify(request):
    ok, checked, bad, reason = verify_chain()
    record("audit.verified", None, f"Chain verification: {'intact' if ok else 'BROKEN'}",
           data={"checked": checked, "bad": bad, "reason": reason})
    return render(request, "audit_verify.html", {"ok": ok, "checked": checked, "bad": bad, "reason": reason})
