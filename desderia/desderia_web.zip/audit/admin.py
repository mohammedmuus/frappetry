from django.contrib import admin

from desderia.admin_mixins import ReadOnlyAdmin

from .models import AuditEntry, AuditHead


@admin.register(AuditEntry)
class AuditEntryAdmin(ReadOnlyAdmin, admin.ModelAdmin):
    list_display = ["seq", "at", "actor_label", "actor_role", "channel", "action", "summary", "ip_address"]
    list_filter = ["channel", "actor_role", "object_type"]
    search_fields = ["summary", "actor_label", "object_id", "action", "ip_address"]
    date_hierarchy = "at"


@admin.register(AuditHead)
class AuditHeadAdmin(ReadOnlyAdmin, admin.ModelAdmin):
    list_display = ["id", "count", "last_hash"]
