from django.urls import path

from . import views

app_name = "audit"

urlpatterns = [
    path("", views.audit_list, name="list"),
    path("verify/", views.audit_verify, name="verify"),
    path("<int:seq>/", views.audit_detail, name="detail"),
]
