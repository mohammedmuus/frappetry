from django.core.management.base import BaseCommand, CommandError

from audit.services import verify_chain


class Command(BaseCommand):
    help = "Verify the audit hash chain. Exit code 1 when tampering is detected."

    def handle(self, *args, **options):
        ok, checked, bad_seq, reason = verify_chain()
        if ok:
            self.stdout.write(self.style.SUCCESS(f"Audit chain intact: {checked} entries verified."))
            return
        raise CommandError(f"Audit chain BROKEN at entry {bad_seq}: {reason}. {checked} entries verified before it.")
