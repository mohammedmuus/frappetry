import json
import logging

from django.db import transaction
from django.utils import timezone

from desderia.middleware import client_ip, current_request

from .models import AuditEntry, AuditHead

log = logging.getLogger("desderia.security")


def _clean(data):
    # Round trip through JSON so the stored value hashes the same on read.
    return json.loads(json.dumps(data or {}, default=str))


def record(action, obj=None, summary="", data=None, actor=None, request=None, channel=None):
    """Append one entry to the hash chain. Call inside the business transaction
    so an action and its audit row commit or roll back together."""
    request = request or current_request()
    if actor is None and request is not None:
        user = getattr(request, "user", None)
        actor = user if user is not None and user.is_authenticated else None
    if channel is None:
        channel = "api" if request is not None and request.path_info.startswith("/api/") else (
            "web" if request is not None else "system")

    with transaction.atomic():
        head, _ = AuditHead.objects.select_for_update().get_or_create(id=1)
        entry = AuditEntry(
            seq=head.count + 1,
            at=timezone.now(),
            actor=actor,
            actor_label=getattr(actor, "email", "") or "system",
            actor_role=("superuser" if getattr(actor, "is_superuser", False) else getattr(actor, "role", "")) or "",
            ip_address=client_ip(request),
            user_agent=(request.META.get("HTTP_USER_AGENT", "")[:255] if request is not None else ""),
            channel=channel,
            action=action,
            object_type=obj.__class__.__name__ if obj is not None else "",
            object_id=str(getattr(obj, "pk", "") or "") if obj is not None else "",
            summary=(summary or action)[:255],
            data=_clean(data),
            prev_hash=head.last_hash,
        )
        entry.hash = entry.compute_hash()
        entry.save()
        AuditHead.objects.filter(id=1).update(last_hash=entry.hash, count=entry.seq)
    return entry


def verify_chain():
    """Walk the chain oldest first. Returns (ok, checked, first_bad_seq, reason)."""
    prev = "0" * 64
    expected_seq = 1
    checked = 0
    for entry in AuditEntry.objects.order_by("seq").iterator(chunk_size=2000):
        if entry.seq != expected_seq:
            return False, checked, expected_seq, "missing entry (sequence gap)"
        if entry.prev_hash != prev:
            return False, checked, entry.seq, "previous hash does not match"
        if entry.compute_hash() != entry.hash:
            return False, checked, entry.seq, "entry content was altered"
        prev = entry.hash
        expected_seq += 1
        checked += 1
    head = AuditHead.objects.filter(id=1).first()
    if head and (head.count != checked or head.last_hash != prev):
        return False, checked, checked + 1, "trailing entries were removed"
    return True, checked, None, ""
