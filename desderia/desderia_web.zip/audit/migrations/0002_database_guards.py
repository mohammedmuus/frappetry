"""
Database level guards. These hold even if application code is bypassed
(a raw SQL console, a compromised admin, a buggy script):

- audit entries, rate history, request timelines and chat messages can
  never be edited or deleted
- exchange requests and payments can never be deleted
- a PAID payment is frozen
- a request in a final state (completed, cancelled, rejected, expired)
  is frozen
"""

from django.db import migrations

APPEND_ONLY = ["audit_auditentry", "rates_exchangerate", "exchange_statusevent", "support_message"]
NO_DELETE = ["exchange_exchangerequest", "payments_payment", "exchange_offer", "payments_gatewayevent"]

FROZEN_RULES = [
    ("payments_payment", "OLD.status = 'paid'", "paid payments are immutable"),
    ("exchange_exchangerequest", "OLD.status IN ('completed','cancelled','rejected','expired')",
     "closed exchange requests are immutable"),
]


def _sqlite(schema_editor, forward):
    run = schema_editor.execute
    for table in APPEND_ONLY:
        for op in ("UPDATE", "DELETE"):
            name = f"guard_{table}_{op.lower()}"
            run(f"DROP TRIGGER IF EXISTS {name}")
            if forward:
                run(f"CREATE TRIGGER {name} BEFORE {op} ON {table} BEGIN "
                    f"SELECT RAISE(ABORT, '{table} is append only'); END")
    for table in NO_DELETE:
        name = f"guard_{table}_delete"
        run(f"DROP TRIGGER IF EXISTS {name}")
        if forward:
            run(f"CREATE TRIGGER {name} BEFORE DELETE ON {table} BEGIN "
                f"SELECT RAISE(ABORT, '{table} rows cannot be deleted'); END")
    for table, cond, msg in FROZEN_RULES:
        name = f"guard_{table}_frozen"
        run(f"DROP TRIGGER IF EXISTS {name}")
        if forward:
            run(f"CREATE TRIGGER {name} BEFORE UPDATE ON {table} WHEN {cond} BEGIN "
                f"SELECT RAISE(ABORT, '{msg}'); END")


def _postgres(schema_editor, forward):
    run = schema_editor.execute
    if forward:
        run("""
        CREATE OR REPLACE FUNCTION desderia_refuse() RETURNS trigger AS $$
        BEGIN
            RAISE EXCEPTION 'desderia guard: % on % refused (%)', TG_OP, TG_TABLE_NAME, TG_ARGV[0];
        END; $$ LANGUAGE plpgsql;
        """)
    for table in APPEND_ONLY:
        run(f"DROP TRIGGER IF EXISTS guard_append_only ON {table}")
        if forward:
            run(f"CREATE TRIGGER guard_append_only BEFORE UPDATE OR DELETE ON {table} "
                f"FOR EACH ROW EXECUTE FUNCTION desderia_refuse('append only')")
    for table in NO_DELETE:
        run(f"DROP TRIGGER IF EXISTS guard_no_delete ON {table}")
        if forward:
            run(f"CREATE TRIGGER guard_no_delete BEFORE DELETE ON {table} "
                f"FOR EACH ROW EXECUTE FUNCTION desderia_refuse('no delete')")
    for table, cond, msg in FROZEN_RULES:
        run(f"DROP TRIGGER IF EXISTS guard_frozen ON {table}")
        if forward:
            run(f"CREATE TRIGGER guard_frozen BEFORE UPDATE ON {table} FOR EACH ROW "
                f"WHEN ({cond}) EXECUTE FUNCTION desderia_refuse('{msg}')")
    if not forward:
        run("DROP FUNCTION IF EXISTS desderia_refuse()")


def forwards(apps, schema_editor):
    vendor = schema_editor.connection.vendor
    if vendor == "sqlite":
        _sqlite(schema_editor, True)
    elif vendor == "postgresql":
        _postgres(schema_editor, True)


def backwards(apps, schema_editor):
    vendor = schema_editor.connection.vendor
    if vendor == "sqlite":
        _sqlite(schema_editor, False)
    elif vendor == "postgresql":
        _postgres(schema_editor, False)


class Migration(migrations.Migration):
    dependencies = [
        ("audit", "0001_initial"),
        ("rates", "0001_initial"),
        ("exchange", "0001_initial"),
        ("payments", "0001_initial"),
        ("support", "0001_initial"),
    ]

    operations = [migrations.RunPython(forwards, backwards)]
