import hashlib
import json

from django.conf import settings
from django.db import models


# ─────────────────────────────────────────────────────────────
# TAMPER EVIDENT AUDIT TRAIL
# ─────────────────────────────────────────────────────────────
# Every bureau action becomes one row. Each row stores the SHA-256 of its
# own content plus the hash of the row before it, so editing or deleting
# any historic row breaks every hash after it and verify_audit reports the
# exact position. Rows refuse update and delete in Python, and on
# PostgreSQL a trigger (migration 0002) refuses them at the database too.

class AuditHead(models.Model):
    """Single row locked with SELECT FOR UPDATE to serialise chain appends."""

    id = models.PositiveSmallIntegerField(primary_key=True, default=1)
    last_hash = models.CharField(max_length=64, default="0" * 64)
    count = models.PositiveBigIntegerField(default=0)

    class Meta:
        constraints = [models.CheckConstraint(condition=models.Q(id=1), name="audit_head_singleton")]


class AuditEntry(models.Model):
    seq = models.PositiveBigIntegerField(unique=True)
    at = models.DateTimeField(db_index=True)
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True,
                              on_delete=models.PROTECT, related_name="audit_entries")
    actor_label = models.CharField(max_length=254, blank=True)
    actor_role = models.CharField(max_length=12, blank=True)
    ip_address = models.CharField(max_length=45, blank=True)
    user_agent = models.CharField(max_length=255, blank=True)
    channel = models.CharField(max_length=8, default="web")
    action = models.CharField(max_length=64, db_index=True)
    object_type = models.CharField(max_length=64, blank=True, db_index=True)
    object_id = models.CharField(max_length=64, blank=True, db_index=True)
    summary = models.CharField(max_length=255)
    data = models.JSONField(default=dict, blank=True)
    prev_hash = models.CharField(max_length=64)
    hash = models.CharField(max_length=64, unique=True)

    class Meta:
        ordering = ["-seq"]
        verbose_name_plural = "audit entries"

    def __str__(self):
        return f"#{self.seq} {self.action} {self.summary}"

    def canonical(self):
        return json.dumps({
            "seq": self.seq,
            "at": self.at.isoformat(),
            "actor": str(self.actor_id or ""),
            "actor_label": self.actor_label,
            "actor_role": self.actor_role,
            "ip": self.ip_address,
            "channel": self.channel,
            "action": self.action,
            "object_type": self.object_type,
            "object_id": self.object_id,
            "summary": self.summary,
            "data": self.data,
            "prev": self.prev_hash,
        }, sort_keys=True, separators=(",", ":"), default=str)

    def compute_hash(self):
        return hashlib.sha256(self.canonical().encode("utf-8")).hexdigest()

    def save(self, *args, **kwargs):
        if not self._state.adding:
            raise PermissionError("Audit entries are append only")
        super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        raise PermissionError("Audit entries cannot be deleted")
