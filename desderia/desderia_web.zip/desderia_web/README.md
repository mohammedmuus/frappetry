# Desderia Bureau De Change: web platform

Django 5.2 web app and REST API for Desderia Bureau De Change. Customers request currency exchanges online at live rates, negotiate larger amounts, pay by CashPay, bank transfer or cash, and receive money by bank wire, mobile money or cash pickup. Staff run everything from the desk, and every action is written to a tamper evident audit trail.

The mobile app (`desderia_mobile.zip`) talks to the same server through the API in `api/`. How the two connect is in [API.md](API.md). How the business runs day to day on both apps is in [OPERATIONS.md](OPERATIONS.md).

## Quick start (local)

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
echo "DJANGO_DEBUG=1" > .env
python manage.py migrate
python manage.py seed_desderia --demo      # currencies, opening rates, demo staff, opening floats
python manage.py createsuperuser           # your management portal login
python manage.py runserver
```

On Windows (PowerShell):

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Set-Content -Path .env -Value "DJANGO_DEBUG=1" -Encoding ascii
python manage.py migrate
python manage.py seed_desderia --demo
python manage.py createsuperuser
python manage.py runserver
```

Open http://127.0.0.1:8000. Codes for sign in and verification print in the terminal (console email and SMS backends). The demo command prints the demo passwords. Never run `--demo` in production.

## Apps

| App | Purpose |
|---|---|
| `accounts` | Email login, required phone, two step sign in, email and phone verification, KYC with private document photos, device tokens |
| `rates` | Currencies and the append only rate board |
| `exchange` | Exchange requests, the state machine (`services.py`), negotiation offers, beneficiaries, timeline |
| `payments` | Payment records, CashPay USSD push and callback, manual bank and cash confirmation |
| `treasury` | Currency balances and the ledger, float movements, branded Excel reports |
| `support` | Chat between customers and the desk (one thread per request plus general threads) |
| `notifications` | In app notifications, automated emails for every status change, email log |
| `audit` | Hash chained audit trail, chain verification, CSV export |
| `desk` | Staff screens: queue, request actions, KYC review, rates, customers, chat inbox, payments |
| `pages` | Public site: home, rate board, contact form with automatic reply, terms, privacy |
| `api` | REST API for the Flutter app (expiring bearer tokens, throttles) |

## Roles

| Role | Can use |
|---|---|
| Customer | `/exchange/` area and the mobile app |
| Teller | Desk: queue, approve, negotiate, confirm funds, pay out, KYC review, chat, balances (view) |
| Manager | Everything a teller can, plus publishing rates, float movements, reports, audit trail |
| Auditor | Audit trail, chain verification, reports. Read only |
| Admin or superuser | All of the above plus the management portal at `/management/` |

Access is enforced on the server by `desderia/middleware.py` (ModuleAccessMiddleware), not by hiding links.

## Security summary

- Passwords hashed with Argon2. Minimum 10 characters, common passwords refused.
- Two step sign in for everyone: password, then a six digit code by email or SMS. Codes are stored as keyed hashes, expire in 10 minutes, allow 5 guesses and are single use.
- Login lockout: 5 failures per email or 10 per IP in 5 minutes locks for 5 minutes, on web and API. The correct password is also refused during lockout.
- Every form is rate limited per user or IP (`desderia/guards.py`). The API has DRF throttles per scope.
- Strict Content Security Policy with per request nonces and no inline scripts or styles. HSTS, secure cookies, SSL redirect and frame denial switch on automatically when `DEBUG` is off.
- The app refuses to boot in production without `DJANGO_SECRET_KEY`. No secret has a default.
- Idle sessions end after 30 minutes. Mobile tokens expire after 72 hours, are stored hashed, and are revoked on sign out and on password change.
- Customer IP and user agent are recorded on every audit entry.
- The management portal lives at `/management/`, uses the same two step sign in, and is limited to superusers and admins. User and group editing is superuser only, so staff cannot grant themselves rights.
- KYC photos are re-encoded on upload and served only through an ownership check, never from a public URL.

## No double payments, no double entries

Enforced at the database, not only in Python:

- One PAID payment per request, one PENDING payment per request (`payments_payment` partial unique indexes).
- A bank, mobile money or gateway reference can settle exactly one request (`request_funding_ref_unique`, `payment_txid_unique`).
- A request can move money in once and out once (`ledger_one_movement_per_request_kind`).
- Webhook retries are ignored by `UniqueConstraint(gateway, event_reference)`.
- Exchange requests carry a client generated `idempotency_key`, so a double tap or a retried API call returns the same request.
- Chat messages carry a `client_id` for the same reason.
- Web forms lock their submit buttons on first submit (`static/js/app.js`).
- Every money transition takes a row lock (`select_for_update`) and checks the allowed transition table.
- Database triggers (migrations `audit/0002`, `treasury/0002`) make audit entries, ledger lines, rate history, timelines, chat and the email log append only, forbid deleting requests and payments, and freeze PAID payments and closed requests. These hold even against raw SQL.
- Large payouts need a second staff member (`DUAL_CONTROL_THRESHOLD_TZS`), and a payout is refused if the currency float would go negative.

## Payments (CashPay)

Implemented against the CashPay Merchant API v1 (copy in `docs/cashpay_merchant_api.md`), in `payments/gateways.py` and `payments/services.py`:

1. **Token.** `POST /get-token` with the merchant username and password. The JWT lives 5 minutes; it is cached for 4 and fetched again automatically on any 401.
2. **Reference.** `POST /generate` with our `transactionNumber` (the alphanumeric payment reference, unique per attempt). CashPay returns its `referenceNumber` (starts with 50), stored on the payment.
3. **Prompt.** `POST /ussdpush` with the customer's wallet (`255XXXXXXXXX`) and the amount in whole shillings, rounded up so the bureau is never short. The customer approves with their PIN.
4. **Callback.** CashPay posts the result to `https://YOUR_DOMAIN/payments/cashpay/callback/<CASHPAY_CALLBACK_SECRET>/`. Register exactly that URL with CashPay support.

CashPay callbacks are not signed, so a callback settles money only when all of these hold: it arrives on the secret path (anything else gets a 404), from an allowed IP when `CASHPAY_ALLOWED_IPS` is set, its `transactionNumber` is ours, its `referenceNumber`, `amount` and `phone` match what we sent, and its `receiptNumber` has never settled anything before. Anything else is stored in Gateway events and flagged to staff, never settled. Retries of the same callback are ignored. `FAILED` marks the attempt failed and tells the customer they can send a new prompt.

A customer can ask for a new prompt after 2 minutes. The old attempt is cancelled and a new `transactionNumber` is used, because CashPay refuses duplicates. If the customer then approves both prompts, the first one to arrive settles the request and the second is flagged to managers as money to refund.

Settings: `CASHPAY_USERNAME`, `CASHPAY_PASSWORD`, `CASHPAY_CALLBACK_SECRET` (long random value), optional `CASHPAY_ALLOWED_IPS` (ask CashPay for their callback IPs) and `CASHPAY_BASE_URL`. Until the first three are set the CashPay option reports itself unavailable and the callback answers 503.

### Phone numbers

Every Tanzanian mobile number is accepted for registration and payouts: all 06x and 07x ranges in the TCRA numbering plan (Halotel 61, 62; Yas 65, 67, 71, 77; Airtel 68, 69, 78; TTCL 73; Vodacom 74, 75, 76, 79), in any format (`0754...`, `+255 754...`, `255754...`). Operators get new ranges over time, so the table lives in **Management, Mobile prefixes**: add a row (for example `785`, Airtel, Airtel Money) the day a range launches and it is recognised at once, with no code change. The longest matching prefix wins. CashPay prompts are refused only for prefixes marked "CashPay supported: no" (HaloPesa and T-Pesa today); a range not yet in the table is passed to CashPay, which decides.

## Fast pages and CDN

- HTML is minified on the fly (`HtmlMinifyMiddleware`), CSS and JS are minified by `python build_assets.py` (uses esbuild when Node is present).
- Icons are one inline SVG sprite, fonts are self hosted, no third party scripts.
- `whitenoise` serves compressed, content hashed static files with one year cache headers. To use a CDN, point a pull zone at `https://YOUR_DOMAIN/static/` and set `DESDERIA_CDN_URL`; the CSP allows that host automatically.

## Production deployment

Files in `deploy/`:

| File | What it does |
|---|---|
| `nginx-desderia.conf`, `desderia-proxy.conf` | TLS, HTTP to HTTPS, rate limit zones for auth and API, long cache for static, private media blocked |
| `gunicorn.service` | systemd unit with sandboxing options |
| `firewall.sh` | ufw: deny all inbound except rate limited SSH, 80 and 443 |
| `fail2ban-desderia.conf` | Bans IPs that keep tripping the lockout, throttles or CashPay callback checks |
| `postgres-setup.sql` | Separate owner and app roles, the app role cannot update or delete history tables |
| `crontab.txt` | Expire unfunded requests, nightly audit chain verification, nightly database backup |

Steps:

1. Ubuntu server, PostgreSQL, Redis, Nginx, Python 3.11+.
2. Run `deploy/postgres-setup.sql` (change the passwords).
3. Copy the project to `/srv/desderia/app`, create the venv, `pip install -r requirements.txt`.
4. Put the variables from `.env.example` in `/etc/desderia/desderia.env` with real values.
5. `python manage.py migrate` (as the owner role), `python manage.py collectstatic`, `python manage.py seed_desderia`, `python manage.py createsuperuser`.
6. `python manage.py check --deploy` must report no issues.
7. Install the systemd unit, Nginx config, firewall, fail2ban and crontab.
8. `python check_templates.py` and `python manage.py test` before every release.

Note: the firewall rules from the Mavuno server conversations were not available to this build. `deploy/firewall.sh` and the Nginx limits are a standard hardened baseline; merge any server specific rules you already use there.

## Tests

```bash
python manage.py test        # 55 tests: access matrix, two step login, lockouts, full money lifecycle,
                             # negotiation, double payment guards, database triggers, webhook
                             # callbacks, forgeries and retries, phone prefixes, chat idempotency, ledger, reports, management
                             # portal, database backup download, backup one time codes, and the complete mobile app journey through the API
python check_templates.py    # no inline handlers or styles, no multi line template comments,
                             # no emojis or long dashes
```

## Screenshots

See `docs/screenshots/`.
