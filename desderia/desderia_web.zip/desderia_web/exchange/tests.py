import json
import uuid
from decimal import Decimal

from django.core.cache import cache
from django.db import IntegrityError, transaction
from django.test import TestCase, override_settings
from django.utils import timezone

from accounts.models import User
from accounts.tests import make_user
from audit.models import AuditEntry
from audit.services import verify_chain
from payments.models import GatewayEvent, Payment
from rates.models import Currency, ExchangeRate
from support.models import Conversation
from support.services import post_message

from . import services
from .models import ExchangeRequest

SECRET = "test-webhook-secret-123"


class Base(TestCase):
    def setUp(self):
        cache.clear()
        self.manager = make_user("mgr@x.test", role="manager")
        self.teller = make_user("tel@x.test", role="teller")
        self.teller2 = make_user("tel2@x.test", role="teller")
        self.customer = make_user("c@x.test")
        Currency.objects.create(code="TZS", name="Tanzanian Shilling")
        self.usd = Currency.objects.create(code="USD", name="US Dollar", min_negotiable_amount=Decimal("1000"))
        ExchangeRate.objects.create(currency=self.usd, buy_rate=Decimal("2575"), sell_rate=Decimal("2615"),
                                    effective_at=timezone.now(), set_by=self.manager)
        from treasury.services import post
        post("USD", "in", "opening", "1000000", self.manager, note="Test float")

    def new_request(self, amount="500", key=None, funding="bank_transfer"):
        req, _ = services.create_request(
            self.customer, direction="buy", currency_code="USD", amount=Decimal(amount), funding_method=funding,
            payout_method="cash_pickup", purpose="travel", source_of_funds="Salary",
            idempotency_key=key or uuid.uuid4())
        return req


class LifecycleTests(Base):
    def test_full_lifecycle_with_dual_control_and_audit(self):
        req = self.new_request("1000")
        self.assertEqual(req.local_amount, Decimal("2615000.00"))
        services.approve(req, self.teller)
        req.refresh_from_db()
        self.assertEqual(req.status, "approved")
        services.confirm_funds(req, self.teller, "bank-ref-001")
        req.refresh_from_db()
        self.assertEqual(req.funding_reference, "BANK-REF-001")
        with self.settings(DUAL_CONTROL_THRESHOLD_TZS=1_000_000):
            with self.assertRaisesMessage(services.ExchangeError, "Dual control"):
                services.mark_paid_out(req, self.teller, "WIRE-1")
            services.mark_paid_out(req, self.teller2, "WIRE-1")
        services.complete(req, self.customer)
        req.refresh_from_db()
        self.assertEqual(req.status, "completed")
        self.assertEqual(list(req.events.values_list("to_status", flat=True)),
                         ["submitted", "approved", "funded", "paid_out", "completed"])
        ok, checked, _, _ = verify_chain()
        self.assertTrue(ok)
        self.assertGreaterEqual(checked, 5)

    def test_idempotent_create(self):
        key = uuid.uuid4()
        a = self.new_request(key=key)
        b = self.new_request(key=key)
        self.assertEqual(a.pk, b.pk)
        self.assertEqual(ExchangeRequest.objects.count(), 1)

    def test_illegal_transition_refused(self):
        req = self.new_request()
        with self.assertRaises(services.ExchangeError):
            services.mark_paid_out(req, self.teller, "X")

    def test_staff_cannot_approve_own_request(self):
        req = self.new_request()
        self.customer.role = "teller"
        self.customer.save()
        with self.assertRaises(services.ExchangeError):
            services.approve(req, self.customer)

    def test_kyc_limit(self):
        with self.assertRaisesMessage(services.ExchangeError, "KYC"):
            self.new_request("5000")


class NegotiationTests(Base):
    def approve_kyc(self):
        from accounts.models import KycProfile
        KycProfile.objects.create(user=self.customer, legal_name="C Test", id_type="nida", id_number="1",
                                  date_of_birth="1990-01-01", address="Dar", occupation="Trader",
                                  status="approved", reviewed_by=self.manager)

    def test_band_and_agreement(self):
        self.approve_kyc()
        req = self.new_request("2000")
        with self.assertRaises(services.ExchangeError):
            services.make_offer(req, self.customer, Decimal("2400"))   # far below the band
        offer = services.make_offer(req, self.customer, Decimal("2600"), "Regular client")
        req.refresh_from_db()
        self.assertEqual(req.status, "negotiating")
        with self.assertRaises(services.ExchangeError):
            services.respond_offer(req, offer.pk, self.customer, True)  # cannot accept own offer
        services.respond_offer(req, offer.pk, self.teller, True)
        req.refresh_from_db()
        self.assertEqual(req.status, "approved")
        self.assertEqual(req.agreed_rate, Decimal("2600"))
        self.assertEqual(req.local_amount, Decimal("5200000.00"))

    def test_small_amount_not_negotiable(self):
        req = self.new_request("200")
        with self.assertRaisesMessage(services.ExchangeError, "Negotiation"):
            services.make_offer(req, self.customer, Decimal("2600"))


class DoubleEntryTests(Base):
    def test_reference_settles_one_request_only(self):
        a, b = self.new_request(), self.new_request()
        services.approve(a, self.teller)
        services.approve(b, self.teller)
        services.confirm_funds(a, self.teller, "REF-777")
        with self.assertRaisesMessage(services.ExchangeError, "already been used"):
            services.confirm_funds(b, self.teller, "ref-777")

    def test_confirm_twice_is_refused(self):
        req = self.new_request()
        services.approve(req, self.teller)
        services.confirm_funds(req, self.teller, "REF-1")
        with self.assertRaises(services.ExchangeError):
            services.confirm_funds(req, self.teller2, "REF-2")
        self.assertEqual(Payment.objects.filter(request=req, status="paid").count(), 1)

    def test_database_refuses_second_paid_payment(self):
        req = self.new_request()
        services.approve(req, self.teller)
        services.confirm_funds(req, self.teller, "REF-9")
        with self.assertRaises(IntegrityError), transaction.atomic():
            Payment.objects.create(request=req, gateway="manual", amount=1, currency="TZS", reference="X-1",
                                   status="paid", settled_txid="OTHER", paid_at=timezone.now(), created_by=self.teller)


class DatabaseGuardTests(Base):
    def test_audit_rows_are_immutable_in_the_database(self):
        self.new_request()
        entry = AuditEntry.objects.first()
        with self.assertRaises(Exception), transaction.atomic():
            AuditEntry.objects.filter(pk=entry.pk).update(summary="edited")
        with self.assertRaises(Exception), transaction.atomic():
            AuditEntry.objects.filter(pk=entry.pk).delete()

    def test_closed_request_is_frozen(self):
        req = self.new_request()
        services.cancel(req, self.customer)
        with self.assertRaises(Exception), transaction.atomic():
            ExchangeRequest.objects.filter(pk=req.pk).update(foreign_amount=1)

    def test_rates_are_append_only(self):
        rate = ExchangeRate.objects.first()
        with self.assertRaises(Exception), transaction.atomic():
            ExchangeRate.objects.filter(pk=rate.pk).update(sell_rate=1)


CASHPAY = dict(CASHPAY_USERNAME="merchant@desderia.test", CASHPAY_PASSWORD="pw", CASHPAY_CALLBACK_SECRET=SECRET,
               CASHPAY_ALLOWED_IPS=[], ALLOWED_HOSTS=["testserver"])


class FakeCashPay:
    """Stands in for https://cashpay.co.tz/api/reference, following the merchant docs."""

    def __init__(self):
        self.calls = []
        self.token_valid = True
        self.push_fails = None
        self.ref = 50000000

    def __call__(self, gateway, path, payload):
        self.calls.append((path, payload))
        if path == "get-token":
            self.token_valid = True
            return 200, {"token": "jwt-token"}
        if not self.token_valid:
            return 401, {"description": "Unauthorized", "code": "401", "message": "Invalid token"}
        req = payload["body"]["request"]
        if path == "generate":
            self.ref += 1
            return 201, {"description": "Success", "code": "1", "referenceNumber": str(self.ref),
                         "transactionNumber": req["transactionNumber"], "message": "Successfully Created"}
        if path == "ussdpush":
            if self.push_fails:
                return 400, {"description": self.push_fails, "code": "0", "status": "failed"}
            return 201, {"description": "Success", "code": "1", "referenceNumber": str(self.ref),
                         "transactionNumber": req["transactionNumber"], "phoneNumber": req["phone"],
                         "amount": req["amount"], "type": "ussdpush", "status": "success"}
        return 404, {}


@override_settings(**CASHPAY)
class CashPayTests(Base):
    def setUp(self):
        super().setUp()
        self.fake = FakeCashPay()
        from unittest import mock
        from payments.gateways import CashPayGateway
        patcher = mock.patch.object(CashPayGateway, "_post", autospec=True, side_effect=self.fake)
        patcher.start()
        self.addCleanup(patcher.stop)

    def approved(self, amount="500"):
        req = self.new_request(amount, funding="cashpay")
        services.approve(req, self.teller)
        req.refresh_from_db()
        return req

    def push(self, req, phone="0754123456"):
        from payments.services import start_payment
        payment, _ = start_payment(req, self.customer, phone=phone)
        return payment

    def callback(self, payment, status="SUCCESS", amount=None, receipt="26785481140984", secret=SECRET, **over):
        body = {"referenceNumber": int(payment.provider_reference), "receiptNumber": receipt, "status": status,
                "provider": "M-PESA", "amount": float(amount if amount is not None else payment.amount),
                "phone": payment.payer_phone, "transactionNumber": payment.reference}
        body.update(over)
        return self.client.post(f"/payments/cashpay/callback/{secret}/", json.dumps(body),
                                content_type="application/json")

    def test_push_follows_the_documented_flow(self):
        req = self.approved("333.33")
        payment = self.push(req, "+255 754 123 456")
        paths = [c[0] for c in self.fake.calls]
        self.assertEqual(paths, ["get-token", "generate", "ussdpush"])
        push = self.fake.calls[-1][1]
        self.assertEqual(push["header"]["token"], "jwt-token")
        sent = push["body"]["request"]
        self.assertEqual(sent["phone"], "255754123456")
        self.assertEqual(sent["type"], "ussdpush")
        self.assertTrue(sent["amount"].isdigit())                 # whole shillings, no decimals
        self.assertEqual(Decimal(sent["amount"]), payment.amount)
        self.assertGreaterEqual(payment.amount, req.local_amount)  # rounded up, never short
        self.assertTrue(sent["transactionNumber"].isalnum())
        self.assertEqual(payment.provider_reference, "50000001")

    def test_token_is_cached_and_refreshed_on_401(self):
        self.push(self.approved())
        self.fake.calls.clear()
        self.fake.token_valid = False                              # CashPay expired it after 5 minutes
        self.push(self.approved())
        self.assertEqual([c[0] for c in self.fake.calls], ["generate", "get-token", "generate", "ussdpush"])

    def test_success_callback_settles_once(self):
        req = self.approved()
        payment = self.push(req)
        r = self.callback(payment)
        self.assertEqual(r.json(), {"status": "received", "message": "settled"})
        req.refresh_from_db()
        self.assertEqual(req.status, "funded")
        self.assertEqual(req.funding_reference, "26785481140984")
        self.assertEqual(self.callback(payment).json()["message"], "duplicate ignored")   # CashPay retry
        self.assertEqual(Payment.objects.filter(request=req, status="paid").count(), 1)

    def test_wrong_secret_is_invisible(self):
        payment = self.push(self.approved())
        self.assertEqual(self.callback(payment, secret="guess").status_code, 404)
        self.assertEqual(GatewayEvent.objects.count(), 0)

    def test_forged_fields_are_never_settled(self):
        req = self.approved()
        payment = self.push(req)
        self.assertEqual(self.callback(payment, amount=1, receipt="R1").json()["message"], "held for review")
        self.assertEqual(self.callback(payment, receipt="R2", referenceNumber=99999999).json()["message"], "held for review")
        self.assertEqual(self.callback(payment, receipt="R3", phone="255700000000").json()["message"], "held for review")
        self.assertEqual(self.callback(payment, receipt="R4", transactionNumber="NOPE").json()["message"], "unknown transaction")
        req.refresh_from_db()
        self.assertEqual(req.status, "approved")

    def test_failed_payment_then_new_prompt(self):
        req = self.approved()
        first = self.push(req)
        self.assertEqual(self.callback(first, status="FAILED", receipt="").json()["message"], "failed noted")
        first.refresh_from_db()
        self.assertEqual(first.status, "failed")
        second = self.push(req)
        self.assertNotEqual(first.reference, second.reference)     # CashPay refuses duplicate transactionNumbers
        self.assertEqual(self.callback(second).json()["message"], "settled")

    def test_resend_is_rate_limited_and_late_duplicate_is_flagged(self):
        req = self.approved()
        first = self.push(req)
        with self.assertRaisesMessage(services.ExchangeError, "already sent"):
            self.push(req)
        Payment.objects.filter(pk=first.pk).update(pushed_at=timezone.now() - timezone.timedelta(minutes=5))
        second = self.push(req)
        first.refresh_from_db()
        self.assertEqual(first.status, "cancelled")
        self.assertEqual(self.callback(second, receipt="A1").json()["message"], "settled")
        # The customer also approved the old prompt: money arrived twice.
        self.assertEqual(self.callback(first, receipt="A2").json()["message"], "held for review")
        self.assertEqual(Payment.objects.filter(request=req, status="paid").count(), 1)
        self.assertTrue(AuditEntry.objects.filter(action="payment.needs_refund").exists())

    def test_ip_allowlist(self):
        payment = self.push(self.approved())
        with self.settings(CASHPAY_ALLOWED_IPS=["41.59.0.0/16"]):
            self.assertEqual(self.callback(payment).status_code, 403)
            r = self.client.post(f"/payments/cashpay/callback/{SECRET}/", json.dumps({}), content_type="application/json",
                                 HTTP_X_FORWARDED_FOR="41.59.10.20")
            self.assertEqual(r.status_code, 400)                   # passed the IP check, then rejected as empty

    def test_disabled_until_configured(self):
        with self.settings(CASHPAY_PASSWORD=""):
            r = self.client.post(f"/payments/cashpay/callback/{SECRET}/", b"{}", content_type="application/json")
            self.assertEqual(r.status_code, 503)
            with self.assertRaisesMessage(services.ExchangeError, "not available"):
                self.push(self.approved())
        self.assertEqual(self.client.get(f"/payments/cashpay/callback/{SECRET}/").status_code, 405)

    def test_operator_rejection_is_explained(self):
        self.fake.push_fails = "Operator Msisdn Not Supported"
        req = self.approved()
        with self.assertRaisesMessage(services.ExchangeError, "does not support"):
            self.push(req)
        self.assertEqual(Payment.objects.get(request=req).status, "failed")


class MobilePrefixTests(TestCase):
    def test_every_tanzanian_mobile_range_is_accepted(self):
        from accounts.models import MobilePrefix, normalise_phone
        from payments.gateways import GatewayError, cashpay_phone
        for local in ("0612345678", "0622345678", "0652345678", "0672345678", "0682345678", "0692345678",
                      "0712345678", "0732345678", "0742345678", "0752345678", "0762345678", "0772345678",
                      "0782345678", "0792345678"):
            self.assertTrue(normalise_phone(local).startswith("+2556") or normalise_phone(local).startswith("+2557"))
        for ok in ("0682345678", "0692345678", "0782345678", "0752345678", "0712345678", "0772345678", "0792345678"):
            self.assertEqual(len(cashpay_phone(ok)), 12)
        for bad in ("0622345678", "0732345678"):                  # HaloPesa and T-Pesa: CashPay cannot push
            with self.assertRaises(GatewayError):
                cashpay_phone(bad)
        self.assertEqual(MobilePrefix.lookup("255782345678").wallet, "Airtel Money")
        # A new range added in Management is recognised at once, no code change.
        MobilePrefix.objects.create(prefix="785", operator="Airtel", wallet="Airtel Money (new range)")
        self.assertEqual(MobilePrefix.lookup("255785123456").prefix, "785")
        # An unknown range is not blocked locally; CashPay decides.
        MobilePrefix.objects.filter(prefix="66").delete()
        self.assertEqual(cashpay_phone("0662345678"), "255662345678")


class ChatTests(Base):
    def test_resend_with_same_client_id_posts_once(self):
        conv = Conversation.objects.create(customer=self.customer, subject="Hello")
        cid = uuid.uuid4()
        post_message(conv, self.customer, "Hi there", client_id=cid)
        post_message(conv, self.customer, "Hi there", client_id=cid)
        self.assertEqual(conv.messages.count(), 1)

    def test_other_customer_cannot_read_thread(self):
        conv = Conversation.objects.create(customer=self.customer, subject="Private")
        other = make_user("other@x.test")
        self.client.force_login(other)
        with self.settings(ALLOWED_HOSTS=["testserver"]):
            self.assertEqual(self.client.get(f"/chat/{conv.pk}/messages/").status_code, 404)


@override_settings(ALLOWED_HOSTS=["testserver"])
class TreasuryAndReportTests(Base):
    def _fund(self, amount="500"):
        req = self.new_request(amount)
        services.approve(req, self.teller)
        services.confirm_funds(req, self.teller, f"REF-{uuid.uuid4().hex[:6]}")
        req.refresh_from_db()
        return req

    def test_ledger_follows_money_and_blocks_overdraft(self):
        from treasury.models import LedgerEntry, TreasuryAccount
        req = self._fund("500")
        self.assertEqual(TreasuryAccount.objects.get(currency_id="TZS").balance, Decimal("1307500.00"))
        services.mark_paid_out(req, self.teller2, "CASH-1")
        self.assertEqual(TreasuryAccount.objects.get(currency_id="USD").balance, Decimal("999500.00"))
        self.assertEqual(LedgerEntry.objects.filter(request=req).count(), 2)
        LedgerEntry_count = LedgerEntry.objects.count()
        from treasury.services import post
        post("USD", "out", "withdrawal", "999500", self.manager, note="Bank deposit")
        req2 = self._fund("100")
        with self.assertRaisesMessage(services.ExchangeError, "Insufficient USD"):
            services.mark_paid_out(req2, self.teller2, "CASH-2")
        self.assertEqual(LedgerEntry.objects.count(), LedgerEntry_count + 2)

    def test_reports_download_and_access(self):
        self._fund()
        self.client.force_login(self.manager)
        for kind in ("requests", "payments", "ledger", "summary", "balances", "audit"):
            r = self.client.get(f"/reports/{kind}.xlsx")
            self.assertEqual(r.status_code, 200, kind)
            self.assertTrue(r.content.startswith(b"PK"), kind)
        self.client.force_login(self.teller)
        self.assertEqual(self.client.get("/reports/requests.xlsx")["Location"], "/desk/")

    def test_management_portal(self):
        self._fund()
        r = self.client.get("/management/")
        self.assertEqual(r.status_code, 302)
        self.client.force_login(self.manager)
        r = self.client.get("/management/login/?next=/management/")
        self.assertEqual(r["Location"], self.manager.home_url)
        boss = User.objects.create_superuser(email="root@x.test", phone="+255711000999", password="x-Strong-pass-1",
                                             full_name="Root Admin")
        self.client.force_login(boss)
        for url in ("/management/", "/management/accounts/user/", "/management/auth/group/",
                    "/management/exchange/exchangerequest/", "/management/treasury/ledgerentry/",
                    "/management/notifications/emaillog/", "/management/audit/auditentry/",
                    "/management/support/message/"):
            self.assertEqual(self.client.get(url).status_code, 200, url)
        r = self.client.post("/management/exchange/exchangerequest/",
                             {"action": "export_excel", "_selected_action": [str(x) for x in
                                                                             ExchangeRequest.objects.values_list("pk", flat=True)]})
        self.assertTrue(r.content.startswith(b"PK"))


@override_settings(ALLOWED_HOSTS=["testserver"])
class BackupDownloadTests(Base):
    def setUp(self):
        super().setUp()
        self.root = User.objects.create_superuser(email="root@x.test", phone="+255711000002",
                                                  password="Root-pass-2026!", full_name="Root Admin")
        self.client.force_login(self.root)

    def download(self, fmt, password="Root-pass-2026!", media=False):
        data = {"format": fmt, "password": password}
        if media:
            data["include_media"] = "1"
        return self.client.post("/management/backup/", data)

    def test_page_and_native_sqlite_copy(self):
        import io, sqlite3, tempfile, zipfile
        self.assertContains(self.client.get("/management/backup/"), "Download a database backup")
        self.assertContains(self.client.get("/management/"), "Database backup")
        r = self.download("native")
        self.assertEqual(r["Content-Type"], "application/zip")
        self.assertEqual(r["Cache-Control"], "no-store, private")
        blob = b"".join(r.streaming_content)
        zf = zipfile.ZipFile(io.BytesIO(blob))
        self.assertEqual(sorted(zf.namelist()), ["RESTORE.txt", "db.sqlite3"])
        with tempfile.TemporaryDirectory() as d:
            path = zf.extract("db.sqlite3", d)
            con = sqlite3.connect(path)
            n = con.execute("select count(*) from accounts_user where email = 'root@x.test'").fetchone()[0]
            con.close()
        self.assertEqual(n, 1)
        self.assertTrue(AuditEntry.objects.filter(action="backup.downloaded").exists())

    def test_portable_json(self):
        import io, json, zipfile
        blob = b"".join(self.download("json").streaming_content)
        rows = json.loads(zipfile.ZipFile(io.BytesIO(blob)).read("desderia.json"))
        self.assertTrue(any(r["model"] == "rates.currency" and r["pk"] == "USD" for r in rows))

    def test_wrong_password_and_non_superuser_refused(self):
        r = self.download("native", password="wrong")
        self.assertEqual(r.status_code, 302)
        self.assertTrue(AuditEntry.objects.filter(action="backup.denied").exists())
        admin_role = User.objects.create_user(email="adm@x.test", phone="+255711000003", password="Adm-pass-2026!",
                                              full_name="Admin Role", role="admin", is_staff=True)
        self.client.force_login(admin_role)
        r = self.client.post("/management/backup/", {"format": "native", "password": "Adm-pass-2026!"})
        self.assertEqual(r.status_code, 302)
        self.assertNotIn("application/zip", r.get("Content-Type", ""))
