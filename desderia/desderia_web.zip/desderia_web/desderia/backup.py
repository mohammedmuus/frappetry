"""
Database backup download for the management panel (superusers only).

A backup holds every customer record, password hashes and the full money
history, so each download needs the superuser's password again, is rate
limited, and is written to the audit trail. The copy is a consistent
snapshot taken while the site keeps running, built in a temporary file
that is deleted as soon as the download closes.
"""

import os
import re
import shutil
import sqlite3
import subprocess
import tempfile
import zipfile
from pathlib import Path

from django.conf import settings
from django.contrib import messages
from django.core.management import call_command
from django.db import connection
from django.http import FileResponse
from django.shortcuts import redirect
from django.template.response import TemplateResponse
from django.utils import timezone

from audit.models import AuditEntry
from audit.services import record
from desderia.guards import hit

FORMATS = {
    "native": "Full database copy (restore as is)",
    "json": "Portable JSON (any database engine, Django loaddata)",
}
DUMPDATA_EXCLUDE = ["contenttypes", "auth.permission", "sessions", "admin.logentry"]


def _engine():
    return connection.vendor  # "sqlite" or "postgresql"


def _db_size():
    try:
        if _engine() == "sqlite":
            return os.path.getsize(connection.settings_dict["NAME"])
        with connection.cursor() as cur:
            cur.execute("SELECT pg_database_size(current_database())")
            return cur.fetchone()[0]
    except Exception:
        return None


def _sqlite_snapshot(target):
    """Online backup API: a consistent copy even while requests are writing."""
    connection.ensure_connection()
    dst = sqlite3.connect(target)
    # Some CHECK constraints use REGEXP, which Django adds to its own connections only.
    dst.create_function("REGEXP", 2, lambda pattern, value: value is not None
                        and re.search(pattern, str(value)) is not None, deterministic=True)
    if connection.in_atomic_block:
        # The backup API waits forever on a connection holding uncommitted
        # writes; the SQL dump reads through the same transaction instead.
        dst.executescript("\n".join(connection.connection.iterdump()))
    else:
        with dst:
            connection.connection.backup(dst)
    dst.close()


def _pg_dump(target):
    db = settings.DATABASES["default"]
    exe = shutil.which("pg_dump")
    if not exe:
        raise RuntimeError("pg_dump is not installed on this server. Choose Portable JSON instead.")
    env = {**os.environ, "PGPASSWORD": db.get("PASSWORD", ""), "PGSSLMODE": db.get("OPTIONS", {}).get("sslmode", "prefer")}
    cmd = [exe, "-Fc", "--no-owner", "-h", db.get("HOST", "127.0.0.1"), "-p", str(db.get("PORT", "5432")),
           "-U", db.get("USER", ""), "-f", str(target), db["NAME"]]
    result = subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=600)
    if result.returncode != 0:
        raise RuntimeError("pg_dump failed: " + (result.stderr or "unknown error")[:300])


def build_backup(fmt, include_media):
    """Return (open temporary file positioned at 0, filename). The file deletes itself on close."""
    stamp = timezone.localtime().strftime("%Y%m%d-%H%M")
    workdir = Path(tempfile.mkdtemp(prefix="dsd-backup-"))
    try:
        if fmt == "native":
            if _engine() == "sqlite":
                data_path = workdir / "db.sqlite3"
                _sqlite_snapshot(data_path)
            else:
                data_path = workdir / "desderia.dump"
                _pg_dump(data_path)
        else:
            data_path = workdir / "desderia.json"
            with open(data_path, "w", encoding="utf-8") as out:
                call_command("dumpdata", natural_foreign=True, exclude=DUMPDATA_EXCLUDE, indent=1, stdout=out)

        readme = (
            f"Desderia database backup\nCreated: {timezone.localtime():%Y-%m-%d %H:%M %Z}\n"
            f"Engine: {_engine()}\nFormat: {FORMATS[fmt]}\nIncludes ID photos: {'yes' if include_media else 'no'}\n\n"
            "Restore\n"
            "  SQLite copy: stop the server, replace db.sqlite3 with this file, start the server.\n"
            "  PostgreSQL dump: pg_restore --clean --no-owner -d desderia desderia.dump\n"
            "  Portable JSON: on an empty database run 'python manage.py migrate' then\n"
            "                 'python manage.py loaddata desderia.json'\n"
            "  ID photos: copy the private_media folder back into the project folder.\n\n"
            "This file contains personal data and password hashes. Store it encrypted and offline.\n"
        )
        archive = tempfile.TemporaryFile(suffix=".zip")
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.write(data_path, data_path.name)
            zf.writestr("RESTORE.txt", readme)
            media_root = Path(settings.MEDIA_ROOT)
            if include_media and media_root.exists():
                for path in media_root.rglob("*"):
                    if path.is_file():
                        zf.write(path, Path("private_media") / path.relative_to(media_root))
        archive.seek(0)
        return archive, f"desderia-backup-{_engine()}-{fmt}-{stamp}.zip"
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


def backup_view(admin_site, request):
    if not request.user.is_superuser:
        messages.error(request, "Only a superuser can download database backups.")
        return redirect("admin:index")

    if request.method == "POST":
        fmt = request.POST.get("format", "native")
        include_media = request.POST.get("include_media") == "1"
        if fmt not in FORMATS:
            messages.error(request, "Choose a backup format.")
            return redirect("admin:db_backup")
        if not request.user.check_password(request.POST.get("password", "")):
            record("backup.denied", None, f"Backup refused for {request.user.email}: wrong password")
            messages.error(request, "Password is not correct.")
            return redirect("admin:db_backup")
        if hit("db_backup", f"u{request.user.pk}", 5, 3600):
            messages.error(request, "Limit reached: 5 backups per hour.")
            return redirect("admin:db_backup")
        try:
            archive, filename = build_backup(fmt, include_media)
        except Exception as exc:
            messages.error(request, f"Backup failed: {exc}")
            return redirect("admin:db_backup")
        size = archive.seek(0, 2)
        archive.seek(0)
        record("backup.downloaded", None, f"Database backup downloaded by {request.user.email} ({fmt}, {size} bytes)",
               data={"format": fmt, "engine": _engine(), "include_media": include_media, "bytes": size})
        response = FileResponse(archive, as_attachment=True, filename=filename, content_type="application/zip")
        response["Cache-Control"] = "no-store, private"
        return response

    recent = AuditEntry.objects.filter(action="backup.downloaded").order_by("-seq")[:10]
    size = _db_size()
    context = {
        **admin_site.each_context(request),
        "title": "Database backup",
        "engine": _engine(),
        "size_mb": f"{size / 1048576:.1f} MB" if size else "unknown",
        "formats": FORMATS,
        "pg_dump_available": bool(shutil.which("pg_dump")),
        "recent": recent,
    }
    return TemplateResponse(request, "admin/db_backup.html", context)
