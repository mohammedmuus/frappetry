from django.contrib import admin, messages
from django.template.response import TemplateResponse
from django.utils import timezone
from django.contrib.auth.admin import GroupAdmin as BaseGroupAdmin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.conf import settings
from django.contrib.auth.models import Group, Permission

from desderia.admin_mixins import NoDeleteAdmin, ReadOnlyAdmin, SuperuserOnlyAdmin

from .models import ApiToken, KycProfile, MobilePrefix, OneTimeCode, User


class KycInline(admin.StackedInline):
    model = KycProfile
    fk_name = "user"
    extra = 0
    can_delete = False
    exclude = ["id_document"]
    readonly_fields = ["submitted_at", "updated_at", "reviewed_by", "reviewed_at"]


class TokenInline(ReadOnlyAdmin, admin.TabularInline):
    model = ApiToken
    extra = 0
    fields = ["device_name", "created_at", "last_used_at", "expires_at", "revoked_at", "ip_address"]
    readonly_fields = fields


@admin.register(User)
class UserAdmin(SuperuserOnlyAdmin, BaseUserAdmin):
    ordering = ["email"]
    list_display = ["email", "full_name", "phone", "role", "is_active", "is_staff", "email_verified_at",
                    "phone_verified_at", "last_login"]
    list_filter = ["role", "is_active", "is_staff", "is_superuser", "groups"]
    search_fields = ["email", "full_name", "phone"]
    readonly_fields = ["id", "date_joined", "last_login"]
    filter_horizontal = ["groups", "user_permissions"]
    inlines = [KycInline, TokenInline]
    fieldsets = (
        (None, {"fields": ("id", "email", "password")}),
        ("Profile", {"fields": ("full_name", "phone", "role", "notify_email")}),
        ("Verification", {"fields": ("email_verified_at", "phone_verified_at")}),
        ("Access", {"fields": ("is_active", "is_staff", "is_superuser", "groups", "user_permissions")}),
        ("Dates", {"fields": ("date_joined", "last_login")}),
    )
    add_fieldsets = ((None, {"classes": ("wide",), "fields": (
        "email", "full_name", "phone", "role", "password1", "password2")}),)
    actions = ["backup_code", "mark_email_verified", "mark_phone_verified", "deactivate"]

    @admin.action(description="Deactivate selected accounts (keeps the audit trail)")
    def deactivate(self, request, queryset):
        queryset.exclude(pk=request.user.pk).update(is_active=False)

    # ── Backup when email or SMS delivery fails ───────────────
    @admin.action(description="Generate a backup one time code (email or SMS not arriving)")
    def backup_code(self, request, queryset):
        from . import otp

        if queryset.count() != 1:
            self.message_user(request, "Select exactly one account to generate a backup code.", messages.ERROR)
            return None
        target = queryset.first()
        context = {
            **self.admin_site.each_context(request),
            "title": "Generate a backup one time code",
            "target": target,
            "purposes": OneTimeCode.PURPOSE_CHOICES,
            "opts": self.model._meta,
            "action_checkbox_name": admin.helpers.ACTION_CHECKBOX_NAME,
            "code": None,
        }
        if request.POST.get("confirm") == "yes":
            purpose = request.POST.get("purpose", "")
            if purpose not in dict(OneTimeCode.PURPOSE_CHOICES):
                self.message_user(request, "Choose what the code is for.", messages.ERROR)
                return None
            try:
                code, sent_by = otp.issue_backup(target, purpose, request.user, request.POST.get("reason", ""),
                                                 also_send=request.POST.get("also_send", ""), request=request)
            except otp.OtpError as exc:
                self.message_user(request, str(exc), messages.ERROR)
                return None
            context.update(code=code, sent_by=sent_by, purpose_label=dict(OneTimeCode.PURPOSE_CHOICES)[purpose],
                           minutes=settings.OTP_TTL_SECONDS // 60)
        response = TemplateResponse(request, "admin/accounts/backup_code.html", context)
        # The code page must never be cached or kept in browser history caches.
        response["Cache-Control"] = "no-store, private"
        return response

    def _mark(self, request, queryset, field, label):
        from audit.services import record

        n = 0
        for user in queryset.filter(**{f"{field}__isnull": True}):
            User.objects.filter(pk=user.pk).update(**{field: timezone.now()})
            record(f"account.{label}_verified_manually", user,
                   f"{label.title()} of {user.email} marked verified by {request.user.email}", actor=request.user)
            n += 1
        self.message_user(request, f"{n} account(s) marked with a verified {label}.", messages.SUCCESS)

    @admin.action(description="Mark email as verified (checked in person)")
    def mark_email_verified(self, request, queryset):
        self._mark(request, queryset, "email_verified_at", "email")

    @admin.action(description="Mark phone as verified (checked in person)")
    def mark_phone_verified(self, request, queryset):
        self._mark(request, queryset, "phone_verified_at", "phone")

    def save_model(self, request, obj, form, change):
        if obj.pk == request.user.pk and not obj.is_superuser:
            obj.is_superuser = True  # never lock out the only page that could undo it
        if obj.is_superuser or obj.role == User.ROLE_ADMIN:
            obj.is_staff = True
        super().save_model(request, obj, form, change)
        from audit.services import record
        record("admin.user_saved", obj, f"User {obj.email} {'changed' if change else 'created'} in management",
               data={"changed": form.changed_data if change else []})


if admin.site.is_registered(Group):
    admin.site.unregister(Group)


@admin.register(Group)
class GroupAdmin(SuperuserOnlyAdmin, BaseGroupAdmin):
    list_display = ["name", "member_count"]

    @admin.display(description="Members")
    def member_count(self, obj):
        return obj.user_set.count()


@admin.register(Permission)
class PermissionAdmin(ReadOnlyAdmin, SuperuserOnlyAdmin, admin.ModelAdmin):
    list_display = ["name", "content_type", "codename"]
    list_filter = ["content_type__app_label"]
    search_fields = ["name", "codename"]

    def has_view_permission(self, request, obj=None):
        return request.user.is_superuser


@admin.register(KycProfile)
class KycAdmin(NoDeleteAdmin, admin.ModelAdmin):
    list_display = ["legal_name", "user", "id_type", "id_number", "status", "submitted_at", "reviewed_by"]
    list_filter = ["status", "id_type", "nationality"]
    search_fields = ["legal_name", "id_number", "user__email", "user__phone"]
    readonly_fields = ["user", "submitted_at", "updated_at", "reviewed_by", "reviewed_at", "document_link"]
    exclude = ["id_document"]
    date_hierarchy = "submitted_at"

    @admin.display(description="Document")
    def document_link(self, obj):
        from django.utils.html import format_html
        if not obj.id_document:
            return "-"
        return format_html('<a href="/account/kyc/{}/document/" target="_blank" rel="noopener">Open photo</a>', obj.user_id)


@admin.register(ApiToken)
class ApiTokenAdmin(admin.ModelAdmin):
    list_display = ["user", "device_name", "created_at", "last_used_at", "expires_at", "revoked_at", "ip_address"]
    list_filter = ["revoked_at"]
    search_fields = ["user__email", "device_name"]
    exclude = ["key_hash"]
    actions = ["revoke"]

    readonly_fields = ["user", "device_name", "created_at", "last_used_at", "expires_at", "revoked_at", "ip_address"]

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False

    @admin.action(description="Revoke selected device tokens")
    def revoke(self, request, queryset):
        from django.utils import timezone
        queryset.filter(revoked_at__isnull=True).update(revoked_at=timezone.now())


@admin.register(OneTimeCode)
class OneTimeCodeAdmin(ReadOnlyAdmin, admin.ModelAdmin):
    list_display = ["user", "purpose", "channel", "created_at", "expires_at", "used_at", "attempts", "ip_address"]
    list_filter = ["purpose", "channel"]
    search_fields = ["user__email"]
    exclude = ["code_hash"]


@admin.register(MobilePrefix)
class MobilePrefixAdmin(admin.ModelAdmin):
    """Add a new operator range here the day it launches. No code change needed."""

    list_display = ["prefix", "operator", "wallet", "cashpay_supported", "is_active", "note"]
    list_editable = ["cashpay_supported", "is_active"]
    list_filter = ["operator", "cashpay_supported", "is_active"]
    search_fields = ["prefix", "operator", "wallet"]

    def has_delete_permission(self, request, obj=None):
        return False
