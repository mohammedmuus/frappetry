"""One time codes for email verification, phone verification and login step two."""

import secrets
from datetime import timedelta

from django.conf import settings
from django.core.mail import send_mail
from django.db.models import F
from django.utils import timezone
from django.utils.crypto import constant_time_compare, salted_hmac

from audit.services import record
from desderia.middleware import client_ip

from .models import OneTimeCode
from .sms import send_sms


class OtpError(Exception):
    pass


def _hash(code_id, code):
    return salted_hmac("desderia.otp", f"{code_id}:{code}", algorithm="sha256").hexdigest()


def issue(user, purpose, channel="email", request=None):
    """Create and deliver a fresh six digit code. Older live codes are retired."""
    last = (OneTimeCode.objects.filter(user=user, purpose=purpose, used_at__isnull=True)
            .order_by("-created_at").first())
    if last and (timezone.now() - last.created_at).total_seconds() < settings.OTP_RESEND_COOLDOWN:
        wait = int(settings.OTP_RESEND_COOLDOWN - (timezone.now() - last.created_at).total_seconds())
        raise OtpError(f"Please wait {max(wait, 1)} seconds before requesting another code.")

    OneTimeCode.objects.filter(user=user, purpose=purpose, used_at__isnull=True).update(used_at=timezone.now())
    code = f"{secrets.randbelow(1_000_000):06d}"
    otp = OneTimeCode(user=user, purpose=purpose, channel=channel,
                      expires_at=timezone.now() + timedelta(seconds=settings.OTP_TTL_SECONDS),
                      ip_address=client_ip(request) or None)
    otp.code_hash = _hash(otp.id, code)
    otp.save()

    minutes = settings.OTP_TTL_SECONDS // 60
    text = f"Your Desderia code is {code}. It expires in {minutes} minutes. Never share this code."
    if channel == "sms":
        send_sms(user.phone, text)
    else:
        send_mail("Your Desderia verification code", text + "\n\nIf you did not request this, ignore this email.",
                  settings.DEFAULT_FROM_EMAIL, [user.email], fail_silently=True)
    record("otp.issued", user, f"{otp.get_purpose_display()} code sent by {channel}",
           data={"purpose": purpose, "channel": channel}, actor=user, request=request)
    return otp


def verify(user, purpose, code, request=None):
    """Check a code. Each wrong guess is counted atomically; success consumes it once."""
    code = (code or "").strip()
    otp = (OneTimeCode.objects.filter(user=user, purpose=purpose, used_at__isnull=True)
           .order_by("-created_at").first())
    if otp is None or not otp.is_live:
        raise OtpError("This code has expired. Request a new one.")
    if not (len(code) == 6 and code.isdigit() and constant_time_compare(otp.code_hash, _hash(otp.id, code))):
        OneTimeCode.objects.filter(pk=otp.pk).update(attempts=F("attempts") + 1)
        record("otp.failed", user, "Wrong one time code entered", data={"purpose": purpose},
               actor=user, request=request)
        left = settings.OTP_MAX_ATTEMPTS - otp.attempts - 1
        if left <= 0:
            raise OtpError("Too many wrong codes. Request a new one.")
        raise OtpError(f"That code is not correct. {left} attempt(s) left.")
    claimed = OneTimeCode.objects.filter(pk=otp.pk, used_at__isnull=True).update(used_at=timezone.now())
    if not claimed:
        raise OtpError("This code was already used.")
    return True


# ─────────────────────────────────────────────────────────────
# BACKUP CODES (management panel, when email or SMS delivery fails)
# ─────────────────────────────────────────────────────────────
# Staff read the code to the customer over a trusted line (a call to the
# phone number on file, or at the counter after checking ID). The code is
# shown once and stored only as a keyed hash, like every other code. A
# backup sign in code does not bypass the password: the customer must
# still pass the password step first.

BACKUP_LIMIT_PER_HOUR = 3


def issue_backup(user, purpose, issued_by, reason, also_send="", request=None):
    """Return a fresh six digit code for staff to hand over. Raises OtpError."""
    reason = (reason or "").strip()
    if len(reason) < 5:
        raise OtpError("Give a reason (at least 5 characters). It is kept in the audit trail.")
    if not user.is_active:
        raise OtpError("This account is disabled.")
    if user.is_bureau_staff and not issued_by.is_superuser:
        raise OtpError("Only a superuser can issue backup codes for staff accounts.")
    if user.pk == issued_by.pk:
        raise OtpError("You cannot issue a backup code for your own account.")
    hour_ago = timezone.now() - timedelta(hours=1)
    if OneTimeCode.objects.filter(user=user, channel="desk", created_at__gte=hour_ago).count() >= BACKUP_LIMIT_PER_HOUR:
        raise OtpError(f"Limit reached: {BACKUP_LIMIT_PER_HOUR} backup codes per customer per hour.")

    OneTimeCode.objects.filter(user=user, purpose=purpose, used_at__isnull=True).update(used_at=timezone.now())
    code = f"{secrets.randbelow(1_000_000):06d}"
    otp = OneTimeCode(user=user, purpose=purpose, channel="desk",
                      expires_at=timezone.now() + timedelta(seconds=settings.OTP_TTL_SECONDS),
                      ip_address=client_ip(request) or None)
    otp.code_hash = _hash(otp.id, code)
    otp.save()

    sent_by = []
    minutes = settings.OTP_TTL_SECONDS // 60
    text = f"Your Desderia code is {code}. It expires in {minutes} minutes. Never share this code."
    if also_send == "email":
        sent = send_mail("Your Desderia verification code", text, settings.DEFAULT_FROM_EMAIL, [user.email],
                         fail_silently=True)
        sent_by.append("email" if sent else "email (failed)")
    elif also_send == "sms":
        sent_by.append("sms" if send_sms(user.phone, text) else "sms (failed)")

    record("otp.backup_issued", user,
           f"Backup {otp.get_purpose_display().lower()} code issued for {user.email} by {issued_by.email}",
           data={"purpose": purpose, "reason": reason[:200], "also_sent": sent_by}, actor=issued_by, request=request)
    return code, sent_by
