from rest_framework.permissions import BasePermission


class IsVerifiedCustomer(BasePermission):
    message = "Verify your email and phone number first."

    def has_permission(self, request, view):
        user = request.user
        if not (user and user.is_authenticated):
            return False
        # Staff never trade through the customer channel (conflict of interest).
        if not user.is_customer:
            self.message = ("This is a staff account. The mobile app is for customers. "
                            "Use the website desk or sign in with a customer account.")
            return False
        if not user.is_fully_verified:
            self.message = "Verify your email and phone number first."
            return False
        return True
