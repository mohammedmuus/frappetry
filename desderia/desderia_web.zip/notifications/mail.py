"""Email backend wrapper that records every outgoing message in EmailLog.

settings.EMAIL_BACKEND points here; settings.REAL_EMAIL_BACKEND is the
transport that actually delivers (SMTP in production, console locally).
"""

import logging

from django.conf import settings
from django.core.mail.backends.base import BaseEmailBackend
from django.utils.module_loading import import_string

log = logging.getLogger("desderia")


class LoggingEmailBackend(BaseEmailBackend):
    def __init__(self, fail_silently=False, **kwargs):
        super().__init__(fail_silently=fail_silently)
        self.inner = import_string(settings.REAL_EMAIL_BACKEND)(fail_silently=fail_silently, **kwargs)

    def open(self):
        return self.inner.open()

    def close(self):
        return self.inner.close()

    def send_messages(self, email_messages):
        from .models import EmailLog

        sent = 0
        for msg in email_messages or []:
            try:
                n = self.inner.send_messages([msg]) or 0
                status, error = ("sent", "") if n else ("failed", "transport returned 0")
                sent += n
            except Exception as exc:
                status, error = "failed", str(exc)[:255]
                log.exception("Email failed: %s", msg.subject)
                if not self.fail_silently:
                    self._log(EmailLog, msg, status, error)
                    raise
            self._log(EmailLog, msg, status, error)
        return sent

    @staticmethod
    def _log(model, msg, status, error):
        try:
            model.objects.create(to=", ".join(msg.to)[:500], subject=msg.subject[:255], status=status, error=error)
        except Exception:
            log.exception("Could not write email log")
