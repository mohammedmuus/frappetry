from django.conf import settings
from django.db import models


class Notification(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notifications")
    event = models.CharField(max_length=40)
    title = models.CharField(max_length=120)
    body = models.CharField(max_length=500)
    link = models.CharField(max_length=200, blank=True)
    read_at = models.DateTimeField(null=True, blank=True)
    emailed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["user", "read_at"])]

    def __str__(self):
        return self.title


class EmailLog(models.Model):
    """Every email the platform sends. Bodies are not stored: they can hold
    one time codes and reset links. Subject, recipients and outcome are enough
    to prove delivery to a customer or an auditor."""

    to = models.CharField(max_length=500)
    subject = models.CharField(max_length=255)
    status = models.CharField(max_length=8, choices=[("sent", "Sent"), ("failed", "Failed")])
    error = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.subject} to {self.to}"
