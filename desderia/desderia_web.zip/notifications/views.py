from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST


@login_required
def notification_list(request):
    items = request.user.notifications.all()[:60]
    return render(request, "notification_list.html", {"items": items})


@login_required
@require_POST
def mark_all_read(request):
    request.user.notifications.filter(read_at__isnull=True).update(read_at=timezone.now())
    return redirect("notifications:list")
