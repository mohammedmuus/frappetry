from django.contrib import admin

from desderia.admin_mixins import ReadOnlyAdmin

from .models import EmailLog, Notification


@admin.register(Notification)
class NotificationAdmin(ReadOnlyAdmin, admin.ModelAdmin):
    list_display = ["user", "event", "title", "emailed", "read_at", "created_at"]
    list_filter = ["event", "emailed"]
    search_fields = ["user__email", "title", "body"]
    date_hierarchy = "created_at"


@admin.register(EmailLog)
class EmailLogAdmin(ReadOnlyAdmin, admin.ModelAdmin):
    list_display = ["created_at", "to", "subject", "status", "error"]
    list_filter = ["status"]
    search_fields = ["to", "subject"]
    date_hierarchy = "created_at"
