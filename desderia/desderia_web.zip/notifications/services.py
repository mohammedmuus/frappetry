"""Automated notifications: an in-app entry plus an email for every event.

Emails are sent after the database transaction commits, so a rolled back
action never emails anyone, and a mail outage never rolls back money.
"""

import logging

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.core.mail import EmailMultiAlternatives
from django.db import transaction
from django.template.loader import render_to_string

from .models import Notification

log = logging.getLogger("desderia")

STATUS_COPY = {
    "submitted": ("Request received", "We received your request {ref}. Our desk will review it shortly."),
    "negotiating": ("Rate under negotiation", "Request {ref} is in negotiation. Open it to see the latest offer."),
    "approved": ("Request approved", "Request {ref} is approved at {rate}. Please send {pay} to complete it."),
    "funded": ("Funds received", "We received your funds for {ref}. Your payout is being prepared."),
    "paid_out": ("Payout sent", "Your payout for {ref} was sent. Reference {payout_ref}."),
    "completed": ("Request completed", "Request {ref} is complete. Thank you for choosing Desderia."),
    "cancelled": ("Request cancelled", "Request {ref} was cancelled. {reason}"),
    "rejected": ("Request declined", "We could not process request {ref}. {reason}"),
    "expired": ("Request expired", "Request {ref} expired because funds did not arrive in time."),
}


def _money(amount, code):
    return f"{code} {amount:,.2f}"


def _send_email(to, subject, title, body, link=""):
    url = f"{settings.SITE_URL}{link}" if link.startswith("/") else link
    ctx = {"title": title, "body": body, "url": url, "site_url": settings.SITE_URL}
    text = render_to_string("email/notification.txt", ctx)
    html = render_to_string("email/notification.html", ctx)
    msg = EmailMultiAlternatives(f"Desderia: {subject}", text, settings.DEFAULT_FROM_EMAIL, to)
    msg.attach_alternative(html, "text/html")
    try:
        msg.send()
        return True
    except Exception:
        log.exception("Email delivery failed to %s", to)
        return False


def notify(user, event, title, body, link="", email=True):
    note = Notification.objects.create(user=user, event=event, title=title, body=body[:500], link=link)
    if email and user.notify_email and user.is_active:
        def _deliver():
            if _send_email([user.email], title, title, body, link):
                Notification.objects.filter(pk=note.pk).update(emailed=True)
        transaction.on_commit(_deliver)
    return note


def staff_recipients():
    User = get_user_model()
    return User.objects.filter(is_active=True, role__in=["teller", "manager", "admin"])


def notify_staff(event, ctx):
    copy = {
        "kyc_submitted": ("KYC to review", "{customer} submitted identity documents.", "/desk/kyc/"),
        "request_new": ("New exchange request", "{customer} submitted {ref}.", "/desk/r/{ref}/"),
        "offer_customer": ("Counter offer received", "{customer} proposed {rate} on {ref}.", "/desk/r/{ref}/"),
        "customer_paid": ("Customer reports payment", "{customer} reports paying {ref}, reference {txid}.",
                          "/desk/r/{ref}/"),
        "message": ("New chat message", "{customer}: {snippet}", "/desk/chat/{conv}/"),
        "contact": ("New contact message", "{name} wrote about {topic}. Ticket {ticket}.", "/admin/pages/contactmessage/"),
    }[event]
    fmt = {k: v for k, v in ctx.items()}
    fmt.setdefault("customer", "")
    if hasattr(fmt.get("customer"), "full_name"):
        fmt["customer"] = fmt["customer"].full_name
    title, body, link = copy[0], copy[1].format(**fmt), copy[2].format(**fmt)
    for staff in staff_recipients():
        # Chat messages notify in-app always, by email at most every 10 minutes per thread.
        email = True
        if event == "message":
            key = f"chatmail:{staff.pk}:{ctx.get('conv')}"
            email = cache.add(key, 1, 600)
        notify(staff, event, title, body, link, email=email)
    desk = getattr(settings, "BUREAU_DESK_EMAIL", "")
    if desk and event in ("request_new", "contact", "customer_paid"):
        transaction.on_commit(lambda: _send_email([desk], title, title, body, link))


def notify_request_status(req, reason=""):
    title, template = STATUS_COPY[req.status]
    pay_amount, pay_code = req.customer_pays
    body = template.format(
        ref=req.reference,
        rate=f"{req.effective_rate:,.2f}",
        pay=_money(pay_amount, pay_code),
        payout_ref=req.payout_reference or "",
        reason=reason or req.closed_reason or "",
    ).strip()
    notify(req.customer, f"request_{req.status}", title, body, f"/exchange/r/{req.reference}/")


def notify_offer(req, offer):
    notify(req.customer, "offer_received", "New rate offer",
           f"Desderia offered {offer.rate:,.2f} on {req.reference}. Accept or reply in the app.",
           f"/exchange/r/{req.reference}/")


def notify_chat_customer(conv, snippet):
    key = f"chatmail:{conv.customer_id}:{conv.pk}"
    email = cache.add(key, 1, 600)
    link = f"/exchange/r/{conv.request.reference}/" if conv.request_id else f"/exchange/support/{conv.pk}/"
    notify(conv.customer, "message", "New message from Desderia", snippet[:300], link, email=email)


def send_contact_ack(contact):
    body = (f"Hello {contact.name}, thank you for contacting Desderia Bureau De Change. "
            f"Your ticket number is {contact.ticket}. A member of our team will reply within one business day. "
            "For rates and requests you can also sign in to your account at any time.")
    transaction.on_commit(lambda: _send_email([contact.email], f"We received your message ({contact.ticket})",
                                              "We received your message", body, "/rates/"))
