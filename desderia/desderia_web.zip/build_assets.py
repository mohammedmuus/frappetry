"""Minify static/css/app.css and static/js/app.js into .min files.

Uses esbuild when Node is available (npx esbuild), otherwise a safe Python
fallback (CSS whitespace and comment removal, JS copied unchanged). Run it
after every CSS or JS change; the templates load only the .min files and
the manifest storage gives them content hashed names for long CDN caching.
"""

import re
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent / "static"
PAIRS = [(ROOT / "css/app.css", ROOT / "css/app.min.css"), (ROOT / "js/app.js", ROOT / "js/app.min.js")]


def esbuild(src, dst):
    npx = shutil.which("npx")
    if not npx:
        return False
    cmd = [npx, "-y", "esbuild", str(src), "--minify", f"--outfile={dst}", "--log-level=warning"]
    if src.suffix == ".js":
        cmd.append("--target=es2017")
    try:
        subprocess.run(cmd, check=True, timeout=120)
        return True
    except (subprocess.SubprocessError, OSError):
        return False


def css_fallback(text):
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"\s*([{}:;,>])\s*", r"\1", text)
    return text.replace(";}", "}").strip()


def main():
    for src, dst in PAIRS:
        before = src.stat().st_size
        if not esbuild(src, dst):
            if src.suffix == ".css":
                dst.write_text(css_fallback(src.read_text(encoding="utf-8")), encoding="utf-8")
            else:
                shutil.copyfile(src, dst)
        print(f"{dst.relative_to(ROOT)}: {before} -> {dst.stat().st_size} bytes")


if __name__ == "__main__":
    main()
