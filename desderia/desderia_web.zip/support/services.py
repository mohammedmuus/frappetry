from django.db import IntegrityError, transaction
from django.utils import timezone

from audit.services import record

from .models import Conversation, Message


class ChatError(Exception):
    pass


def conversation_for_request(req):
    conv, _ = Conversation.objects.get_or_create(
        request=req, defaults={"customer": req.customer, "subject": f"Request {req.reference}"})
    return conv


def can_access(user, conv):
    return user.is_bureau_staff or user.role == "auditor" or conv.customer_id == user.pk


def post_system(conv, body):
    msg = Message.objects.create(conversation=conv, kind=Message.KIND_SYSTEM, body=body[:2000], from_staff=True)
    Conversation.objects.filter(pk=conv.pk).update(last_message_at=msg.created_at)
    return msg


def post_message(conv, user, body, client_id=None):
    """Post a chat message. A repeated client_id returns the original message."""
    from notifications.services import notify_chat_customer, notify_staff

    body = (body or "").strip()
    if not body:
        raise ChatError("Write a message first.")
    if len(body) > 2000:
        raise ChatError("Messages are limited to 2000 characters.")
    if user.role == "auditor":
        raise ChatError("Auditors have read only access.")
    if not can_access(user, conv):
        raise ChatError("Not allowed.")
    if conv.status == Conversation.CLOSED and not user.is_bureau_staff:
        raise ChatError("This conversation is closed. Open a new one from Support.")
    if client_id:
        existing = Message.objects.filter(conversation=conv, client_id=client_id).first()
        if existing:
            return existing, False
    try:
        with transaction.atomic():
            msg = Message.objects.create(conversation=conv, sender=user, from_staff=user.is_bureau_staff,
                                         body=body, client_id=client_id)
            fields = {"last_message_at": msg.created_at}
            fields["staff_last_read" if user.is_bureau_staff else "customer_last_read"] = msg.created_at
            if conv.status == Conversation.CLOSED:
                fields["status"] = Conversation.OPEN
            Conversation.objects.filter(pk=conv.pk).update(**fields)
            record("chat.message", conv, f"Chat message in {conv.subject}",
                   data={"message_id": str(msg.pk), "length": len(body)})
            snippet = body[:140]
            if user.is_bureau_staff:
                notify_chat_customer(conv, snippet)
            else:
                notify_staff("message", {"customer": user, "snippet": snippet, "conv": conv.pk})
    except IntegrityError:
        return Message.objects.get(conversation=conv, client_id=client_id), False
    return msg, True


def mark_read(conv, user):
    field = "staff_last_read" if user.is_bureau_staff else "customer_last_read"
    if conv.customer_id == user.pk or user.is_bureau_staff:
        Conversation.objects.filter(pk=conv.pk).update(**{field: timezone.now()})


def serialise(msg, viewer):
    return {
        "id": str(msg.pk),
        "kind": msg.kind,
        "body": msg.body,
        "from_staff": msg.from_staff,
        "mine": msg.sender_id == viewer.pk,
        "sender": ("Desderia" if msg.from_staff else (msg.sender.first_name if msg.sender_id else "")),
        "at": msg.created_at.isoformat(),
    }
