from django.urls import path

from . import views

app_name = "support"

urlpatterns = [
    path("exchange/support/", views.support_home, name="home"),
    path("exchange/support/new/", views.support_new, name="new"),
    path("exchange/support/<uuid:pk>/", views.support_thread, name="thread"),
    path("chat/<uuid:pk>/messages/", views.chat_messages, name="messages"),
    path("chat/<uuid:pk>/send/", views.chat_send, name="send"),
]
