import uuid

from django.conf import settings
from django.db import models
from django.db.models import Q


class Conversation(models.Model):
    """A chat thread between one customer and the Desderia desk.

    Every exchange request gets its own thread automatically; customers can
    also open general support threads.
    """

    OPEN = "open"
    CLOSED = "closed"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    customer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="conversations")
    request = models.OneToOneField("exchange.ExchangeRequest", null=True, blank=True, on_delete=models.PROTECT,
                                   related_name="conversation")
    subject = models.CharField(max_length=120)
    status = models.CharField(max_length=8, choices=[(OPEN, "Open"), (CLOSED, "Closed")], default=OPEN)
    last_message_at = models.DateTimeField(auto_now_add=True, db_index=True)
    customer_last_read = models.DateTimeField(null=True, blank=True)
    staff_last_read = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-last_message_at"]
        constraints = [models.CheckConstraint(condition=Q(status__in=["open", "closed"]), name="conversation_status_valid")]

    def __str__(self):
        return self.subject

    def unread_for(self, user):
        mark = self.staff_last_read if user.is_bureau_staff else self.customer_last_read
        qs = self.messages.exclude(sender=user)
        if mark:
            qs = qs.filter(created_at__gt=mark)
        return qs.count()


class Message(models.Model):
    KIND_TEXT = "text"
    KIND_SYSTEM = "system"
    KIND_OFFER = "offer"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    conversation = models.ForeignKey(Conversation, on_delete=models.PROTECT, related_name="messages")
    sender = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT,
                               related_name="+")
    from_staff = models.BooleanField(default=False)
    kind = models.CharField(max_length=8, default=KIND_TEXT)
    body = models.TextField(max_length=2000)
    # Client generated id so a resend after a timeout never posts twice.
    client_id = models.UUIDField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["created_at"]
        constraints = [
            models.UniqueConstraint(fields=["conversation", "client_id"], condition=Q(client_id__isnull=False),
                                    name="message_client_id_unique"),
            models.CheckConstraint(condition=Q(kind__in=["text", "system", "offer"]), name="message_kind_valid"),
        ]

    def __str__(self):
        return self.body[:40]

    def save(self, *args, **kwargs):
        if not self._state.adding:
            raise PermissionError("Chat messages are append only")
        super().save(*args, **kwargs)
