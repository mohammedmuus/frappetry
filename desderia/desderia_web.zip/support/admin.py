from django.contrib import admin

from desderia.admin_mixins import NoDeleteAdmin, ReadOnlyAdmin

from .models import Conversation, Message


class MessageInline(ReadOnlyAdmin, admin.TabularInline):
    model = Message
    extra = 0
    fields = ["created_at", "sender", "from_staff", "kind", "body"]
    readonly_fields = fields


@admin.register(Conversation)
class ConversationAdmin(NoDeleteAdmin, admin.ModelAdmin):
    list_display = ["subject", "customer", "request", "status", "last_message_at"]
    list_filter = ["status"]
    search_fields = ["subject", "customer__email", "request__reference"]
    readonly_fields = ["customer", "request", "last_message_at", "customer_last_read", "staff_last_read", "created_at"]
    inlines = [MessageInline]


@admin.register(Message)
class MessageAdmin(ReadOnlyAdmin, admin.ModelAdmin):
    list_display = ["conversation", "sender", "from_staff", "kind", "short", "created_at"]
    list_filter = ["from_staff", "kind"]
    search_fields = ["body", "conversation__subject", "sender__email"]
    date_hierarchy = "created_at"

    @admin.display(description="Message")
    def short(self, obj):
        return obj.body[:80]
