import uuid

from django import forms
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import Http404, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils.dateparse import parse_datetime
from django.views.decorators.http import require_POST

from accounts.forms import style
from audit.services import record
from desderia.guards import rate_limit

from .models import Conversation
from .services import ChatError, can_access, mark_read, post_message, serialise


class NewConversationForm(forms.Form):
    subject = forms.CharField(max_length=120)
    body = forms.CharField(max_length=2000, label="Message", widget=forms.Textarea(attrs={"rows": 4}))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        style(self)


def _conv(request, pk):
    conv = get_object_or_404(Conversation.objects.select_related("request", "customer"), pk=pk)
    if not can_access(request.user, conv):
        raise Http404
    return conv


@login_required
def support_home(request):
    convs = Conversation.objects.filter(customer=request.user).select_related("request")[:50]
    rows = [(c, c.unread_for(request.user)) for c in convs]
    return render(request, "support_home.html", {"rows": rows, "form": NewConversationForm()})


@login_required
@require_POST
@rate_limit("conversation_new", limit=5, window=900)
def support_new(request):
    form = NewConversationForm(request.POST)
    if not form.is_valid():
        messages.error(request, "Add a subject and a message.")
        return redirect("support:home")
    conv = Conversation.objects.create(customer=request.user, subject=form.cleaned_data["subject"])
    record("chat.opened", conv, f"Support conversation opened: {conv.subject}")
    try:
        post_message(conv, request.user, form.cleaned_data["body"])
    except ChatError as exc:
        messages.error(request, str(exc))
    return redirect("support:thread", pk=conv.pk)


@login_required
def support_thread(request, pk):
    conv = _conv(request, pk)
    if conv.request_id and not request.user.is_bureau_staff:
        return redirect("exchange:request_detail", reference=conv.request.reference)
    mark_read(conv, request.user)
    chat = conv.messages.select_related("sender").order_by("-created_at")[:60][::-1]
    return render(request, "support_thread.html", {"conv": conv, "chat": chat})


# ─────────────────────────────────────────────────────────────
# JSON ENDPOINTS (polling chat used by web pages)
# ─────────────────────────────────────────────────────────────

@login_required
@rate_limit("chat_poll", limit=40, window=60, methods=("GET",))
def chat_messages(request, pk):
    conv = _conv(request, pk)
    qs = conv.messages.select_related("sender")
    after = parse_datetime(request.GET.get("after", "") or "")
    if after:
        qs = qs.filter(created_at__gt=after)
    msgs = list(qs.order_by("-created_at")[:60])[::-1]
    if msgs:
        mark_read(conv, request.user)
    return JsonResponse({"messages": [serialise(m, request.user) for m in msgs], "status": conv.status})


@login_required
@require_POST
@rate_limit("chat_send", limit=20, window=60)
def chat_send(request, pk):
    conv = _conv(request, pk)
    try:
        client_id = uuid.UUID(request.POST.get("client_id", ""))
    except ValueError:
        client_id = None
    try:
        msg, _ = post_message(conv, request.user, request.POST.get("body", ""), client_id=client_id)
    except ChatError as exc:
        return JsonResponse({"ok": False, "error": str(exc)}, status=400)
    return JsonResponse({"ok": True, "message": serialise(msg, request.user)})
