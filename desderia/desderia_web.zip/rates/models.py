from decimal import Decimal

from django.conf import settings
from django.db import models
from django.db.models import F, Q


class Currency(models.Model):
    code = models.CharField(primary_key=True, max_length=3)
    name = models.CharField(max_length=60)
    symbol = models.CharField(max_length=4, blank=True)
    decimals = models.PositiveSmallIntegerField(default=2)
    is_active = models.BooleanField(default=True)
    sort_order = models.PositiveSmallIntegerField(default=10)
    # Negotiation: a customer may propose a rate within this band of the board.
    negotiation_band_pct = models.DecimalField(max_digits=4, decimal_places=2, default=Decimal("1.50"))
    min_negotiable_amount = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("1000"))
    min_amount = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("10"))
    max_amount = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("100000"))
    # Approximate USD value of one unit, used only for KYC limits.
    usd_value = models.DecimalField(max_digits=12, decimal_places=6, default=Decimal("1"))

    class Meta:
        ordering = ["sort_order", "code"]
        verbose_name_plural = "currencies"
        constraints = [
            models.CheckConstraint(condition=Q(code__regex=r"^[A-Z]{3}$"), name="currency_code_iso"),
            models.CheckConstraint(condition=Q(min_amount__gt=0) & Q(max_amount__gt=F("min_amount")),
                                   name="currency_amount_range"),
            models.CheckConstraint(condition=Q(negotiation_band_pct__gte=0) & Q(negotiation_band_pct__lte=10),
                                   name="currency_band_range"),
        ]

    def __str__(self):
        return self.code

    @property
    def current_rate(self):
        return self.rates.order_by("-effective_at", "-id").first()


class ExchangeRate(models.Model):
    """Append only rate board. The newest row per currency is the live rate.

    buy_rate: TZS the bureau pays per unit when a customer SELLS foreign currency.
    sell_rate: TZS the customer pays per unit when BUYING foreign currency.
    """

    currency = models.ForeignKey(Currency, on_delete=models.PROTECT, related_name="rates")
    buy_rate = models.DecimalField(max_digits=14, decimal_places=4)
    sell_rate = models.DecimalField(max_digits=14, decimal_places=4)
    effective_at = models.DateTimeField(db_index=True)
    set_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="rates_set")
    note = models.CharField(max_length=160, blank=True)

    class Meta:
        ordering = ["-effective_at", "-id"]
        get_latest_by = "effective_at"
        constraints = [
            models.CheckConstraint(condition=Q(buy_rate__gt=0) & Q(sell_rate__gt=0), name="rate_positive"),
            # The bureau never buys higher than it sells: no negative spread.
            models.CheckConstraint(condition=Q(sell_rate__gte=F("buy_rate")), name="rate_spread_non_negative"),
        ]

    def __str__(self):
        return f"{self.currency_id} buy {self.buy_rate} sell {self.sell_rate}"

    @property
    def spread(self):
        return self.sell_rate - self.buy_rate

    def save(self, *args, **kwargs):
        if not self._state.adding:
            raise PermissionError("Rates are append only. Publish a new rate instead.")
        super().save(*args, **kwargs)
