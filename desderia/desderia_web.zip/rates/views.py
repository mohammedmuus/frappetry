from django.conf import settings
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.cache import cache_control

from desderia.guards import rate_limit

from .models import Currency


def board():
    rows = []
    for cur in Currency.objects.filter(is_active=True).exclude(code=settings.BASE_CURRENCY):
        rate = cur.current_rate
        if rate:
            rows.append({"code": cur.code, "name": cur.name, "symbol": cur.symbol,
                         "buy": rate.buy_rate, "sell": rate.sell_rate, "updated": rate.effective_at,
                         "min_negotiable": cur.min_negotiable_amount})
    return rows


def rate_board(request):
    return render(request, "rate_board.html", {"rows": board()})


@cache_control(public=True, max_age=30)
@rate_limit("rates_json", limit=60, window=60, methods=("GET",))
def rates_json(request):
    return JsonResponse({"base": settings.BASE_CURRENCY, "rates": [
        {**r, "buy": str(r["buy"]), "sell": str(r["sell"]), "updated": r["updated"].isoformat(),
         "min_negotiable": str(r["min_negotiable"])} for r in board()]})
