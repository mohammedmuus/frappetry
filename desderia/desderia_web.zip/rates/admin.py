from django.contrib import admin

from desderia.admin_mixins import NoDeleteAdmin, ReadOnlyAdmin

from .models import Currency, ExchangeRate


class RateInline(ReadOnlyAdmin, admin.TabularInline):
    model = ExchangeRate
    extra = 0
    fields = ["buy_rate", "sell_rate", "effective_at", "set_by", "note"]
    readonly_fields = fields
    ordering = ["-effective_at"]


@admin.register(Currency)
class CurrencyAdmin(NoDeleteAdmin, admin.ModelAdmin):
    list_display = ["code", "name", "is_active", "live_buy", "live_sell", "negotiation_band_pct",
                    "min_negotiable_amount", "min_amount", "max_amount", "sort_order"]
    list_editable = ["is_active", "sort_order"]
    search_fields = ["code", "name"]
    inlines = [RateInline]

    @admin.display(description="Buy")
    def live_buy(self, obj):
        r = obj.current_rate
        return r.buy_rate if r else "-"

    @admin.display(description="Sell")
    def live_sell(self, obj):
        r = obj.current_rate
        return r.sell_rate if r else "-"


@admin.register(ExchangeRate)
class ExchangeRateAdmin(ReadOnlyAdmin, admin.ModelAdmin):
    """Publish rates from the desk so every change is audited. History is read only."""

    list_display = ["currency", "buy_rate", "sell_rate", "effective_at", "set_by", "note"]
    list_filter = ["currency"]
    date_hierarchy = "effective_at"
