import secrets
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone

from rates.models import Currency, ExchangeRate

CURRENCIES = [
    # code, name, symbol, sort, usd_value, buy, sell, min_negotiable
    ("USD", "US Dollar", "$", 1, "1", "2575", "2615", "1000"),
    ("EUR", "Euro", "E", 2, "1.08", "2790", "2850", "1000"),
    ("GBP", "British Pound", "L", 3, "1.27", "3270", "3345", "1000"),
    ("KES", "Kenyan Shilling", "KSh", 4, "0.0077", "19.60", "20.40", "150000"),
    ("AED", "UAE Dirham", "AED", 5, "0.27", "695", "715", "4000"),
]


class Command(BaseCommand):
    help = "Create currencies, opening rates and (with --demo) demo accounts."

    def add_arguments(self, parser):
        parser.add_argument("--demo", action="store_true", help="Create demo staff and customer accounts")

    @transaction.atomic
    def handle(self, *args, **opts):
        User = get_user_model()
        Currency.objects.get_or_create(code="TZS", defaults={"name": "Tanzanian Shilling", "symbol": "TSh",
                                                             "sort_order": 0, "usd_value": Decimal("0.00039")})
        admin = User.objects.filter(is_superuser=True, is_active=True).first()
        for code, name, sym, order, usd, buy, sell, neg in CURRENCIES:
            cur, _ = Currency.objects.get_or_create(code=code, defaults={
                "name": name, "symbol": sym, "sort_order": order, "usd_value": Decimal(usd),
                "min_negotiable_amount": Decimal(neg),
                "max_amount": Decimal("100000") if code != "KES" else Decimal("15000000"),
                "min_amount": Decimal("10") if code != "KES" else Decimal("1000")})
            if cur.current_rate is None:
                setter = admin or self._system()
                ExchangeRate.objects.create(currency=cur, buy_rate=Decimal(buy), sell_rate=Decimal(sell),
                                            effective_at=timezone.now(), set_by=setter, note="Opening rate")
        self.stdout.write(self.style.SUCCESS("Currencies and opening rates ready."))

        if opts["demo"]:
            now = timezone.now()
            for email, role, name, phone in (
                ("manager@desderia.test", "manager", "Neema Manager", "+255700000001"),
                ("teller@desderia.test", "teller", "Baraka Teller", "+255700000002"),
                ("auditor@desderia.test", "auditor", "Rehema Auditor", "+255700000003"),
                ("client@desderia.test", "customer", "Juma Client", "+255700000004"),
            ):
                if User.objects.filter(email=email).exists():
                    continue
                password = secrets.token_urlsafe(12)
                User.objects.create_user(email=email, phone=phone, password=password, full_name=name, role=role,
                                         is_staff=False, email_verified_at=now, phone_verified_at=now)
                self.stdout.write(f"{role:9} {email}  password: {password}")
            from treasury.models import TreasuryAccount
            from treasury.services import post
            mgr = User.objects.get(email="manager@desderia.test")
            for code, amount in (("TZS", "500000000"), ("USD", "150000"), ("EUR", "40000"), ("GBP", "20000"),
                                 ("KES", "3000000"), ("AED", "60000")):
                if not TreasuryAccount.objects.filter(currency_id=code, balance__gt=0).exists():
                    post(code, "in", "opening", amount, mgr, note="Demo opening float")
            self.stdout.write(self.style.WARNING("Demo accounts are for local testing only. Never seed them in production."))

    def _system(self):
        from exchange.services import system_user
        return system_user()
