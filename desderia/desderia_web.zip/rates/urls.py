from django.urls import path

from . import views

app_name = "rates"

urlpatterns = [
    path("", views.rate_board, name="board"),
    path("live.json", views.rates_json, name="json"),
]
