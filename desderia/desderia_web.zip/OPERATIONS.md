# How the Desderia apps operate

One server, two front doors. Customers use the website or the mobile app; staff use the website desk. Everything below is identical on web and mobile because both call the same services.

## People and where they work

| Who | Where | Main jobs |
|---|---|---|
| Customer | Mobile app or website `/exchange/` | Request exchanges, negotiate, pay, receive, chat |
| Teller | Website `/desk/` | Review and approve, negotiate, confirm funds, pay out, KYC, chat |
| Manager | Website `/desk/`, `/reports/`, `/audit/` | Everything a teller does, publish rates, record float movements, reports |
| Auditor | Website `/audit/`, `/reports/` | Read and verify the audit trail, download reports |
| Administrator | `/management/` | Users, roles, groups, every record in the system |

## The life of an exchange request

```
Customer submits ──► Submitted ──► (optional) Negotiating ──► Approved ──► Funds received ──► Paid out ──► Completed
                         │                 │                      │
                         └──► Rejected     └──► Cancelled         └──► Expired (not funded in 24 hours)
```

1. **Submit.** The customer picks buy or sell, currency, amount, how they will pay (CashPay, bank transfer, cash) and how they receive (bank wire, mobile money, cash pickup). The live board rate is locked for 10 minutes. A reference like `DSD-7K2M9QXA` is issued. The customer gets an email and an in app notification; every teller gets a notification.
2. **Review.** A teller opens it from the queue (oldest first), clicks **Assign to me**, checks the customer's KYC and history, then either **Approves** at the locked rate, sends a **counter offer**, or **Rejects** with a reason. If the lock expired and the market moved, Approve automatically sends the customer today's rate as an offer instead.
3. **Negotiate (amounts from 1,000 USD equivalent).** The customer proposes a rate within the published band (1.5 percent by default, set per currency in management). Staff accept, decline or counter. Only one offer is open at a time. Accepting fixes the rate and approves the request. Each customer can make 5 offers per request.
4. **Pay.** The customer sees exactly what to pay and how:
   - CashPay: the customer confirms their M-Pesa, Mixx by Yas or Airtel Money number and taps Pay. A USSD prompt arrives on that phone; they enter their PIN. CashPay notifies the server and the request turns to Funds received by itself, with the mobile money receipt number as the reference. If the prompt is missed or fails, they can send a new one after 2 minutes.
   - Bank transfer: bank details and the reference to quote are shown. The customer taps **I have paid** and types the bank reference.
   - Cash: the customer brings it to the branch and quotes the reference.
5. **Confirm funds.** The teller checks the money on the statement or in the till, then enters the reference in **Confirm funds**. The reference can never be used again on any request. The currency balance goes up automatically.
6. **Pay out.** The teller (a different one for amounts at or above 5,000,000 TZS) sends the wire, mobile money or cash and records the payout reference. The system refuses if the float in that currency is too low. The balance goes down automatically.
7. **Complete.** The customer taps **Confirm receipt** in the app, or staff mark it completed.

Unfunded approved requests expire after 24 hours (the `expire_requests` job runs every 15 minutes).

## Daily routine

**Opening (manager)**
1. `/desk/rates/`: publish today's buy and sell rates. Changes above 5 percent need the confirmation tick.
2. `/desk/balances/`: record the opening float or top ups per currency with a note (vault count, bank slip).

**During the day (tellers)**
- Work the queue at `/desk/queue/` and the chat inbox at `/desk/chat/`.
- Review identity documents at `/desk/kyc/`. Customers above 1,000 USD equivalent need approved KYC.
- Answer contact form messages in `/management/pages/contactmessage/` (each visitor already received an automatic acknowledgement with a ticket number).

**Closing (manager)**
1. `/desk/balances/`: compare system balances with the vault and bank. Record any difference as an adjustment with a note.
2. `/reports/`: download the day's requests, payments, ledger and volume summary as Excel.

**Compliance (auditor, any time)**
- `/audit/` lists every action with who, when, from which IP and channel.
- `/audit/verify/` recomputes the hash chain. A nightly job does the same and logs the result. A broken chain names the exact entry that was altered or removed.

## Chat

- Every request has its own chat thread, shown on the request page (web) and behind the chat button (app). Status changes and offers appear in the thread automatically.
- Customers can also open general support threads from **Chat**.
- Staff see all threads in `/desk/chat/`, newest first, with unread counts, and can close or reopen general threads.
- The customer gets an email when the desk replies (at most one per thread every 10 minutes, so a busy chat does not flood their inbox). Staff get the same.

## Automated emails

| Event | Who gets it |
|---|---|
| Sign in code, verification code | The customer (email or SMS) |
| Request submitted, approved, funded, paid out, completed, cancelled, rejected, expired | The customer |
| New rate offer from Desderia | The customer |
| New request, customer offer, customer reports payment, new chat message, new KYC, new contact message | Staff (and `BUREAU_DESK_EMAIL` for the important ones) |
| KYC approved or rejected | The customer |
| Contact form acknowledgement with ticket number | The visitor |

Every email sent is listed in `/management/notifications/emaillog/` with recipient, subject and delivery result. Customers can switch request emails off under Account.

## Reports

`/reports/` (managers, admins, auditors). Choose dates, then download:

| Report | Contents |
|---|---|
| Exchange requests | Every request with customer, rates, amounts, methods, references and the staff who approved, funded and paid out |
| Payments | Every payment with gateway, status and settlement reference |
| Treasury ledger | Every money movement with running balance |
| Volume summary | Completed deals per currency and side, with totals as live Excel formulas |
| Balances snapshot | Current holding per currency |
| Audit trail | All audit entries with their hashes |

Each workbook has the Desderia header, filters, frozen headings, real `SUM` formulas and a Notes sheet stating the scope and whether it contains personal data. Every download is itself recorded in the audit trail. In `/management/`, any list can also be exported: tick rows, choose **Download selected as Excel**.

## Management portal

`/management/` (superusers and admins). Sign in goes through the normal two step login.

- **Users and groups**: create staff, set roles, deactivate leavers (accounts are never deleted, so history stays intact).
- **Currencies**: activate currencies, set negotiation band, minimum negotiable amount and limits.
- **Everything else** is visible: KYC profiles, device tokens, one time code records (never the codes), requests with their offers, payments and timeline, gateway events, ledger and balances, chats and messages, notifications, email log, contact messages, audit entries.
- Money and history records are read only here on purpose. They change only through the desk, which locks, checks and audits each step.

## Mobile app, from the customer's side

1. **Welcome**: open an account or sign in.
2. **Sign in**: email and password, then the six digit code (email or SMS).
3. **Verify**: new accounts confirm email and phone before trading.
4. **Home**: greeting, identity banner if KYC is needed, recent requests, live rates.
5. **New exchange** (centre button): live quote updates as you type; dependent menus only show valid methods and matching beneficiaries.
6. **Request page**: amounts, locked or agreed rate, payment instructions, offers with Accept and Decline, propose a rate, timeline, cancel, confirm receipt, and the chat button.
7. **Chat**: request threads and general support.
8. **Account**: KYC upload (camera or gallery), beneficiaries, notifications, email preference, sign out.

The app signs out after 15 minutes in the background, blocks screenshots on Android, and keeps the token in the phone's secure keystore.

## When something goes wrong

| Symptom | Check |
|---|---|
| Customer says the code never arrived | `/management/notifications/emaillog/` for email; SMS provider dashboard for SMS. They can resend after 60 seconds. If delivery is down: Management, Users, tick the customer, action **Generate a backup one time code**, give a reason, and read the code to them on a call to their registered number or at the counter after checking ID. A sign in code still needs their password. Limit 3 per customer per hour, every use is audited |
| Customer cannot finish verification and you have seen their ID | Management, Users, tick the customer, action **Mark email as verified** or **Mark phone as verified** (audited) |
| "Too many failed sign in attempts" | Wait 5 minutes, or check `logs/security.log` for the IP |
| Payout refused for insufficient balance | Record a float top up in `/desk/balances/` first |
| "Dual control" message | A different staff member must record the payout |
| CashPay payments not confirming | `/management/payments/gatewayevent/` shows every callback with its note (settled, failed, held for review with the reason, unknown transaction). No events at all means CashPay is not calling: check the callback URL registered with CashPay support |
| "Money received but not settled" alert | The customer approved two prompts. One settled the request; refund the other receipt shown in the alert |
| A new mobile number range is refused or shown as unknown | Add it in `/management/accounts/mobileprefix/` with its operator and wallet |
| Audit verification failed | Treat as a security incident. The page names the first bad entry |
