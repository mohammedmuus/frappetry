from django.urls import path

from . import views

app_name = "desk"

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("queue/", views.queue, name="queue"),
    path("r/<str:reference>/", views.request_detail, name="request_detail"),
    path("r/<str:reference>/action/", views.request_action, name="request_action"),
    path("kyc/", views.kyc_list, name="kyc_list"),
    path("kyc/<int:pk>/review/", views.kyc_review, name="kyc_review"),
    path("rates/", views.rates, name="rates"),
    path("customers/", views.customers, name="customers"),
    path("chat/", views.inbox, name="inbox"),
    path("chat/<uuid:pk>/", views.chat_thread, name="chat_thread"),
    path("payments/", views.recent_payments, name="payments"),
]
