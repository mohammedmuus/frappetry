import csv
from datetime import timedelta
from decimal import Decimal, InvalidOperation

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.core.paginator import Paginator
from django.db import transaction
from django.db.models import Count, Q, Sum
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from accounts.models import KycProfile
from audit.services import record
from desderia.guards import rate_limit
from exchange import services
from exchange.forms import OfferForm
from exchange.models import ExchangeRequest
from notifications.services import notify
from payments.models import Payment
from rates.models import Currency, ExchangeRate
from support.models import Conversation
from support.services import conversation_for_request, mark_read

User = get_user_model()


def csv_safe(value):
    """Stop spreadsheet formula injection in exported cells."""
    text = "" if value is None else str(value)
    return "'" + text if text[:1] in ("=", "+", "-", "@", "\t", "\r") else text


@login_required
def dashboard(request):
    today = timezone.localdate()
    reqs = ExchangeRequest.objects.all()
    by_status = dict(reqs.values_list("status").annotate(n=Count("id")))
    today_done = reqs.filter(status=ExchangeRequest.COMPLETED, completed_at__date=today)
    volume = today_done.aggregate(t=Sum("local_amount"))["t"] or 0
    unread = sum(1 for c in Conversation.objects.filter(status="open")[:200] if c.unread_for(request.user))
    return render(request, "desk_dashboard.html", {
        "by_status": by_status,
        "awaiting_review": by_status.get("submitted", 0) + by_status.get("negotiating", 0),
        "awaiting_funds": by_status.get("approved", 0),
        "awaiting_payout": by_status.get("funded", 0),
        "today_count": today_done.count(),
        "today_volume": volume,
        "kyc_pending": KycProfile.objects.filter(status=KycProfile.STATUS_PENDING).count(),
        "unread_chats": unread,
        "queue": reqs.filter(status__in=ExchangeRequest.OPEN_STATUSES).select_related("customer", "currency")
                    .order_by("created_at")[:8],
        "board": [(c, c.current_rate) for c in Currency.objects.filter(is_active=True)
                  .exclude(code=settings.BASE_CURRENCY)],
    })


@login_required
def queue(request):
    qs = ExchangeRequest.objects.select_related("customer", "currency", "assigned_to")
    status = request.GET.get("status", "open")
    q = request.GET.get("q", "").strip()[:60]
    if status == "open":
        qs = qs.filter(status__in=ExchangeRequest.OPEN_STATUSES).order_by("created_at")
    elif status == "mine":
        qs = qs.filter(assigned_to=request.user, status__in=ExchangeRequest.OPEN_STATUSES)
    elif status in dict(ExchangeRequest.STATUS_CHOICES):
        qs = qs.filter(status=status)
    if q:
        qs = qs.filter(Q(reference__icontains=q) | Q(customer__email__icontains=q)
                       | Q(customer__full_name__icontains=q) | Q(customer__phone__icontains=q))
    if request.GET.get("export") == "csv" and (request.user.role in ("manager", "admin") or request.user.is_superuser):
        return _export_requests(request, qs)
    page = Paginator(qs, 20).get_page(request.GET.get("page"))
    return render(request, "desk_queue.html", {"page": page, "status": status, "q": q,
                                               "statuses": ExchangeRequest.STATUS_CHOICES})


def _export_requests(request, qs):
    record("export.requests", None, f"Requests exported ({qs.count()} rows)", data={"filter": request.GET.dict()})
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = f'attachment; filename="desderia-requests-{timezone.localdate()}.csv"'
    w = csv.writer(response)
    w.writerow(["Reference", "Created", "Customer", "Email", "Direction", "Currency", "Foreign amount",
                "Board rate", "Agreed rate", "Local amount TZS", "Status", "Funding ref", "Payout ref"])
    for r in qs[:5000]:
        w.writerow([csv_safe(x) for x in (
            r.reference, timezone.localtime(r.created_at).strftime("%Y-%m-%d %H:%M"), r.customer.full_name,
            r.customer.email, r.get_direction_display(), r.currency_id, r.foreign_amount, r.board_rate,
            r.agreed_rate or "", r.local_amount, r.get_status_display(), r.funding_reference, r.payout_reference)])
    return response


@login_required
def request_detail(request, reference):
    req = get_object_or_404(ExchangeRequest.objects.select_related("customer", "currency", "beneficiary",
                                                                   "approved_by", "funds_confirmed_by"),
                            reference=reference)
    conv = conversation_for_request(req)
    mark_read(conv, request.user)
    rate = req.currency.current_rate
    return render(request, "desk_request.html", {
        "req": req,
        "kyc": getattr(req.customer, "kyc", None),
        "events": req.events.select_related("actor"),
        "offers": req.offers.select_related("made_by"),
        "pending_offer": req.pending_offer,
        "payments": req.payments.all(),
        "offer_form": OfferForm(),
        "conv": conv,
        "chat": conv.messages.select_related("sender").order_by("-created_at")[:60][::-1],
        "live_rate": services.board_rate_for(rate, req.direction) if rate else None,
        "dual_control": req.local_amount >= settings.DUAL_CONTROL_THRESHOLD_TZS,
        "history_count": ExchangeRequest.objects.filter(customer=req.customer, status="completed").count(),
    })


@login_required
@require_POST
@rate_limit("desk_action", limit=60, window=60)
def request_action(request, reference):
    req = get_object_or_404(ExchangeRequest, reference=reference)
    action = request.POST.get("action", "")
    user = request.user
    try:
        if action == "assign":
            ExchangeRequest.objects.filter(pk=req.pk).update(assigned_to=user)
            record("request.assigned", req, f"{req.reference} assigned to {user.email}")
            messages.success(request, "Assigned to you.")
        elif action == "approve":
            _, offer = services.approve(req, user)
            messages.success(request, "Quote expired, so a fresh offer at today's rate was sent."
                             if offer else "Request approved.")
        elif action == "reject":
            services.reject(req, user, request.POST.get("reason", ""))
            messages.success(request, "Request rejected.")
        elif action == "offer":
            form = OfferForm(request.POST)
            if not form.is_valid():
                raise services.ExchangeError("Enter a valid rate.")
            services.make_offer(req, user, form.cleaned_data["rate"], form.cleaned_data["message"])
            messages.success(request, "Counter offer sent.")
        elif action in ("accept_offer", "decline_offer"):
            services.respond_offer(req, request.POST.get("offer_id"), user, action == "accept_offer")
            messages.success(request, "Offer accepted." if action == "accept_offer" else "Offer declined.")
        elif action == "confirm_funds":
            services.confirm_funds(req, user, request.POST.get("reference", ""))
            messages.success(request, "Funds confirmed.")
        elif action == "paid_out":
            services.mark_paid_out(req, user, request.POST.get("reference", ""))
            messages.success(request, "Payout recorded.")
        elif action == "complete":
            services.complete(req, user)
            messages.success(request, "Request completed.")
        else:
            messages.error(request, "Unknown action.")
    except (services.ExchangeError, ValueError, ValidationError) as exc:
        if isinstance(exc, ValidationError):
            exc = "Invalid input."
        messages.error(request, str(exc))
    return redirect("desk:request_detail", reference=reference)


# ─────────────────────────────────────────────────────────────
# KYC REVIEW
# ─────────────────────────────────────────────────────────────

@login_required
def kyc_list(request):
    status = request.GET.get("status", KycProfile.STATUS_PENDING)
    qs = KycProfile.objects.select_related("user", "reviewed_by")
    if status in dict(KycProfile.STATUS_CHOICES):
        qs = qs.filter(status=status)
    page = Paginator(qs.order_by("submitted_at"), 20).get_page(request.GET.get("page"))
    return render(request, "desk_kyc.html", {"page": page, "status": status, "statuses": KycProfile.STATUS_CHOICES})


@login_required
@require_POST
@rate_limit("kyc_review", limit=60, window=60)
def kyc_review(request, pk):
    with transaction.atomic():
        kyc = get_object_or_404(KycProfile.objects.select_for_update(), pk=pk)
        if kyc.user_id == request.user.pk:
            messages.error(request, "You cannot review your own KYC.")
            return redirect("desk:kyc_list")
        decision = request.POST.get("decision")
        note = request.POST.get("note", "")[:255]
        if decision not in ("approve", "reject") or (decision == "reject" and not note.strip()):
            messages.error(request, "Choose a decision. A rejection needs a reason.")
            return redirect("desk:kyc_list")
        kyc.status = KycProfile.STATUS_APPROVED if decision == "approve" else KycProfile.STATUS_REJECTED
        kyc.review_note = note
        kyc.reviewed_by = request.user
        kyc.reviewed_at = timezone.now()
        kyc.save()
        record(f"kyc.{kyc.status}", kyc, f"KYC of {kyc.user.email} {kyc.status}", data={"note": note})
        notify(kyc.user, "kyc_reviewed", "Identity check " + ("approved" if decision == "approve" else "declined"),
               "Your identity documents are approved. Higher limits are now available."
               if decision == "approve" else f"We could not approve your documents. {note}", "/account/kyc/")
    messages.success(request, "KYC decision saved.")
    return redirect("desk:kyc_list")


# ─────────────────────────────────────────────────────────────
# RATES (manager)
# ─────────────────────────────────────────────────────────────

@login_required
@rate_limit("rates", limit=30, window=300)
def rates(request):
    currencies = Currency.objects.filter(is_active=True).exclude(code=settings.BASE_CURRENCY)
    if request.method == "POST":
        published = 0
        errors = []
        with transaction.atomic():
            for cur in currencies:
                buy_raw = request.POST.get(f"buy_{cur.code}", "").replace(",", "").strip()
                sell_raw = request.POST.get(f"sell_{cur.code}", "").replace(",", "").strip()
                if not buy_raw and not sell_raw:
                    continue
                try:
                    buy, sell = Decimal(buy_raw), Decimal(sell_raw)
                except InvalidOperation:
                    errors.append(f"{cur.code}: enter numbers for both rates.")
                    continue
                if buy <= 0 or sell < buy:
                    errors.append(f"{cur.code}: sell rate must be at or above the buy rate.")
                    continue
                current = cur.current_rate
                if current and (abs(sell - current.sell_rate) / current.sell_rate > Decimal("0.05")
                                and request.POST.get("confirm_large") != "1"):
                    errors.append(f"{cur.code}: change above 5 percent. Tick the confirmation box to publish.")
                    continue
                if current and current.buy_rate == buy and current.sell_rate == sell:
                    continue
                rate = ExchangeRate.objects.create(currency=cur, buy_rate=buy, sell_rate=sell,
                                                   effective_at=timezone.now(), set_by=request.user,
                                                   note=request.POST.get("note", "")[:160])
                record("rate.published", rate, f"{cur.code} buy {buy} sell {sell}",
                       data={"currency": cur.code, "buy": str(buy), "sell": str(sell),
                             "previous_buy": str(current.buy_rate) if current else "",
                             "previous_sell": str(current.sell_rate) if current else ""})
                published += 1
        for e in errors:
            messages.error(request, e)
        if published:
            messages.success(request, f"{published} rate(s) published.")
        return redirect("desk:rates")
    history = ExchangeRate.objects.select_related("currency", "set_by")[:40]
    return render(request, "desk_rates.html", {"rows": [(c, c.current_rate) for c in currencies],
                                               "history": history})


# ─────────────────────────────────────────────────────────────
# CUSTOMERS AND CHAT INBOX
# ─────────────────────────────────────────────────────────────

@login_required
def customers(request):
    q = request.GET.get("q", "").strip()[:60]
    qs = User.objects.filter(role=User.ROLE_CUSTOMER).annotate(n=Count("exchange_requests"))
    if q:
        qs = qs.filter(Q(email__icontains=q) | Q(full_name__icontains=q) | Q(phone__icontains=q))
    page = Paginator(qs.order_by("-date_joined"), 25).get_page(request.GET.get("page"))
    return render(request, "desk_customers.html", {"page": page, "q": q})


@login_required
def inbox(request):
    convs = Conversation.objects.select_related("customer", "request").order_by("-last_message_at")[:80]
    rows = [(c, c.unread_for(request.user)) for c in convs]
    return render(request, "desk_inbox.html", {"rows": rows})


@login_required
def chat_thread(request, pk):
    conv = get_object_or_404(Conversation.objects.select_related("customer", "request"), pk=pk)
    mark_read(conv, request.user)
    if request.method == "POST" and request.POST.get("action") in ("close", "reopen"):
        Conversation.objects.filter(pk=conv.pk).update(status="closed" if request.POST["action"] == "close" else "open")
        record("chat.status", conv, f"Conversation {request.POST['action']}d")
        return redirect("desk:chat_thread", pk=pk)
    chat = conv.messages.select_related("sender").order_by("-created_at")[:80][::-1]
    return render(request, "desk_chat.html", {"conv": conv, "chat": chat})


@login_required
def recent_payments(request):
    since = timezone.now() - timedelta(days=30)
    payments = Payment.objects.filter(created_at__gte=since).select_related("request", "confirmed_by")[:200]
    return render(request, "desk_payments.html", {"payments": payments})
