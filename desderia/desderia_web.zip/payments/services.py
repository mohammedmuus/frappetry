import ipaddress
import secrets
from decimal import Decimal, InvalidOperation

from django.conf import settings
from django.db import IntegrityError, transaction
from django.utils import timezone
from django.utils.crypto import constant_time_compare

from accounts.models import User
from audit.services import record
from exchange.models import ExchangeRequest
from exchange.services import ExchangeError, confirm_funds, system_user
from notifications.services import notify, notify_staff

from .gateways import (CashPayGateway, GatewayError, cashpay_amount, cashpay_phone, get_gateway,
                       transaction_number)
from .models import GatewayEvent, Payment


def _new_reference(req):
    # Alphanumeric only: CashPay rejects other characters in transactionNumber.
    return f"{req.reference.replace('-', '')}P{secrets.token_hex(3).upper()}"


def _lock_approved(req, customer):
    req = ExchangeRequest.objects.select_for_update().get(pk=req.pk)
    if req.customer_id != customer.pk:
        raise ExchangeError("Not allowed.")
    if req.status != ExchangeRequest.APPROVED:
        raise ExchangeError("This request is not waiting for payment.")
    if req.payments.filter(status=Payment.PAID).exists():
        raise ExchangeError("This request is already paid.")
    return req


def start_payment(req, customer, phone=None):
    """Bank and cash: one pending payment record the teller later confirms.
    CashPay: generate a reference and send a USSD prompt to the customer's wallet.

    A customer who missed the prompt may ask again after CASHPAY_RESEND_AFTER
    seconds. The old attempt is cancelled and a new transactionNumber is used
    (CashPay refuses duplicates). If the old prompt is paid late anyway, the
    callback still settles it, or flags it for refund if another one won.
    """
    if req.funding_method != ExchangeRequest.FUND_CASHPAY:
        with transaction.atomic():
            req = _lock_approved(req, customer)
            pending = req.payments.filter(status=Payment.PENDING).first()
            if pending:
                return pending, None
            amount, code = req.customer_pays
            payment = Payment.objects.create(request=req, gateway="manual", amount=amount, currency=code,
                                             reference=_new_reference(req), created_by=customer)
            record("payment.started", payment, f"Payment {payment.reference} opened for {req.reference}",
                   data={"amount": str(amount), "currency": code, "method": req.funding_method})
        return payment, get_gateway("manual").create_charge(payment)

    gateway = get_gateway("cashpay")
    if not gateway.is_configured():
        raise ExchangeError("CashPay is not available right now. Please contact us to change the payment method.")
    try:
        wallet = cashpay_phone(phone or customer.phone)
    except GatewayError as exc:
        raise ExchangeError(str(exc))

    # Step 1, inside a short lock: decide whether a new prompt is allowed and
    # create the payment row. The network calls happen outside the lock.
    with transaction.atomic():
        req = _lock_approved(req, customer)
        pending = req.payments.filter(status=Payment.PENDING, gateway="cashpay").first()
        if pending and pending.pushed_at:
            age = (timezone.now() - pending.pushed_at).total_seconds()
            if age < settings.CASHPAY_RESEND_AFTER:
                wait = int(settings.CASHPAY_RESEND_AFTER - age)
                raise ExchangeError(f"A payment prompt was already sent to {pending.payer_phone}. "
                                    f"Check your phone, or try again in {wait} seconds.")
        if pending:
            Payment.objects.filter(pk=pending.pk).update(status=Payment.CANCELLED,
                                                         failure_reason="Replaced by a new prompt")
        amount, _code = req.customer_pays
        payment = Payment.objects.create(request=req, gateway="cashpay", amount=cashpay_amount(amount),
                                         currency=settings.BASE_CURRENCY, reference=_new_reference(req),
                                         created_by=customer, payer_phone=wallet)

    # Step 2: talk to CashPay.
    try:
        result = gateway.create_charge(payment, wallet)
    except GatewayError as exc:
        Payment.objects.filter(pk=payment.pk).update(status=Payment.FAILED, failure_reason=str(exc)[:255])
        record("payment.push_failed", payment, f"CashPay prompt failed for {req.reference}",
               data={"reason": str(exc), "phone": wallet})
        raise ExchangeError(str(exc))
    Payment.objects.filter(pk=payment.pk).update(provider_reference=result.provider_reference,
                                                 pushed_at=timezone.now())
    record("payment.pushed", payment, f"CashPay prompt sent for {req.reference} to {wallet}",
           data={"transaction": transaction_number(payment.reference), "cashpay_reference": result.provider_reference,
                 "amount": str(payment.amount)})
    payment.refresh_from_db()
    return payment, result


@transaction.atomic
def customer_claims_paid(req, customer, reference):
    """Customer typed the bank or mobile money reference after paying."""
    if req.funding_method == ExchangeRequest.FUND_CASHPAY:
        raise ExchangeError("CashPay payments are confirmed automatically. Use Pay with CashPay instead.")
    reference = (reference or "").strip().upper()[:64]
    if len(reference) < 4:
        raise ExchangeError("Enter the full payment reference from your bank or receipt.")
    payment, _ = start_payment(req, customer)
    if Payment.objects.filter(customer_reference=reference).exclude(pk=payment.pk).exists():
        raise ExchangeError("This reference was already submitted for another payment.")
    Payment.objects.filter(pk=payment.pk).update(customer_reference=reference)
    record("payment.claimed", payment, f"Customer reports paying {req.reference}, reference {reference}",
           data={"reference": reference})
    notify_staff("customer_paid", {"customer": customer, "ref": req.reference, "txid": reference})
    return payment


# ─────────────────────────────────────────────────────────────
# CASHPAY CALLBACK
# ─────────────────────────────────────────────────────────────

def _ip_allowed(ip):
    allowed = settings.CASHPAY_ALLOWED_IPS
    if not allowed:
        return True
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False
    for entry in allowed:
        try:
            if addr in ipaddress.ip_network(entry, strict=False):
                return True
        except ValueError:
            continue
    return False


def _note(event, text, payment=None):
    fields = {"note": text[:255]}
    if payment is not None:
        fields["payment"] = payment
    GatewayEvent.objects.filter(pk=event.pk).update(**fields)


def handle_cashpay_callback(secret, body, ip):
    """Returns (http_status, message). Order: path secret, IP, parse, record, match, settle."""
    gateway = get_gateway("cashpay")
    if not gateway.is_configured():
        return 503, "disabled"
    if not constant_time_compare(secret or "", settings.CASHPAY_CALLBACK_SECRET):
        return 404, "not found"
    if not _ip_allowed(ip):
        return 403, "forbidden"
    try:
        data = CashPayGateway.parse_callback(body)
    except (ValueError, TypeError):
        return 400, "bad payload"
    if not data.transaction_number or data.status not in ("SUCCESS", "FAILED"):
        return 400, "missing fields"

    try:
        with transaction.atomic():
            event = GatewayEvent.objects.create(gateway="cashpay", event_reference=data.event_reference,
                                                verified=True, payload=_safe_json(body), ip_address=ip)
    except IntegrityError:
        return 200, "duplicate ignored"

    # Our payment reference is alphanumeric, so it is the transactionNumber itself.
    payment = (Payment.objects.select_related("request", "request__customer")
               .filter(gateway="cashpay", reference=data.transaction_number).first())
    if payment is None:
        _note(event, "unknown transactionNumber")
        return 200, "unknown transaction"
    req = payment.request

    # Every field must match what we sent. The callback is unsigned, so a
    # mismatch is never settled; it is stored for review instead.
    problems = []
    if payment.provider_reference and data.reference_number != payment.provider_reference:
        problems.append("referenceNumber does not match")
    if data.phone and payment.payer_phone and data.phone != payment.payer_phone:
        problems.append("phone does not match")
    try:
        paid_amount = Decimal(data.amount)
    except (InvalidOperation, ValueError):
        paid_amount = None
    if data.status == "SUCCESS" and (paid_amount is None or paid_amount.quantize(Decimal("1")) != payment.amount.quantize(Decimal("1"))):
        problems.append(f"amount {data.amount} does not match {payment.amount}")
    if data.status == "SUCCESS" and not data.receipt_number:
        problems.append("receiptNumber missing")
    if problems:
        _note(event, "; ".join(problems), payment)
        record("payment.callback_rejected", payment, f"CashPay callback rejected for {req.reference}",
               data={"problems": problems, "ip": ip})
        notify_staff("customer_paid", {"customer": req.customer, "ref": req.reference,
                                       "txid": f"CashPay callback needs review: {'; '.join(problems)}"})
        return 200, "held for review"

    if data.status == "FAILED":
        if payment.status == Payment.PENDING:
            from django.db.models import F
            ExchangeRequest.objects.filter(pk=req.pk, status=ExchangeRequest.APPROVED).update(version=F("version") + 1)
            Payment.objects.filter(pk=payment.pk, status=Payment.PENDING).update(
                status=Payment.FAILED, provider=data.provider, failure_reason="Customer did not complete the payment")
            notify(req.customer, "payment_failed", "Payment not completed",
                   f"Your CashPay payment for {req.reference} was not completed. You can send a new prompt from the request.",
                   f"/exchange/r/{req.reference}/")
        _note(event, "payment failed", payment)
        return 200, "failed noted"

    # SUCCESS
    Payment.objects.filter(pk=payment.pk).update(provider=data.provider)
    try:
        confirm_funds(req, system_user(), data.receipt_number, payment=payment, amount=paid_amount)
    except ExchangeError as exc:
        # Typical case: an older prompt paid after a newer one already settled.
        _note(event, f"not settled: {exc}", payment)
        record("payment.needs_refund", payment, f"CashPay money received but not settled for {req.reference}",
               data={"receipt": data.receipt_number, "amount": data.amount, "reason": str(exc)})
        for staff in User.objects.filter(is_active=True, role__in=["manager", "admin"]):
            notify(staff, "payment_review", "CashPay payment needs review",
                   f"Receipt {data.receipt_number} for {req.reference} ({data.amount} TZS) was received but not "
                   f"applied: {exc}. Check and refund if it is a duplicate.", f"/desk/r/{req.reference}/")
        return 200, "held for review"
    _note(event, "settled", payment)
    return 200, "settled"


def _safe_json(body):
    import json
    try:
        return json.loads(body)
    except ValueError:
        return {"raw": body[:2000].decode("utf-8", "replace")}
