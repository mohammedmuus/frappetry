import secrets

from django.db import IntegrityError, transaction

from audit.services import record
from exchange.models import ExchangeRequest
from exchange.services import ExchangeError, confirm_funds, system_user
from notifications.services import notify_staff

from .gateways import get_gateway
from .models import GatewayEvent, Payment


def _new_reference(req):
    return f"{req.reference}-P{secrets.token_hex(3).upper()}"


@transaction.atomic
def start_payment(req, customer):
    """Create (or reuse) the single pending payment for an approved request."""
    req = ExchangeRequest.objects.select_for_update().get(pk=req.pk)
    if req.customer_id != customer.pk:
        raise ExchangeError("Not allowed.")
    if req.status != ExchangeRequest.APPROVED:
        raise ExchangeError("This request is not waiting for payment.")
    if req.payments.filter(status=Payment.PAID).exists():
        raise ExchangeError("This request is already paid.")
    pending = req.payments.filter(status=Payment.PENDING).first()
    if pending:
        return pending, None
    amount, code = req.customer_pays
    slug = "cashpay" if req.funding_method == ExchangeRequest.FUND_CASHPAY else "manual"
    gateway = get_gateway(slug)
    payment = Payment.objects.create(request=req, gateway=slug, amount=amount, currency=code,
                                     reference=_new_reference(req), created_by=customer)
    result = gateway.create_charge(payment, customer)
    if result.checkout_url:
        payment.checkout_url = result.checkout_url
        payment.save(update_fields=["checkout_url"])
    record("payment.started", payment, f"Payment {payment.reference} started via {slug}",
           data={"amount": str(amount), "currency": code, "ok": result.ok})
    return payment, result


@transaction.atomic
def customer_claims_paid(req, customer, reference):
    """Customer typed the bank or mobile money reference after paying."""
    reference = (reference or "").strip().upper()[:64]
    if len(reference) < 4:
        raise ExchangeError("Enter the full payment reference from your bank or receipt.")
    payment, _ = start_payment(req, customer)
    if Payment.objects.filter(customer_reference=reference).exclude(pk=payment.pk).exists():
        raise ExchangeError("This reference was already submitted for another payment.")
    Payment.objects.filter(pk=payment.pk).update(customer_reference=reference)
    record("payment.claimed", payment, f"Customer reports paying {req.reference}, reference {reference}",
           data={"reference": reference})
    notify_staff("customer_paid", {"customer": customer, "ref": req.reference, "txid": reference})
    return payment


def handle_webhook(slug, headers, body, ip):
    """verify -> parse -> record -> settle. Returns (http_status, message)."""
    gateway = get_gateway(slug)
    if gateway is None or slug == "manual":
        return 404, "unknown gateway"
    if not gateway.is_configured():
        return 503, "gateway disabled"
    verified = gateway.verify_webhook(headers, body)
    try:
        data = gateway.parse_webhook(body)
    except (ValueError, TypeError):
        return 400, "bad payload"
    if not data.event_reference:
        return 400, "missing event id"
    try:
        with transaction.atomic():
            event = GatewayEvent.objects.create(gateway=slug, event_reference=data.event_reference,
                                                verified=verified, payload=_safe_json(body), ip_address=ip)
    except IntegrityError:
        return 200, "duplicate ignored"
    if not verified:
        GatewayEvent.objects.filter(pk=event.pk).update(note="signature invalid, stored for forensics")
        return 403, "bad signature"
    if data.status not in ("success", "successful", "paid", "completed"):
        GatewayEvent.objects.filter(pk=event.pk).update(note=f"status {data.status}")
        return 200, "noted"
    payment = Payment.objects.filter(reference=data.order_reference, gateway=slug).first()
    if payment is None:
        GatewayEvent.objects.filter(pk=event.pk).update(note="unknown order reference")
        return 200, "unknown order"
    GatewayEvent.objects.filter(pk=event.pk).update(payment=payment)
    if data.currency and data.currency != payment.currency:
        GatewayEvent.objects.filter(pk=event.pk).update(note="currency mismatch, not settled")
        return 200, "currency mismatch"
    try:
        confirm_funds(payment.request, system_user(), data.txid or data.event_reference,
                      payment=payment, amount=data.amount or None)
    except ExchangeError as exc:
        GatewayEvent.objects.filter(pk=event.pk).update(note=str(exc)[:255])
        return 200, "not settled"
    GatewayEvent.objects.filter(pk=event.pk).update(note="settled")
    return 200, "settled"


def _safe_json(body):
    import json
    try:
        return json.loads(body)
    except ValueError:
        return {"raw": body[:2000].decode("utf-8", "replace")}
