from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

from desderia.guards import hit
from desderia.middleware import client_ip, security_log

from .services import handle_webhook

MAX_BODY = 8 * 1024


@csrf_exempt
@require_POST
def webhook(request, slug):
    ip = client_ip(request)
    if hit("webhook", ip, 60, 60):
        return JsonResponse({"detail": "rate limited"}, status=429)
    if int(request.META.get("CONTENT_LENGTH") or 0) > MAX_BODY or len(request.body) > MAX_BODY:
        return JsonResponse({"detail": "too large"}, status=413)
    status, message = handle_webhook(slug, request.headers, request.body, ip)
    if status in (403, 400):
        security_log.warning("webhook_rejected gateway=%s ip=%s reason=%s", slug, ip, message)
    return JsonResponse({"detail": message}, status=status)
