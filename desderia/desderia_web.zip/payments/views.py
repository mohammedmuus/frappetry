from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

from desderia.guards import hit
from desderia.middleware import client_ip, security_log

from .services import handle_cashpay_callback

MAX_BODY = 8 * 1024


@csrf_exempt
@require_POST
def cashpay_callback(request, secret):
    """CashPay result notification. Must answer within 5 seconds."""
    ip = client_ip(request)
    if hit("cashpay_callback", ip, 120, 60):
        return JsonResponse({"status": "rejected", "message": "rate limited"}, status=429)
    if int(request.META.get("CONTENT_LENGTH") or 0) > MAX_BODY or len(request.body) > MAX_BODY:
        return JsonResponse({"status": "rejected", "message": "too large"}, status=413)
    status, message = handle_cashpay_callback(secret, request.body, ip)
    if status in (400, 403, 404):
        security_log.warning("cashpay_callback_rejected ip=%s reason=%s", ip, message)
    if status == 200:
        return JsonResponse({"status": "received", "message": message})
    return JsonResponse({"status": "rejected", "message": message}, status=status)
