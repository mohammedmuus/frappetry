from django.urls import path

from . import views

app_name = "payments"

urlpatterns = [
    path("webhook/<slug:slug>/", views.webhook, name="webhook"),
]
