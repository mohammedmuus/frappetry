from django.urls import path

from . import views

app_name = "payments"

urlpatterns = [
    path("cashpay/callback/<str:secret>/", views.cashpay_callback, name="cashpay_callback"),
]
