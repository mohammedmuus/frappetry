"""
Payment gateway backbone. Checkout code talks to this interface only, so a
real provider can be switched on without touching exchange logic.

CashPay: the adapter below follows the common pattern (JSON charge request
with a bearer key, HMAC-SHA256 signed webhooks). Confirm field names
against CashPay's merchant documentation before enabling it in production.
Until CASHPAY_* settings hold real values the gateway reports itself as
not configured and its webhook answers 503.
"""

import hashlib
import hmac
import json
import logging
import urllib.request
from dataclasses import dataclass

from django.conf import settings

log = logging.getLogger("desderia")

PLACEHOLDERS = {"", "change-me", "changeme", "placeholder", "set-me"}


@dataclass
class ChargeResult:
    ok: bool
    checkout_url: str = ""
    provider_reference: str = ""
    message: str = ""


@dataclass
class GatewayEventData:
    event_reference: str
    order_reference: str
    status: str
    amount: str
    currency: str
    txid: str


class PaymentGateway:
    slug = ""
    label = ""
    supports_push = False

    def is_configured(self):
        return False

    def create_charge(self, payment, customer):
        raise NotImplementedError

    def verify_webhook(self, headers, body):
        return False

    def parse_webhook(self, body):
        raise NotImplementedError


class ManualGateway(PaymentGateway):
    """Bank transfer or cash at the branch. A teller confirms the receipt."""

    slug = "manual"
    label = "Bank transfer or cash"

    def is_configured(self):
        return True

    def create_charge(self, payment, customer):
        return ChargeResult(ok=True, message="Pay using the bank details shown, then submit your reference.")


class CashPayGateway(PaymentGateway):
    slug = "cashpay"
    label = "CashPay"
    supports_push = True

    def is_configured(self):
        return all(str(v).strip().lower() not in PLACEHOLDERS for v in (
            settings.CASHPAY_API_URL, settings.CASHPAY_MERCHANT_ID,
            settings.CASHPAY_API_KEY, settings.CASHPAY_WEBHOOK_SECRET))

    def create_charge(self, payment, customer):
        if not self.is_configured():
            return ChargeResult(ok=False, message="CashPay is not available right now.")
        payload = {
            "merchant_id": settings.CASHPAY_MERCHANT_ID,
            "order_reference": payment.reference,
            "amount": str(payment.amount),
            "currency": payment.currency,
            "customer_phone": customer.phone,
            "customer_email": customer.email,
            "description": f"Desderia {payment.request.reference}",
            "callback_url": f"{settings.SITE_URL}/payments/webhook/cashpay/",
            "return_url": f"{settings.SITE_URL}/exchange/r/{payment.request.reference}/",
        }
        req = urllib.request.Request(
            settings.CASHPAY_API_URL.rstrip("/") + "/charges",
            data=json.dumps(payload).encode(), method="POST",
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {settings.CASHPAY_API_KEY}",
                     "Idempotency-Key": payment.reference},
        )
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read() or b"{}")
        except Exception:
            log.exception("CashPay charge failed for %s", payment.reference)
            return ChargeResult(ok=False, message="CashPay did not respond. Please try again.")
        return ChargeResult(ok=True, checkout_url=str(data.get("checkout_url", ""))[:200],
                            provider_reference=str(data.get("id", ""))[:64],
                            message="Approve the payment prompt on your phone.")

    def verify_webhook(self, headers, body):
        signature = headers.get("X-Cashpay-Signature", "")
        expected = hmac.new(settings.CASHPAY_WEBHOOK_SECRET.encode(), body, hashlib.sha256).hexdigest()
        return bool(signature) and hmac.compare_digest(signature, expected)

    def parse_webhook(self, body):
        data = json.loads(body)
        return GatewayEventData(
            event_reference=str(data.get("event_id") or data.get("id") or "")[:80],
            order_reference=str(data.get("order_reference", ""))[:40],
            status=str(data.get("status", "")).lower(),
            amount=str(data.get("amount", "")),
            currency=str(data.get("currency", "")).upper(),
            txid=str(data.get("transaction_id", ""))[:64],
        )


GATEWAYS = {g.slug: g for g in (ManualGateway(), CashPayGateway())}


def get_gateway(slug):
    return GATEWAYS.get(slug)
