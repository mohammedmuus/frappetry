"""
Payment gateway backbone. Checkout code talks to this interface only, so
another provider can be added without touching exchange logic.

CashPay (Merchant API v1, https://cashpay.co.tz/api/reference):

    1. POST /get-token   {"username", "password"}                -> {"token"}   (JWT, 5 minutes)
    2. POST /generate    {"header": {"token"}, "body": {"request": {"transactionNumber"}}}
                                                                 -> {"code": "1", "referenceNumber": "50..."}
    3. POST /ussdpush    {"header": {"token"}, "body": {"request": {"transactionNumber", "phone",
                                                                     "amount", "type": "ussdpush"}}}
                                                                 -> {"code": "1", "status": "success"}
    4. CashPay POSTs the result to our callback URL:
       {"referenceNumber", "receiptNumber", "status": "SUCCESS"|"FAILED", "provider",
        "amount", "phone", "transactionNumber"}

The callback carries no signature, so payments/services.py accepts it only
when it arrives on the secret callback path, from an allowed IP (if a list
is configured), and every field matches what we sent: transactionNumber,
referenceNumber, amount and phone. A receiptNumber can settle one payment only.
"""

import json
import logging
import re
import urllib.error
import urllib.request
from dataclasses import dataclass
from decimal import ROUND_CEILING, Decimal

from django.conf import settings
from django.core.cache import cache

log = logging.getLogger("desderia")

PLACEHOLDERS = {"", "change-me", "changeme", "placeholder", "set-me"}

class GatewayError(Exception):
    """Message is safe to show to the customer."""


@dataclass
class ChargeResult:
    ok: bool
    message: str = ""
    provider_reference: str = ""


@dataclass
class CallbackData:
    transaction_number: str
    reference_number: str
    receipt_number: str
    status: str
    provider: str
    amount: str
    phone: str

    @property
    def event_reference(self):
        # CashPay sends no event id. A retry repeats these three exactly,
        # so the unique (gateway, event_reference) row makes retries no-ops.
        return f"{self.transaction_number}:{self.status}:{self.receipt_number}"[:80]


class PaymentGateway:
    slug = ""
    label = ""
    supports_push = False

    def is_configured(self):
        return False

    def create_charge(self, payment, phone):
        raise NotImplementedError


class ManualGateway(PaymentGateway):
    """Bank transfer or cash at the branch. A teller confirms the receipt."""

    slug = "manual"
    label = "Bank transfer or cash"

    def is_configured(self):
        return True

    def create_charge(self, payment, phone=None):
        return ChargeResult(ok=True, message="Pay using the details shown, then submit your reference.")


def cashpay_phone(raw):
    """255XXXXXXXXX for any Tanzanian mobile number, or GatewayError.

    Every 06x and 07x range is accepted. Only prefixes marked as not
    supported in Management, Mobile prefixes (Halotel and TTCL today) are
    refused here; a brand new range that is not in the table yet goes
    through and CashPay itself decides.
    """
    from accounts.models import MobilePrefix

    digits = re.sub(r"\D", "", str(raw or ""))
    if digits.startswith("0") and len(digits) == 10:
        digits = "255" + digits[1:]
    if not re.fullmatch(r"255[67]\d{8}", digits):
        raise GatewayError("Enter a Tanzanian mobile number, for example 0754 123 456.")
    network = MobilePrefix.lookup(digits)
    if network is not None and not network.cashpay_supported:
        raise GatewayError(f"CashPay cannot send a prompt to {network.wallet or network.operator} numbers. "
                           "Use an M-Pesa, Mixx by Yas or Airtel Money number.")
    return digits


def network_label(digits):
    from accounts.models import MobilePrefix

    network = MobilePrefix.lookup(digits)
    return (network.wallet or network.operator) if network else "mobile money"


def cashpay_amount(amount):
    """CashPay takes whole shillings as a string. Round up so we are never short."""
    return Decimal(amount).quantize(Decimal("1"), rounding=ROUND_CEILING)


def transaction_number(payment_reference):
    """CashPay requires an alphanumeric transactionNumber, unique per merchant."""
    return re.sub(r"[^A-Za-z0-9]", "", payment_reference)[:40]


class CashPayGateway(PaymentGateway):
    slug = "cashpay"
    label = "CashPay"
    supports_push = True
    TOKEN_KEY = "cashpay:token"

    def is_configured(self):
        return all(str(v).strip().lower() not in PLACEHOLDERS for v in (
            settings.CASHPAY_USERNAME, settings.CASHPAY_PASSWORD, settings.CASHPAY_CALLBACK_SECRET))

    # ── transport ──────────────────────────────────────────────
    def _post(self, path, payload):
        """POST JSON, return (http_status, parsed_body). Network errors raise GatewayError."""
        req = urllib.request.Request(
            f"{settings.CASHPAY_BASE_URL}/{path}", data=json.dumps(payload).encode(), method="POST",
            headers={"Content-Type": "application/json", "Accept": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=settings.CASHPAY_TIMEOUT) as resp:
                status, raw = resp.status, resp.read()
        except urllib.error.HTTPError as exc:
            status, raw = exc.code, exc.read()
        except (urllib.error.URLError, TimeoutError, OSError):
            log.exception("CashPay unreachable on %s", path)
            raise GatewayError("CashPay is not responding right now. Please try again in a moment.")
        try:
            body = json.loads(raw or b"{}")
        except ValueError:
            body = {}
        return status, body

    def _token(self, force=False):
        token = None if force else cache.get(self.TOKEN_KEY)
        if token:
            return token
        status, body = self._post("get-token", {"username": settings.CASHPAY_USERNAME,
                                                "password": settings.CASHPAY_PASSWORD})
        token = body.get("token") if isinstance(body, dict) else None
        if status != 200 or not token:
            log.error("CashPay get-token failed: %s %s", status, body.get("message", "") if isinstance(body, dict) else "")
            raise GatewayError("CashPay is not available right now.")
        cache.set(self.TOKEN_KEY, token, settings.CASHPAY_TOKEN_TTL)
        return token

    def _call(self, path, request_body):
        """Authenticated call. On an expired or rejected token, fetch a new one once."""
        for attempt in (0, 1):
            token = self._token(force=attempt == 1)
            status, body = self._post(path, {"header": {"token": token}, "body": {"request": request_body}})
            if status == 401 and attempt == 0:
                cache.delete(self.TOKEN_KEY)
                continue
            return status, body
        return status, body

    # ── operations ────────────────────────────────────────────
    def generate_reference(self, txn):
        status, body = self._call("generate", {"transactionNumber": txn})
        if str(body.get("code")) == "1" and body.get("referenceNumber"):
            return str(body["referenceNumber"])
        log.error("CashPay generate failed for %s: %s %s", txn, status, body)
        raise GatewayError("Could not create the CashPay payment. Please try again.")

    def ussd_push(self, txn, phone, amount):
        status, body = self._call("ussdpush", {"transactionNumber": txn, "phone": phone,
                                               "amount": str(int(amount)), "type": "ussdpush"})
        if str(body.get("code")) == "1" and str(body.get("status", "")).lower() == "success":
            return True
        reason = str(body.get("description") or "Payment prompt failed")
        log.error("CashPay ussdpush failed for %s: %s %s", txn, status, reason)
        if "Operator" in reason or "Phone" in reason:
            raise GatewayError("CashPay does not support this number's network yet. Use an M-Pesa, Mixx by Yas "
                               "or Airtel Money number.")
        raise GatewayError("CashPay could not send the payment prompt. Please try again.")

    def create_charge(self, payment, phone):
        if not self.is_configured():
            raise GatewayError("CashPay is not available right now. Choose bank transfer or cash.")
        txn = transaction_number(payment.reference)
        reference = self.generate_reference(txn)
        self.ussd_push(txn, phone, payment.amount)
        return ChargeResult(ok=True, provider_reference=reference,
                            message=f"A {network_label(phone)} prompt was sent to {phone}. Enter your PIN to approve.")

    @staticmethod
    def parse_callback(body):
        data = json.loads(body)
        if not isinstance(data, dict):
            raise ValueError("not an object")
        return CallbackData(
            transaction_number=str(data.get("transactionNumber", ""))[:40],
            reference_number=str(data.get("referenceNumber", "")).split(".")[0][:40],
            receipt_number=str(data.get("receiptNumber", ""))[:64],
            status=str(data.get("status", "")).upper()[:12],
            provider=str(data.get("provider", ""))[:20],
            amount=str(data.get("amount", "")),
            phone=re.sub(r"\D", "", str(data.get("phone", "")))[:15],
        )


GATEWAYS = {g.slug: g for g in (ManualGateway(), CashPayGateway())}


def get_gateway(slug):
    return GATEWAYS.get(slug)
