import uuid

from django.conf import settings
from django.db import models
from django.db.models import Q


class Payment(models.Model):
    """Money moving from the customer to the bureau for one exchange request.

    Double payment guards, all enforced by the database:
    - at most one PAID payment per request
    - at most one PENDING payment per request (a retry reuses it)
    - a provider or bank reference can settle only one payment, ever
    """

    PENDING = "pending"
    PAID = "paid"
    FAILED = "failed"
    CANCELLED = "cancelled"
    STATUS_CHOICES = [(PENDING, "Pending"), (PAID, "Paid"), (FAILED, "Failed"), (CANCELLED, "Cancelled")]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    request = models.ForeignKey("exchange.ExchangeRequest", on_delete=models.PROTECT, related_name="payments")
    gateway = models.CharField(max_length=16)
    amount = models.DecimalField(max_digits=18, decimal_places=2)
    currency = models.CharField(max_length=3)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default=PENDING)
    # Our own reference sent to the provider (order id).
    reference = models.CharField(max_length=40, unique=True)
    # The provider, bank or teller receipt reference. Unique when set.
    settled_txid = models.CharField(max_length=64, blank=True)
    customer_reference = models.CharField(max_length=64, blank=True,
                                          help_text="Reference the customer typed after paying")
    checkout_url = models.URLField(blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    confirmed_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT,
                                     related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)
    paid_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]
        constraints = [
            models.UniqueConstraint(fields=["request"], condition=Q(status="paid"), name="payment_one_paid_per_request"),
            models.UniqueConstraint(fields=["request"], condition=Q(status="pending"),
                                    name="payment_one_pending_per_request"),
            models.UniqueConstraint(fields=["settled_txid"], condition=~Q(settled_txid=""),
                                    name="payment_txid_unique"),
            models.CheckConstraint(condition=Q(amount__gt=0), name="payment_amount_positive"),
            models.CheckConstraint(condition=~Q(status="paid") | (~Q(settled_txid="") & Q(paid_at__isnull=False)),
                                   name="payment_paid_has_txid"),
        ]

    def __str__(self):
        return f"{self.reference} {self.amount} {self.currency} {self.status}"


class GatewayEvent(models.Model):
    """Every webhook delivery, verified or not. The unique pair IS idempotency:
    providers retry, and a retry must never settle twice."""

    gateway = models.CharField(max_length=16)
    event_reference = models.CharField(max_length=80)
    verified = models.BooleanField(default=False)
    payload = models.JSONField(default=dict)
    note = models.CharField(max_length=255, blank=True)
    payment = models.ForeignKey(Payment, null=True, blank=True, on_delete=models.PROTECT, related_name="events")
    received_at = models.DateTimeField(auto_now_add=True)
    ip_address = models.CharField(max_length=45, blank=True)

    class Meta:
        ordering = ["-received_at"]
        constraints = [
            models.UniqueConstraint(fields=["gateway", "event_reference"], name="gateway_event_unique"),
        ]

    def __str__(self):
        return f"{self.gateway} {self.event_reference}"
