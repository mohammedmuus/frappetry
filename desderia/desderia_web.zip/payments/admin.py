from django.contrib import admin

from desderia.admin_mixins import ReadOnlyAdmin

from .models import GatewayEvent, Payment


@admin.register(Payment)
class PaymentAdmin(ReadOnlyAdmin, admin.ModelAdmin):
    list_display = ["reference", "request", "gateway", "amount", "currency", "status", "settled_txid",
                    "customer_reference", "confirmed_by", "paid_at"]
    list_filter = ["status", "gateway", "currency"]
    search_fields = ["reference", "settled_txid", "customer_reference", "request__reference"]
    date_hierarchy = "created_at"


@admin.register(GatewayEvent)
class GatewayEventAdmin(ReadOnlyAdmin, admin.ModelAdmin):
    list_display = ["gateway", "event_reference", "verified", "payment", "note", "ip_address", "received_at"]
    list_filter = ["gateway", "verified"]
    search_fields = ["event_reference", "note"]
