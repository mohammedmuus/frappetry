/* Desderia web behaviour. No inline handlers anywhere: everything hangs off
   data- attributes so the Content Security Policy never needs unsafe-inline.
   Source file. build_assets.py writes app.min.js, which the templates load. */
(function () {
  "use strict";

  var $ = function (sel, root) { return (root || document).querySelector(sel); };
  var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  function csrf() {
    var el = $("input[name=csrfmiddlewaretoken]");
    return el ? el.value : "";
  }

  function fmt(n, dp) {
    return Number(n).toLocaleString("en-US", { minimumFractionDigits: dp, maximumFractionDigits: dp });
  }

  // ── Drawer (mobile menu) ──────────────────────────────────
  document.addEventListener("click", function (ev) {
    var open = ev.target.closest("[data-drawer-open]");
    var close = ev.target.closest("[data-drawer-close]");
    var drawer = $("#drawer");
    if (!drawer) { return; }
    if (open) { drawer.classList.add("open"); drawer.setAttribute("aria-hidden", "false"); }
    if (close) { drawer.classList.remove("open"); drawer.setAttribute("aria-hidden", "true"); }
  });
  document.addEventListener("keydown", function (ev) {
    if (ev.key === "Escape") {
      var drawer = $("#drawer");
      if (drawer) { drawer.classList.remove("open"); }
    }
  });

  // ── Confirm and single submit (no double entries) ─────────
  document.addEventListener("submit", function (ev) {
    var form = ev.target;
    var msg = form.getAttribute("data-confirm");
    if (msg && !window.confirm(msg)) { ev.preventDefault(); return; }
    if (form.dataset.busy === "1") { ev.preventDefault(); return; }
    if (form.hasAttribute("data-chat-form")) { return; }
    form.dataset.busy = "1";
    $$("button[type=submit], button:not([type])", form).forEach(function (b) {
      b.classList.add("is-busy");
      b.setAttribute("aria-busy", "true");
    });
    // Release after a while in case the browser stays on the page (validation errors, downloads).
    setTimeout(function () {
      form.dataset.busy = "";
      $$(".is-busy", form).forEach(function (b) { b.classList.remove("is-busy"); b.removeAttribute("aria-busy"); });
    }, 8000);
  }, true);

  // ── Public converter (rates embedded as data attributes) ──
  $$("[data-converter]").forEach(function (box) {
    var cur = $("[data-cv-currency]", box);
    var amt = $("[data-cv-amount]", box);
    var out = $("[data-cv-out]", box);
    var rateEl = $("[data-cv-rate]", box);
    function run() {
      var opt = cur.options[cur.selectedIndex];
      var dirEl = $("[data-cv-direction]:checked", box);
      var dir = dirEl ? dirEl.value : "buy";
      var rate = parseFloat(dir === "buy" ? opt.dataset.sell : opt.dataset.buy);
      var a = parseFloat(amt.value || "0");
      if (!rate || !a || a < 0) { out.textContent = "TZS 0.00"; rateEl.textContent = rate ? fmt(rate, 2) : "-"; return; }
      out.textContent = "TZS " + fmt(a * rate, 2);
      rateEl.textContent = fmt(rate, 2);
    }
    box.addEventListener("input", run);
    box.addEventListener("change", run);
    run();
  });

  // ── Request form: live quote and dependent fields ─────────
  var reqForm = $("[data-request-form]");
  if (reqForm) {
    var funding = JSON.parse(reqForm.dataset.funding || "{}");
    var payout = JSON.parse(reqForm.dataset.payout || "{}");
    var quoteUrl = reqForm.dataset.quoteUrl;
    var fSel = $("[name=funding_method]", reqForm);
    var pSel = $("[name=payout_method]", reqForm);
    var benWrap = $("[data-beneficiary]", reqForm);
    var qOut = $("[data-quote-out]", reqForm);
    var qRate = $("[data-quote-rate]", reqForm);
    var qNote = $("[data-quote-note]", reqForm);
    var timer = null;

    var dir = function () { var d = $("[name=direction]:checked", reqForm); return d ? d.value : "buy"; };
    var limit = function (sel, allowed) {
      $$("option", sel).forEach(function (o) { o.hidden = allowed.indexOf(o.value) === -1; o.disabled = o.hidden; });
      if (sel.selectedOptions[0] && sel.selectedOptions[0].disabled) {
        var first = $$("option", sel).filter(function (o) { return !o.disabled; })[0];
        if (first) { sel.value = first.value; }
      }
    };
    var sync = function () {
      limit(fSel, funding[dir()] || []);
      limit(pSel, payout[dir()] || []);
      benWrap.hidden = pSel.value === "cash_pickup";
    };
    var quote = function () {
      clearTimeout(timer);
      timer = setTimeout(function () {
        var params = new URLSearchParams({
          currency: $("[name=currency]", reqForm).value,
          direction: dir(),
          amount: $("[name=amount]", reqForm).value || "0"
        });
        fetch(quoteUrl + "?" + params.toString(), { credentials: "same-origin", headers: { Accept: "application/json" } })
          .then(function (r) { return r.json(); })
          .then(function (d) {
            if (!d.ok) { qOut.textContent = "TZS 0.00"; qRate.textContent = "-"; qNote.textContent = d.error || ""; return; }
            qOut.textContent = "TZS " + d.local;
            qRate.textContent = d.rate;
            qNote.textContent = d.negotiable ? "This amount qualifies for rate negotiation after you submit."
              : "Negotiation opens from " + d.min_negotiable + " units.";
          })
          .catch(function () { qNote.textContent = "Quote unavailable. Check your connection."; });
      }, 250);
    };
    reqForm.addEventListener("change", function () { sync(); quote(); });
    reqForm.addEventListener("input", function (ev) { if (ev.target.name === "amount") { quote(); } });
    sync();
    quote();
  }

  // ── Beneficiary form: bank or mobile fields ───────────────
  var benForm = $("[data-beneficiary-form]");
  if (benForm) {
    var kind = $("[name=kind]", benForm);
    var toggle = function () {
      var bank = kind.value === "bank";
      $$("[data-bank-only]", benForm).forEach(function (el) { el.hidden = !bank; });
      $$("[data-mobile-only]", benForm).forEach(function (el) { el.hidden = bank; });
    };
    kind.addEventListener("change", toggle);
    toggle();
  }

  // ── Chat (polling, idempotent sends) ──────────────────────
  $$("[data-chat]").forEach(function (box) {
    var log = $(".chat-log", box);
    var form = $("[data-chat-form]", box);
    var input = $("[name=body]", form);
    var pollUrl = box.dataset.pollUrl;
    var sendUrl = box.dataset.sendUrl;
    var seen = {};
    var last = box.dataset.last || "";

    $$("[data-id]", log).forEach(function (el) { seen[el.dataset.id] = true; });

    function render(m) {
      if (seen[m.id]) { return; }
      seen[m.id] = true;
      var div = document.createElement("div");
      div.className = "msg " + (m.kind === "system" ? "sys" : (m.mine ? "me" : "them"));
      div.dataset.id = m.id;
      div.textContent = m.body;
      if (m.kind !== "system") {
        var meta = document.createElement("small");
        var t = new Date(m.at);
        meta.textContent = (m.mine ? "You" : m.sender) + ", " + t.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
        div.appendChild(meta);
      }
      log.appendChild(div);
      last = m.at;
    }
    function scroll() { log.scrollTop = log.scrollHeight; }
    function poll() {
      var url = pollUrl + (last ? "?after=" + encodeURIComponent(last) : "");
      fetch(url, { credentials: "same-origin", headers: { Accept: "application/json" } })
        .then(function (r) { return r.ok ? r.json() : { messages: [] }; })
        .then(function (d) {
          var before = log.children.length;
          (d.messages || []).forEach(render);
          if (log.children.length !== before) { scroll(); }
        })
        .catch(function () {});
    }
    form.addEventListener("submit", function (ev) {
      ev.preventDefault();
      var body = input.value.trim();
      if (!body || form.dataset.sending === "1") { return; }
      form.dataset.sending = "1";
      var data = new FormData();
      data.append("body", body);
      data.append("client_id", window.crypto && crypto.randomUUID ? crypto.randomUUID() : String(Date.now()));
      fetch(sendUrl, { method: "POST", credentials: "same-origin", body: data,
                       headers: { "X-CSRFToken": csrf(), Accept: "application/json" } })
        .then(function (r) { return r.json(); })
        .then(function (d) {
          if (d.ok) { render(d.message); input.value = ""; scroll(); }
          else { window.alert(d.error || d.detail || "Message not sent."); }
        })
        .catch(function () { window.alert("Message not sent. Check your connection."); })
        .then(function () { form.dataset.sending = ""; input.focus(); });
    });
    input.addEventListener("keydown", function (ev) {
      if (ev.key === "Enter" && !ev.shiftKey) { ev.preventDefault(); form.requestSubmit(); }
    });
    scroll();
    var period = function () { return document.hidden ? 15000 : 4000; };
    (function loop() { setTimeout(function () { poll(); loop(); }, period()); })();
  });

  // ── Copy buttons ──────────────────────────────────────────
  document.addEventListener("click", function (ev) {
    var btn = ev.target.closest("[data-copy]");
    if (!btn || !navigator.clipboard) { return; }
    navigator.clipboard.writeText(btn.dataset.copy).then(function () {
      var old = btn.textContent;
      btn.textContent = "Copied";
      setTimeout(function () { btn.textContent = old; }, 1400);
    });
  });
})();
