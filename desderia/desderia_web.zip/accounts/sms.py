"""SMS delivery. The console backend logs codes for development; a provider
backend posts to any HTTP SMS gateway configured in the environment."""

import json
import logging
import urllib.request

from django.conf import settings
from django.utils.module_loading import import_string

log = logging.getLogger("desderia")


class ConsoleSmsBackend:
    def send(self, phone, text):
        log.info("SMS to %s: %s", phone, text)
        return True


class HttpSmsBackend:
    """Generic JSON gateway: POST {to, from, text} with a bearer key."""

    def send(self, phone, text):
        if not settings.SMS_API_URL or not settings.SMS_API_KEY:
            log.error("SMS backend not configured")
            return False
        body = json.dumps({"to": phone, "from": settings.SMS_SENDER_ID, "text": text}).encode()
        req = urllib.request.Request(
            settings.SMS_API_URL, data=body, method="POST",
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {settings.SMS_API_KEY}"},
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return 200 <= resp.status < 300
        except Exception:
            log.exception("SMS delivery failed for %s", phone)
            return False


def send_sms(phone, text):
    return import_string(settings.SMS_BACKEND)().send(phone, text)
