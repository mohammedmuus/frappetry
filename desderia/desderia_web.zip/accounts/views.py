import time

from django.contrib import messages
from django.contrib.auth import authenticate, get_user_model, login as auth_login, logout as auth_logout
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordChangeForm
from django.db import IntegrityError, transaction
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_POST

from audit.services import record
from desderia.guards import rate_limit
from notifications.services import notify_staff

from . import otp
from .forms import CodeForm, KycForm, LoginForm, ProfileForm, RegisterForm, style
from .models import ApiToken, KycProfile, OneTimeCode

User = get_user_model()

PENDING_KEY = "pending_2fa"
PENDING_TTL = 600


def _safe_next(request, fallback):
    nxt = request.POST.get("next") or request.GET.get("next") or ""
    if nxt and url_has_allowed_host_and_scheme(nxt, allowed_hosts={request.get_host()},
                                               require_https=request.is_secure()):
        return nxt
    return fallback


# ─────────────────────────────────────────────────────────────
# LOGIN (password, then a one time code: two step for everyone)
# ─────────────────────────────────────────────────────────────

@never_cache
def login_view(request):
    if request.user.is_authenticated:
        return redirect(request.user.home_url)
    form = LoginForm(request, data=request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.get_user()
        if not user.email_verified_at:
            # Not yet verified: sign in so they can finish verification. Trading
            # stays blocked by the middleware until both channels are verified.
            auth_login(request, user)
            return redirect("accounts:verify")
        channel = "sms" if request.POST.get("channel") == "sms" and user.phone_verified_at else "email"
        try:
            otp.issue(user, OneTimeCode.PURPOSE_LOGIN, channel=channel, request=request)
        except otp.OtpError:
            pass  # a code is already on its way; reuse it
        request.session.cycle_key()
        request.session[PENDING_KEY] = {"uid": str(user.pk), "at": int(time.time()), "channel": channel,
                                        "next": _safe_next(request, "")}
        return redirect("accounts:login_verify")
    return render(request, "login.html", {"form": form, "next": request.GET.get("next", "")})


@never_cache
@rate_limit("login_verify", limit=10, window=300)
def login_verify(request):
    pending = request.session.get(PENDING_KEY)
    if not pending or time.time() - pending.get("at", 0) > PENDING_TTL:
        request.session.pop(PENDING_KEY, None)
        messages.info(request, "Please sign in again.")
        return redirect("accounts:login")
    user = get_object_or_404(User, pk=pending["uid"], is_active=True)
    form = CodeForm(request.POST or None)
    if request.method == "POST":
        if request.POST.get("resend"):
            try:
                otp.issue(user, OneTimeCode.PURPOSE_LOGIN, channel=pending.get("channel", "email"), request=request)
                messages.success(request, "A new code was sent.")
            except otp.OtpError as exc:
                messages.error(request, str(exc))
            return redirect("accounts:login_verify")
        if form.is_valid():
            try:
                otp.verify(user, OneTimeCode.PURPOSE_LOGIN, form.cleaned_data["code"], request=request)
            except otp.OtpError as exc:
                form.add_error("code", str(exc))
            else:
                nxt = pending.get("next") or user.home_url
                request.session.pop(PENDING_KEY, None)
                auth_login(request, user, backend="accounts.backends.EmailBackend")
                request.session["last_seen"] = int(time.time())
                return redirect(nxt)
    masked = user.email if pending.get("channel") == "email" else f"{user.phone[:6]}*****{user.phone[-2:]}"
    return render(request, "login_verify.html", {"form": form, "sent_to": masked})


@require_POST
def logout_view(request):
    auth_logout(request)
    messages.success(request, "You have been signed out.")
    return redirect("accounts:login")


# ─────────────────────────────────────────────────────────────
# REGISTRATION AND VERIFICATION
# ─────────────────────────────────────────────────────────────

@never_cache
@rate_limit("register", limit=5, window=600)
def register(request):
    if request.user.is_authenticated:
        return redirect(request.user.home_url)
    form = RegisterForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        try:
            with transaction.atomic():
                user = form.save()
                record("account.registered", user, f"New customer {user.email}", actor=user,
                       data={"phone": user.phone})
        except IntegrityError:
            # Two parallel submissions: the database unique constraints win.
            messages.error(request, "This email or phone number is already registered.")
            return redirect("accounts:register")
        auth_login(request, user, backend="accounts.backends.EmailBackend")
        request.session["last_seen"] = int(time.time())
        for purpose, channel in ((OneTimeCode.PURPOSE_EMAIL, "email"), (OneTimeCode.PURPOSE_PHONE, "sms")):
            try:
                otp.issue(user, purpose, channel=channel, request=request)
            except otp.OtpError:
                pass
        messages.success(request, "Welcome to Desderia. We sent codes to your email and phone.")
        return redirect("accounts:verify")
    return render(request, "register.html", {"form": form})


@never_cache
@login_required
@rate_limit("verify", limit=15, window=300)
def verify(request):
    user = request.user
    if user.is_fully_verified:
        return redirect(user.home_url)
    email_form = CodeForm(request.POST if request.POST.get("which") == "email" else None, prefix="email")
    phone_form = CodeForm(request.POST if request.POST.get("which") == "phone" else None, prefix="phone")
    if request.method == "POST":
        which = request.POST.get("which")
        purpose = OneTimeCode.PURPOSE_EMAIL if which == "email" else OneTimeCode.PURPOSE_PHONE
        form = email_form if which == "email" else phone_form
        if request.POST.get("resend"):
            try:
                otp.issue(user, purpose, channel="email" if which == "email" else "sms", request=request)
                messages.success(request, "A new code was sent.")
            except otp.OtpError as exc:
                messages.error(request, str(exc))
            return redirect("accounts:verify")
        if form.is_valid():
            try:
                otp.verify(user, purpose, form.cleaned_data["code"], request=request)
            except otp.OtpError as exc:
                form.add_error("code", str(exc))
            else:
                field = "email_verified_at" if which == "email" else "phone_verified_at"
                User.objects.filter(pk=user.pk, **{f"{field}__isnull": True}).update(**{field: timezone.now()})
                record(f"account.{which}_verified", user, f"{which.title()} verified for {user.email}")
                messages.success(request, f"Your {which} is verified.")
                return redirect("accounts:verify")
    return render(request, "verify.html", {"email_form": email_form, "phone_form": phone_form})


# ─────────────────────────────────────────────────────────────
# ACCOUNT AREA
# ─────────────────────────────────────────────────────────────

@login_required
@rate_limit("profile", limit=10, window=300)
def profile(request):
    user = request.user
    old_phone = user.phone
    form = ProfileForm(request.POST or None, instance=user)
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            user = form.save(commit=False)
            phone_changed = user.phone != old_phone
            if phone_changed:
                user.phone_verified_at = None
            user.save()
            record("account.profile_updated", user, "Profile updated",
                   data={"phone_changed": phone_changed, "old_phone": old_phone if phone_changed else ""})
        if phone_changed:
            try:
                otp.issue(user, OneTimeCode.PURPOSE_PHONE, channel="sms", request=request)
            except otp.OtpError:
                pass
            messages.info(request, "Please verify your new phone number.")
            return redirect("accounts:verify")
        messages.success(request, "Profile saved.")
        return redirect("accounts:profile")
    return render(request, "profile.html", {"form": form, "kyc": getattr(user, "kyc", None)})


@login_required
@rate_limit("password_change", limit=5, window=600)
def security(request):
    form = PasswordChangeForm(request.user, request.POST or None)
    style(form)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        update_session_auth_hash(request, user)
        # A new password ends every mobile session.
        ApiToken.objects.filter(user=user, revoked_at__isnull=True).update(revoked_at=timezone.now())
        record("account.password_changed", user, "Password changed, all devices signed out")
        messages.success(request, "Password changed. Other devices were signed out.")
        return redirect("accounts:security")
    tokens = request.user.api_tokens.filter(revoked_at__isnull=True, expires_at__gt=timezone.now())
    return render(request, "security.html", {"form": form, "tokens": tokens})


@login_required
@require_POST
def revoke_device(request, token_id):
    token = get_object_or_404(ApiToken, pk=token_id, user=request.user)
    ApiToken.objects.filter(pk=token.pk, revoked_at__isnull=True).update(revoked_at=timezone.now())
    record("account.device_revoked", token, f"Device signed out: {token.device_name or 'device'}")
    messages.success(request, "Device signed out.")
    return redirect("accounts:security")


@login_required
@rate_limit("kyc", limit=5, window=600)
def kyc(request):
    instance = KycProfile.objects.filter(user=request.user).first()
    if instance and instance.status == KycProfile.STATUS_APPROVED:
        return render(request, "kyc.html", {"kyc": instance, "locked": True})
    form = KycForm(request.POST or None, request.FILES or None, instance=instance)
    if request.method == "POST" and form.is_valid():
        try:
            with transaction.atomic():
                kyc_obj = form.save(commit=False)
                kyc_obj.user = request.user
                kyc_obj.status = KycProfile.STATUS_PENDING
                kyc_obj.reviewed_by = None
                kyc_obj.reviewed_at = None
                kyc_obj.save()
                record("kyc.submitted", kyc_obj, f"KYC submitted by {request.user.email}",
                       data={"id_type": kyc_obj.id_type})
        except IntegrityError:
            messages.error(request, "This ID document is already linked to another account.")
            return redirect("accounts:kyc")
        notify_staff("kyc_submitted", {"customer": request.user, "kyc": kyc_obj})
        messages.success(request, "Thank you. Our team will review your documents shortly.")
        return redirect("accounts:profile")
    return render(request, "kyc.html", {"form": form, "kyc": instance})


@login_required
def kyc_document(request, user_id):
    """Private file: only the owner and bureau staff may open it."""
    kyc_obj = get_object_or_404(KycProfile, user_id=user_id)
    if not (request.user.pk == kyc_obj.user_id or request.user.is_bureau_staff
            or request.user.role == User.ROLE_AUDITOR):
        raise Http404
    if not kyc_obj.id_document:
        raise Http404
    if request.user.pk != kyc_obj.user_id:
        record("kyc.document_viewed", kyc_obj, f"KYC document of {kyc_obj.user.email} opened")
    response = FileResponse(kyc_obj.id_document.open("rb"), content_type="image/jpeg")
    response["Cache-Control"] = "no-store, private"
    response["Content-Disposition"] = "inline; filename=document.jpg"
    return response
