import re

from django.core import mail
from django.core.cache import cache
from django.test import TestCase, override_settings
from django.utils import timezone

from .models import User, normalise_phone


def make_user(email, role="customer", phone=None, verified=True, password="Strong-pass-2026"):
    now = timezone.now() if verified else None
    return User.objects.create_user(
        email=email, phone=phone or f"+2557{abs(hash(email)) % 10**8:08d}", password=password,
        full_name=email.split("@")[0].title() + " Test", role=role,
        email_verified_at=now, phone_verified_at=now)


def last_code():
    for msg in reversed(mail.outbox):
        m = re.search(r"\b(\d{6})\b", msg.body)
        if m:
            return m.group(1)
    raise AssertionError("no code emailed")


@override_settings(ALLOWED_HOSTS=["testserver"])
class AccessMatrixTests(TestCase):
    def setUp(self):
        cache.clear()
        self.customer = make_user("cust@x.test")
        self.teller = make_user("teller@x.test", role="teller")
        self.auditor = make_user("aud@x.test", role="auditor")

    def test_anonymous_is_sent_to_login(self):
        for url in ("/exchange/", "/desk/", "/desk/r/DSD-XXXX/", "/audit/", "/account/", "/chat/00000000-0000-0000-0000-000000000000/messages/"):
            r = self.client.get(url)
            self.assertEqual(r.status_code, 302, url)
            self.assertTrue(r["Location"].startswith("/auth/login/?next="), url)

    def test_public_pages_stay_open(self):
        for url in ("/", "/rates/", "/contact/", "/auth/login/", "/api/v1/rates/"):
            self.assertEqual(self.client.get(url).status_code, 200, url)

    def test_customer_blocked_from_desk_and_audit(self):
        self.client.force_login(self.customer)
        for url in ("/desk/", "/desk/queue/", "/desk/rates/", "/audit/"):
            r = self.client.get(url)
            self.assertEqual(r["Location"], "/exchange/", url)

    def test_teller_cannot_publish_rates_or_read_audit(self):
        self.client.force_login(self.teller)
        self.assertEqual(self.client.get("/desk/").status_code, 200)
        self.assertEqual(self.client.get("/desk/rates/")["Location"], "/desk/")
        self.assertEqual(self.client.get("/audit/")["Location"], "/desk/")
        self.assertEqual(self.client.get("/exchange/")["Location"], "/desk/")

    def test_auditor_reads_audit_only(self):
        self.client.force_login(self.auditor)
        self.assertEqual(self.client.get("/audit/").status_code, 200)
        self.assertEqual(self.client.get("/desk/queue/")["Location"], "/audit/")

    def test_unverified_customer_must_verify(self):
        u = make_user("new@x.test", verified=False)
        self.client.force_login(u)
        self.assertEqual(self.client.get("/exchange/")["Location"], "/auth/verify/")

    def test_logout_really_logs_out(self):
        self.client.force_login(self.customer)
        self.assertEqual(self.client.get("/exchange/").status_code, 200)
        self.assertEqual(self.client.get("/auth/logout/").status_code, 405)
        self.client.post("/auth/logout/")
        self.assertEqual(self.client.get("/exchange/").status_code, 302)

    def test_security_headers(self):
        r = self.client.get("/")
        csp = r["Content-Security-Policy"]
        self.assertIn("nonce-", csp)
        self.assertNotIn("unsafe-inline", csp)
        self.assertIn("frame-ancestors 'none'", csp)
        self.assertEqual(r["X-Frame-Options"], "DENY")
        self.assertNotIn(" onclick=", r.content.decode())
        self.client.force_login(self.customer)
        self.assertEqual(self.client.get("/exchange/")["Cache-Control"], "no-store, private")


@override_settings(ALLOWED_HOSTS=["testserver"])
class LoginTests(TestCase):
    def setUp(self):
        cache.clear()
        self.user = make_user("login@x.test")

    def test_two_step_login(self):
        r = self.client.post("/auth/login/", {"username": "LOGIN@x.test", "password": "Strong-pass-2026"})
        self.assertEqual(r["Location"], "/auth/login/verify/")
        # Password alone is not a session.
        self.assertEqual(self.client.get("/exchange/").status_code, 302)
        r = self.client.post("/auth/login/verify/", {"code": "000000" if last_code() != "000000" else "111111"})
        self.assertEqual(r.status_code, 200)
        r = self.client.post("/auth/login/verify/", {"code": last_code()})
        self.assertEqual(r["Location"], "/exchange/")
        self.assertEqual(self.client.get("/exchange/").status_code, 200)

    def test_code_cannot_be_reused(self):
        self.client.post("/auth/login/", {"username": "login@x.test", "password": "Strong-pass-2026"})
        code = last_code()
        self.client.post("/auth/login/verify/", {"code": code})
        self.client.post("/auth/logout/")
        self.client.post("/auth/login/", {"username": "login@x.test", "password": "Strong-pass-2026"})
        r = self.client.post("/auth/login/verify/", {"code": code})
        self.assertEqual(r.status_code, 200)  # stale code refused, form shown again

    def test_web_lockout_after_five_failures(self):
        for _ in range(5):
            self.client.post("/auth/login/", {"username": "login@x.test", "password": "wrong"})
        r = self.client.post("/auth/login/", {"username": "login@x.test", "password": "Strong-pass-2026"})
        self.assertEqual(r.status_code, 429)
        self.assertEqual(self.client.get("/auth/login/").status_code, 200)

    def test_api_lockout(self):
        for _ in range(5):
            self.client.post("/api/v1/auth/login/", {"email": "login@x.test", "password": "bad"},
                             content_type="application/json")
        r = self.client.post("/api/v1/auth/login/", {"email": "login@x.test", "password": "Strong-pass-2026"},
                             content_type="application/json")
        self.assertEqual(r.status_code, 429)

    def test_api_two_step_and_token_revocation(self):
        r = self.client.post("/api/v1/auth/login/", {"email": "login@x.test", "password": "Strong-pass-2026"},
                             content_type="application/json")
        challenge = r.json()["challenge"]
        r = self.client.post("/api/v1/auth/login/verify/", {"challenge": challenge, "code": last_code()},
                             content_type="application/json")
        token = r.json()["token"]
        auth = {"HTTP_AUTHORIZATION": f"Bearer {token}"}
        self.assertEqual(self.client.get("/api/v1/me/", **auth).status_code, 200)
        self.client.post("/api/v1/auth/logout/", **auth)
        self.assertEqual(self.client.get("/api/v1/me/", **auth).status_code, 401)


@override_settings(ALLOWED_HOSTS=["testserver"])
class RegistrationTests(TestCase):
    def setUp(self):
        cache.clear()

    def test_phone_normalisation(self):
        self.assertEqual(normalise_phone("0755 123 456"), "+255755123456")
        self.assertEqual(normalise_phone("255755123456"), "+255755123456")
        self.assertEqual(normalise_phone("+255 755-123-456"), "+255755123456")

    def _form(self, **kw):
        from django.core import signing
        import time
        data = {"full_name": "Asha Juma", "email": "asha@x.test", "phone": "0755123456",
                "password1": "Long-and-unique-77", "password2": "Long-and-unique-77", "accept_terms": "on",
                "started": signing.dumps(int(time.time()) - 30, salt="form-start"), "website": ""}
        data.update(kw)
        return data

    def test_register_then_duplicate_phone_in_other_format(self):
        r = self.client.post("/auth/register/", self._form())
        self.assertEqual(r["Location"], "/auth/verify/")
        self.assertEqual(User.objects.get(email="asha@x.test").phone, "+255755123456")
        self.client.post("/auth/logout/")
        r = self.client.post("/auth/register/", self._form(email="other@x.test", phone="+255755123456"))
        self.assertContains(r, "already registered")

    def test_honeypot_blocks_bots(self):
        r = self.client.post("/auth/register/", self._form(website="http://spam"))
        self.assertEqual(r.status_code, 200)
        self.assertFalse(User.objects.filter(email="asha@x.test").exists())
