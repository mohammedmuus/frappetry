import io
import time

from django import forms
from django.conf import settings
from django.contrib.auth import password_validation
from django.contrib.auth.forms import AuthenticationForm
from django.core import signing
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import InMemoryUploadedFile
from django.utils import timezone
from PIL import Image, UnidentifiedImageError

from .models import KycProfile, User, normalise_phone

input_class = "field"


def style(form):
    for field in form.fields.values():
        widget = field.widget
        if isinstance(widget, (forms.CheckboxInput, forms.RadioSelect)):
            continue
        widget.attrs.setdefault("class", "select" if isinstance(widget, forms.Select) else input_class)


# ─────────────────────────────────────────────────────────────
# BOT TRAP (honeypot plus signed time trap)
# ─────────────────────────────────────────────────────────────

class BotTrapMixin(forms.Form):
    website = forms.CharField(required=False, widget=forms.TextInput(
        attrs={"tabindex": "-1", "autocomplete": "off", "class": "hp"}))
    started = forms.CharField(required=False, widget=forms.HiddenInput)

    MIN_SECONDS = 3

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.is_bound:
            self.initial["started"] = signing.dumps(int(time.time()), salt="form-start")

    def clean(self):
        data = super().clean()
        if data.get("website"):
            raise ValidationError("Your submission could not be accepted.")
        try:
            started = signing.loads(data.get("started", ""), salt="form-start", max_age=60 * 60 * 3)
        except signing.BadSignature:
            raise ValidationError("This form expired. Please reload the page and try again.")
        if time.time() - started < self.MIN_SECONDS:
            raise ValidationError("Your submission could not be accepted.")
        return data


# ─────────────────────────────────────────────────────────────
# LOGIN AND REGISTRATION
# ─────────────────────────────────────────────────────────────

class LoginForm(AuthenticationForm):
    username = forms.EmailField(label="Email", widget=forms.EmailInput(
        attrs={"autocomplete": "email", "autofocus": True}))
    password = forms.CharField(label="Password", strip=False, widget=forms.PasswordInput(
        attrs={"autocomplete": "current-password"}))

    error_messages = {
        "invalid_login": "Email or password is not correct.",
        "inactive": "This account is disabled.",
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        style(self)


class RegisterForm(BotTrapMixin, forms.ModelForm):
    password1 = forms.CharField(label="Password", strip=False,
                                widget=forms.PasswordInput(attrs={"autocomplete": "new-password"}),
                                help_text="At least 10 characters, not a common password.")
    password2 = forms.CharField(label="Confirm password", strip=False,
                                widget=forms.PasswordInput(attrs={"autocomplete": "new-password"}))
    accept_terms = forms.BooleanField(label="I accept the terms and privacy policy")

    class Meta:
        model = User
        fields = ["full_name", "email", "phone"]
        widgets = {
            "full_name": forms.TextInput(attrs={"autocomplete": "name"}),
            "email": forms.EmailInput(attrs={"autocomplete": "email"}),
            "phone": forms.TextInput(attrs={"autocomplete": "tel", "inputmode": "tel",
                                            "placeholder": "+255 7XX XXX XXX"}),
        }
        labels = {"full_name": "Full name", "phone": "Phone number"}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        style(self)

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        if User.objects.filter(email__iexact=email).exists():
            raise ValidationError("An account with this email already exists.")
        return email

    def clean_phone(self):
        phone = normalise_phone(self.cleaned_data["phone"])
        if User.objects.filter(phone=phone).exists():
            raise ValidationError("This phone number is already registered.")
        return phone

    def clean(self):
        data = super().clean()
        p1, p2 = data.get("password1"), data.get("password2")
        if p1 and p2 and p1 != p2:
            self.add_error("password2", "The two passwords do not match.")
        if p1:
            probe = User(email=data.get("email", ""), full_name=data.get("full_name", ""))
            try:
                password_validation.validate_password(p1, probe)
            except ValidationError as exc:
                self.add_error("password1", exc)
        return data

    def save(self, commit=True):
        user = super().save(commit=False)
        user.role = User.ROLE_CUSTOMER
        user.set_password(self.cleaned_data["password1"])
        if commit:
            user.save()
        return user


class CodeForm(forms.Form):
    code = forms.CharField(max_length=6, min_length=6, label="Six digit code", widget=forms.TextInput(
        attrs={"inputmode": "numeric", "autocomplete": "one-time-code", "pattern": "[0-9]{6}",
               "class": "field code"}))


# ─────────────────────────────────────────────────────────────
# PROFILE AND KYC
# ─────────────────────────────────────────────────────────────

class ProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ["full_name", "phone", "notify_email"]
        labels = {"full_name": "Full name", "phone": "Phone number",
                  "notify_email": "Email me on every request update"}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        style(self)

    def clean_phone(self):
        phone = normalise_phone(self.cleaned_data["phone"])
        if User.objects.filter(phone=phone).exclude(pk=self.instance.pk).exists():
            raise ValidationError("This phone number is already registered.")
        return phone


def reencode_image(upload):
    """Decode and re-encode as JPEG so no hidden payload survives the upload."""
    if upload.size > settings.KYC_MAX_UPLOAD_BYTES:
        raise ValidationError("The file is larger than 5 MB.")
    try:
        img = Image.open(upload)
        img.verify()
        upload.seek(0)
        img = Image.open(upload)
        if img.format not in ("JPEG", "PNG", "WEBP"):
            raise ValidationError("Upload a JPEG, PNG or WEBP photo of the document.")
        if img.width * img.height > 40_000_000:
            raise ValidationError("The image is too large.")
        img = img.convert("RGB")
        img.thumbnail((2400, 2400))
    except (UnidentifiedImageError, OSError):
        raise ValidationError("That file is not a readable image.")
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=85, optimize=True)
    buf.seek(0)
    return InMemoryUploadedFile(buf, "id_document", "document.jpg", "image/jpeg", buf.getbuffer().nbytes, None)


class KycForm(forms.ModelForm):
    class Meta:
        model = KycProfile
        fields = ["legal_name", "id_type", "id_number", "nationality", "date_of_birth",
                  "address", "occupation", "id_document"]
        widgets = {"date_of_birth": forms.DateInput(attrs={"type": "date"})}
        labels = {"id_document": "Photo of the ID document", "id_type": "ID type", "id_number": "ID number"}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        style(self)
        self.fields["id_document"].required = not (self.instance and self.instance.id_document)
        self.fields["id_document"].widget.attrs["accept"] = "image/jpeg,image/png,image/webp"

    def clean_id_number(self):
        return self.cleaned_data["id_number"].strip().upper()

    def clean_date_of_birth(self):
        dob = self.cleaned_data["date_of_birth"]
        today = timezone.localdate()
        age = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
        if age < 18:
            raise ValidationError("You must be at least 18 years old.")
        if age > 120:
            raise ValidationError("Check the date of birth.")
        return dob

    def clean_id_document(self):
        upload = self.cleaned_data.get("id_document")
        if upload and hasattr(upload, "content_type"):
            return reencode_image(upload)
        return upload

    def clean(self):
        data = super().clean()
        id_type, id_number = data.get("id_type"), data.get("id_number")
        if id_type and id_number:
            clash = KycProfile.objects.filter(id_type=id_type, id_number=id_number)
            if self.instance.pk:
                clash = clash.exclude(pk=self.instance.pk)
            if clash.exists():
                raise ValidationError("This ID document is already linked to another account.")
        return data
