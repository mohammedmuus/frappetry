from django.db import migrations

# TCRA National Numbering Plan allocations for mobile networks.
PREFIXES = [
    ("61", "Halotel", "HaloPesa", False),
    ("62", "Halotel", "HaloPesa", False),
    ("65", "Yas (formerly Tigo)", "Mixx by Yas", True),
    ("67", "Yas (formerly Tigo)", "Mixx by Yas", True),
    ("71", "Yas (formerly Tigo)", "Mixx by Yas", True),
    ("77", "Yas (formerly Zantel)", "Mixx by Yas", True),
    ("68", "Airtel", "Airtel Money", True),
    ("69", "Airtel", "Airtel Money", True),
    ("78", "Airtel", "Airtel Money", True),
    ("73", "TTCL", "T-Pesa", False),
    ("74", "Vodacom", "M-Pesa", True),
    ("75", "Vodacom", "M-Pesa", True),
    ("76", "Vodacom", "M-Pesa", True),
    ("79", "Vodacom", "M-Pesa", True),
]


def seed(apps, schema_editor):
    MobilePrefix = apps.get_model("accounts", "MobilePrefix")
    for prefix, operator, wallet, cashpay in PREFIXES:
        MobilePrefix.objects.get_or_create(prefix=prefix, defaults={
            "operator": operator, "wallet": wallet, "cashpay_supported": cashpay})


class Migration(migrations.Migration):
    dependencies = [("accounts", "0002_mobile_prefix")]
    operations = [migrations.RunPython(seed, migrations.RunPython.noop)]
