from django.contrib.auth import views as auth_views
from django.urls import path, reverse_lazy

from desderia.guards import rate_limit

from . import views
from .forms import style

app_name = "accounts"


class StyledResetForm(auth_views.PasswordResetForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        style(self)


class StyledSetPasswordForm(auth_views.SetPasswordForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        style(self)


urlpatterns = [
    path("auth/login/", views.login_view, name="login"),
    path("auth/login/verify/", views.login_verify, name="login_verify"),
    path("auth/logout/", views.logout_view, name="logout"),
    path("auth/register/", views.register, name="register"),
    path("auth/verify/", views.verify, name="verify"),
    path("auth/password-reset/", rate_limit("password_reset", limit=5, window=900)(
        auth_views.PasswordResetView.as_view(
            template_name="password_reset.html",
            email_template_name="password_reset_email.txt",
            subject_template_name="password_reset_subject.txt",
            form_class=StyledResetForm,
            success_url=reverse_lazy("accounts:password_reset_done"))),
        name="password_reset"),
    path("auth/password-reset/sent/", auth_views.PasswordResetDoneView.as_view(
        template_name="password_reset_done.html"), name="password_reset_done"),
    path("auth/reset/<uidb64>/<token>/", auth_views.PasswordResetConfirmView.as_view(
        template_name="password_reset_confirm.html", form_class=StyledSetPasswordForm,
        success_url=reverse_lazy("accounts:login")), name="password_reset_confirm"),
    path("account/", views.profile, name="profile"),
    path("account/security/", views.security, name="security"),
    path("account/security/devices/<uuid:token_id>/revoke/", views.revoke_device, name="revoke_device"),
    path("account/kyc/", views.kyc, name="kyc"),
    path("account/kyc/<uuid:user_id>/document/", views.kyc_document, name="kyc_document"),
]
