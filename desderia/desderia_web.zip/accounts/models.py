import re
import uuid

from django.conf import settings
from django.contrib.auth.base_user import AbstractBaseUser, BaseUserManager
from django.contrib.auth.models import PermissionsMixin
from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Q
from django.db.models.functions import Lower
from django.utils import timezone


# ─────────────────────────────────────────────────────────────
# PHONE NUMBERS
# ─────────────────────────────────────────────────────────────
# Customers type 0755..., +255755... and 255755... interchangeably. Every
# number is stored in E.164 so uniqueness and SMS matching are exact.

def normalise_phone(raw):
    digits = re.sub(r"[^\d+]", "", str(raw or "")).strip()
    if digits.startswith("00"):
        digits = "+" + digits[2:]
    if re.fullmatch(r"0[67]\d{8}", digits):
        return "+255" + digits[1:]
    if re.fullmatch(r"255[67]\d{8}", digits):
        return "+" + digits
    if re.fullmatch(r"\+\d{8,15}", digits):
        return digits
    raise ValidationError("Enter a valid phone number, for example +255 7XX XXX XXX.")


class UserManager(BaseUserManager):
    use_in_migrations = True

    def _create(self, email, phone, password, **extra):
        if not email:
            raise ValueError("Email is required")
        user = self.model(email=self.normalize_email(email).lower(), phone=normalise_phone(phone), **extra)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, email, phone, password=None, **extra):
        extra.setdefault("role", User.ROLE_CUSTOMER)
        return self._create(email, phone, password, **extra)

    def create_superuser(self, email, phone, password=None, **extra):
        extra.update(is_staff=True, is_superuser=True, role=User.ROLE_ADMIN,
                     email_verified_at=timezone.now(), phone_verified_at=timezone.now())
        return self._create(email, phone, password, **extra)


class User(AbstractBaseUser, PermissionsMixin):
    """Customers and staff share one table. Login is by email; phone is mandatory."""

    ROLE_CUSTOMER = "customer"
    ROLE_TELLER = "teller"
    ROLE_MANAGER = "manager"
    ROLE_AUDITOR = "auditor"
    ROLE_ADMIN = "admin"
    ROLE_CHOICES = [
        (ROLE_CUSTOMER, "Customer"),
        (ROLE_TELLER, "Teller"),
        (ROLE_MANAGER, "Manager"),
        (ROLE_AUDITOR, "Auditor"),
        (ROLE_ADMIN, "Administrator"),
    ]
    STAFF_ROLES = {ROLE_TELLER, ROLE_MANAGER, ROLE_ADMIN}

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email = models.EmailField(max_length=254, unique=True)
    phone = models.CharField(max_length=16, unique=True)
    full_name = models.CharField(max_length=150)
    role = models.CharField(max_length=12, choices=ROLE_CHOICES, default=ROLE_CUSTOMER)
    email_verified_at = models.DateTimeField(null=True, blank=True)
    phone_verified_at = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    notify_email = models.BooleanField(default=True)
    date_joined = models.DateTimeField(default=timezone.now)

    objects = UserManager()

    USERNAME_FIELD = "email"
    EMAIL_FIELD = "email"
    REQUIRED_FIELDS = ["phone", "full_name"]

    class Meta:
        ordering = ["full_name"]
        constraints = [
            # Database level: no two accounts may differ only by letter case.
            models.UniqueConstraint(Lower("email"), name="user_email_ci_unique"),
            models.CheckConstraint(
                condition=Q(role__in=["customer", "teller", "manager", "auditor", "admin"]),
                name="user_role_valid",
            ),
            models.CheckConstraint(condition=Q(phone__startswith="+"), name="user_phone_e164"),
        ]

    def __str__(self):
        return f"{self.full_name} <{self.email}>"

    def clean(self):
        super().clean()
        self.email = (self.email or "").strip().lower()
        if self.phone:
            self.phone = normalise_phone(self.phone)

    @property
    def is_fully_verified(self):
        return bool(self.email_verified_at and self.phone_verified_at)

    @property
    def is_bureau_staff(self):
        return self.is_superuser or self.role in self.STAFF_ROLES

    @property
    def is_customer(self):
        return self.role == self.ROLE_CUSTOMER and not self.is_superuser

    @property
    def first_name(self):
        return (self.full_name or "").split(" ")[0]

    @property
    def home_url(self):
        if self.is_superuser or self.role in (self.ROLE_TELLER, self.ROLE_MANAGER, self.ROLE_ADMIN):
            return "/desk/"
        if self.role == self.ROLE_AUDITOR:
            return "/audit/"
        return "/exchange/"

    @property
    def kyc_approved(self):
        kyc = getattr(self, "kyc", None)
        return bool(kyc and kyc.status == KycProfile.STATUS_APPROVED)


# ─────────────────────────────────────────────────────────────
# ONE TIME CODES
# ─────────────────────────────────────────────────────────────
# Codes are never stored in clear. Each row allows a fixed number of
# guesses and expires; consuming it is a conditional UPDATE so two
# concurrent submissions cannot both succeed.

class OneTimeCode(models.Model):
    PURPOSE_EMAIL = "verify_email"
    PURPOSE_PHONE = "verify_phone"
    PURPOSE_LOGIN = "login"
    PURPOSE_CHOICES = [
        (PURPOSE_EMAIL, "Verify email"),
        (PURPOSE_PHONE, "Verify phone"),
        (PURPOSE_LOGIN, "Login step two"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="codes")
    purpose = models.CharField(max_length=16, choices=PURPOSE_CHOICES)
    code_hash = models.CharField(max_length=128)
    channel = models.CharField(max_length=8, default="email")
    attempts = models.PositiveSmallIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()
    used_at = models.DateTimeField(null=True, blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)

    class Meta:
        indexes = [models.Index(fields=["user", "purpose", "used_at"])]
        constraints = [
            models.CheckConstraint(condition=Q(attempts__lte=20), name="otp_attempts_bounded"),
        ]

    @property
    def is_live(self):
        return self.used_at is None and self.expires_at > timezone.now() and self.attempts < settings.OTP_MAX_ATTEMPTS


# ─────────────────────────────────────────────────────────────
# KNOW YOUR CUSTOMER
# ─────────────────────────────────────────────────────────────

def kyc_upload_path(instance, filename):
    return f"kyc/{instance.user_id}/{uuid.uuid4().hex}.jpg"


class KycProfile(models.Model):
    """Bank of Tanzania bureau rules: identify the customer before larger trades."""

    STATUS_NONE = "not_submitted"
    STATUS_PENDING = "pending"
    STATUS_APPROVED = "approved"
    STATUS_REJECTED = "rejected"
    STATUS_CHOICES = [
        (STATUS_NONE, "Not submitted"),
        (STATUS_PENDING, "Pending review"),
        (STATUS_APPROVED, "Approved"),
        (STATUS_REJECTED, "Rejected"),
    ]
    ID_TYPES = [
        ("nida", "NIDA national ID"),
        ("passport", "Passport"),
        ("driving", "Driving licence"),
        ("voter", "Voter ID"),
        ("zanzibar", "Zanzibar resident ID"),
    ]

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="kyc")
    legal_name = models.CharField(max_length=150)
    id_type = models.CharField(max_length=12, choices=ID_TYPES)
    id_number = models.CharField(max_length=40)
    nationality = models.CharField(max_length=60, default="Tanzanian")
    date_of_birth = models.DateField()
    address = models.CharField(max_length=255)
    occupation = models.CharField(max_length=100)
    id_document = models.FileField(upload_to=kyc_upload_path, blank=True)
    status = models.CharField(max_length=16, choices=STATUS_CHOICES, default=STATUS_PENDING)
    review_note = models.CharField(max_length=255, blank=True)
    reviewed_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True,
                                    on_delete=models.PROTECT, related_name="kyc_reviews")
    reviewed_at = models.DateTimeField(null=True, blank=True)
    submitted_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "KYC profile"
        constraints = [
            models.UniqueConstraint(fields=["id_type", "id_number"], name="kyc_id_unique"),
            models.CheckConstraint(
                condition=Q(status__in=["not_submitted", "pending", "approved", "rejected"]),
                name="kyc_status_valid",
            ),
            # An approval must always name who approved it.
            models.CheckConstraint(
                condition=~Q(status="approved") | Q(reviewed_by__isnull=False),
                name="kyc_approval_has_reviewer",
            ),
        ]

    def __str__(self):
        return f"KYC {self.legal_name} ({self.get_status_display()})"


# ─────────────────────────────────────────────────────────────
# DEVICE TOKENS FOR THE MOBILE APP
# ─────────────────────────────────────────────────────────────

class ApiToken(models.Model):
    """Expiring bearer token. Only a SHA-256 of the key is stored."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="api_tokens")
    key_hash = models.CharField(max_length=64, unique=True)
    device_name = models.CharField(max_length=80, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    last_used_at = models.DateTimeField(null=True, blank=True)
    expires_at = models.DateTimeField()
    revoked_at = models.DateTimeField(null=True, blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.user.email} {self.device_name or 'device'}"

    @property
    def is_valid(self):
        return self.revoked_at is None and self.expires_at > timezone.now()
