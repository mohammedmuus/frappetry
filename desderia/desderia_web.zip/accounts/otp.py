"""One time codes for email verification, phone verification and login step two."""

import secrets
from datetime import timedelta

from django.conf import settings
from django.core.mail import send_mail
from django.db.models import F
from django.utils import timezone
from django.utils.crypto import constant_time_compare, salted_hmac

from audit.services import record
from desderia.middleware import client_ip

from .models import OneTimeCode
from .sms import send_sms


class OtpError(Exception):
    pass


def _hash(code_id, code):
    return salted_hmac("desderia.otp", f"{code_id}:{code}", algorithm="sha256").hexdigest()


def issue(user, purpose, channel="email", request=None):
    """Create and deliver a fresh six digit code. Older live codes are retired."""
    last = (OneTimeCode.objects.filter(user=user, purpose=purpose, used_at__isnull=True)
            .order_by("-created_at").first())
    if last and (timezone.now() - last.created_at).total_seconds() < settings.OTP_RESEND_COOLDOWN:
        wait = int(settings.OTP_RESEND_COOLDOWN - (timezone.now() - last.created_at).total_seconds())
        raise OtpError(f"Please wait {max(wait, 1)} seconds before requesting another code.")

    OneTimeCode.objects.filter(user=user, purpose=purpose, used_at__isnull=True).update(used_at=timezone.now())
    code = f"{secrets.randbelow(1_000_000):06d}"
    otp = OneTimeCode(user=user, purpose=purpose, channel=channel,
                      expires_at=timezone.now() + timedelta(seconds=settings.OTP_TTL_SECONDS),
                      ip_address=client_ip(request) or None)
    otp.code_hash = _hash(otp.id, code)
    otp.save()

    minutes = settings.OTP_TTL_SECONDS // 60
    text = f"Your Desderia code is {code}. It expires in {minutes} minutes. Never share this code."
    if channel == "sms":
        send_sms(user.phone, text)
    else:
        send_mail("Your Desderia verification code", text + "\n\nIf you did not request this, ignore this email.",
                  settings.DEFAULT_FROM_EMAIL, [user.email], fail_silently=True)
    record("otp.issued", user, f"{otp.get_purpose_display()} code sent by {channel}",
           data={"purpose": purpose, "channel": channel}, actor=user, request=request)
    return otp


def verify(user, purpose, code, request=None):
    """Check a code. Each wrong guess is counted atomically; success consumes it once."""
    code = (code or "").strip()
    otp = (OneTimeCode.objects.filter(user=user, purpose=purpose, used_at__isnull=True)
           .order_by("-created_at").first())
    if otp is None or not otp.is_live:
        raise OtpError("This code has expired. Request a new one.")
    if not (len(code) == 6 and code.isdigit() and constant_time_compare(otp.code_hash, _hash(otp.id, code))):
        OneTimeCode.objects.filter(pk=otp.pk).update(attempts=F("attempts") + 1)
        record("otp.failed", user, "Wrong one time code entered", data={"purpose": purpose},
               actor=user, request=request)
        left = settings.OTP_MAX_ATTEMPTS - otp.attempts - 1
        if left <= 0:
            raise OtpError("Too many wrong codes. Request a new one.")
        raise OtpError(f"That code is not correct. {left} attempt(s) left.")
    claimed = OneTimeCode.objects.filter(pk=otp.pk, used_at__isnull=True).update(used_at=timezone.now())
    if not claimed:
        raise OtpError("This code was already used.")
    return True
