from django.core.management.base import BaseCommand

from exchange.services import expire_stale


class Command(BaseCommand):
    help = "Expire approved requests whose funding window passed. Schedule every 15 minutes."

    def handle(self, *args, **options):
        self.stdout.write(f"Expired {expire_stale()} request(s).")
