from django.urls import path

from . import views

app_name = "exchange"

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("requests/", views.request_list, name="request_list"),
    path("new/", views.request_create, name="request_create"),
    path("quote/", views.quote_json, name="quote"),
    path("r/<str:reference>/", views.request_detail, name="request_detail"),
    path("r/<str:reference>/status.json", views.request_status_json, name="request_status"),
    path("r/<str:reference>/offer/", views.request_offer, name="request_offer"),
    path("r/<str:reference>/offer/<uuid:offer_id>/respond/", views.request_offer_respond, name="request_offer_respond"),
    path("r/<str:reference>/cancel/", views.request_cancel, name="request_cancel"),
    path("r/<str:reference>/pay/", views.request_pay, name="request_pay"),
    path("r/<str:reference>/paid/", views.request_paid, name="request_paid"),
    path("r/<str:reference>/received/", views.request_confirm_receipt, name="request_confirm_receipt"),
    path("beneficiaries/", views.beneficiary_list, name="beneficiary_list"),
    path("beneficiaries/new/", views.beneficiary_create, name="beneficiary_create"),
    path("beneficiaries/<uuid:pk>/remove/", views.beneficiary_delete, name="beneficiary_delete"),
]
