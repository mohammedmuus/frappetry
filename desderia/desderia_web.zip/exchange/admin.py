from django.contrib import admin

from desderia.admin_mixins import NoDeleteAdmin, ReadOnlyAdmin

from .models import Beneficiary, ExchangeRequest, Offer, StatusEvent


class OfferInline(ReadOnlyAdmin, admin.TabularInline):
    model = Offer
    extra = 0
    fields = ["side", "rate", "message", "status", "made_by", "responded_by", "created_at"]
    readonly_fields = fields


class EventInline(ReadOnlyAdmin, admin.TabularInline):
    model = StatusEvent
    extra = 0
    fields = ["from_status", "to_status", "actor", "note", "at"]
    readonly_fields = fields


class PaymentInline(ReadOnlyAdmin, admin.TabularInline):
    from payments.models import Payment as model  # noqa: N813
    extra = 0
    fields = ["reference", "gateway", "amount", "currency", "status", "settled_txid", "customer_reference",
              "confirmed_by", "paid_at"]
    readonly_fields = fields


@admin.register(ExchangeRequest)
class ExchangeRequestAdmin(ReadOnlyAdmin, admin.ModelAdmin):
    """Read only: money state changes only through the desk, which locks and audits them."""

    list_display = ["reference", "customer", "direction", "currency", "foreign_amount", "board_rate",
                    "agreed_rate", "local_amount", "status", "source_system", "created_at"]
    list_filter = ["status", "direction", "currency", "funding_method", "payout_method", "source_system"]
    search_fields = ["reference", "customer__email", "customer__phone", "funding_reference", "payout_reference"]
    date_hierarchy = "created_at"
    inlines = [OfferInline, PaymentInline, EventInline]

    def has_view_permission(self, request, obj=None):
        return True


@admin.register(Offer)
class OfferAdmin(ReadOnlyAdmin, admin.ModelAdmin):
    list_display = ["request", "side", "rate", "status", "made_by", "created_at", "responded_at"]
    list_filter = ["side", "status"]
    search_fields = ["request__reference"]


@admin.register(StatusEvent)
class StatusEventAdmin(ReadOnlyAdmin, admin.ModelAdmin):
    list_display = ["request", "from_status", "to_status", "actor", "note", "at"]
    list_filter = ["to_status"]
    search_fields = ["request__reference", "note"]
    date_hierarchy = "at"


@admin.register(Beneficiary)
class BeneficiaryAdmin(NoDeleteAdmin, admin.ModelAdmin):
    list_display = ["label", "customer", "kind", "currency", "account_name", "bank_name", "mobile_network", "is_active"]
    list_filter = ["kind", "is_active", "currency", "mobile_network"]
    search_fields = ["label", "customer__email", "account_number", "account_name"]
    readonly_fields = ["customer", "created_at"]
