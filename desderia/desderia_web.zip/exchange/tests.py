import hashlib
import hmac
import json
import uuid
from decimal import Decimal

from django.core.cache import cache
from django.db import IntegrityError, transaction
from django.test import TestCase, override_settings
from django.utils import timezone

from accounts.models import User
from accounts.tests import make_user
from audit.models import AuditEntry
from audit.services import verify_chain
from payments.models import GatewayEvent, Payment
from rates.models import Currency, ExchangeRate
from support.models import Conversation
from support.services import post_message

from . import services
from .models import ExchangeRequest

SECRET = "test-webhook-secret-123"


class Base(TestCase):
    def setUp(self):
        cache.clear()
        self.manager = make_user("mgr@x.test", role="manager")
        self.teller = make_user("tel@x.test", role="teller")
        self.teller2 = make_user("tel2@x.test", role="teller")
        self.customer = make_user("c@x.test")
        Currency.objects.create(code="TZS", name="Tanzanian Shilling")
        self.usd = Currency.objects.create(code="USD", name="US Dollar", min_negotiable_amount=Decimal("1000"))
        ExchangeRate.objects.create(currency=self.usd, buy_rate=Decimal("2575"), sell_rate=Decimal("2615"),
                                    effective_at=timezone.now(), set_by=self.manager)
        from treasury.services import post
        post("USD", "in", "opening", "1000000", self.manager, note="Test float")

    def new_request(self, amount="500", key=None, funding="bank_transfer"):
        req, _ = services.create_request(
            self.customer, direction="buy", currency_code="USD", amount=Decimal(amount), funding_method=funding,
            payout_method="cash_pickup", purpose="travel", source_of_funds="Salary",
            idempotency_key=key or uuid.uuid4())
        return req


class LifecycleTests(Base):
    def test_full_lifecycle_with_dual_control_and_audit(self):
        req = self.new_request("1000")
        self.assertEqual(req.local_amount, Decimal("2615000.00"))
        services.approve(req, self.teller)
        req.refresh_from_db()
        self.assertEqual(req.status, "approved")
        services.confirm_funds(req, self.teller, "bank-ref-001")
        req.refresh_from_db()
        self.assertEqual(req.funding_reference, "BANK-REF-001")
        with self.settings(DUAL_CONTROL_THRESHOLD_TZS=1_000_000):
            with self.assertRaisesMessage(services.ExchangeError, "Dual control"):
                services.mark_paid_out(req, self.teller, "WIRE-1")
            services.mark_paid_out(req, self.teller2, "WIRE-1")
        services.complete(req, self.customer)
        req.refresh_from_db()
        self.assertEqual(req.status, "completed")
        self.assertEqual(list(req.events.values_list("to_status", flat=True)),
                         ["submitted", "approved", "funded", "paid_out", "completed"])
        ok, checked, _, _ = verify_chain()
        self.assertTrue(ok)
        self.assertGreaterEqual(checked, 5)

    def test_idempotent_create(self):
        key = uuid.uuid4()
        a = self.new_request(key=key)
        b = self.new_request(key=key)
        self.assertEqual(a.pk, b.pk)
        self.assertEqual(ExchangeRequest.objects.count(), 1)

    def test_illegal_transition_refused(self):
        req = self.new_request()
        with self.assertRaises(services.ExchangeError):
            services.mark_paid_out(req, self.teller, "X")

    def test_staff_cannot_approve_own_request(self):
        req = self.new_request()
        self.customer.role = "teller"
        self.customer.save()
        with self.assertRaises(services.ExchangeError):
            services.approve(req, self.customer)

    def test_kyc_limit(self):
        with self.assertRaisesMessage(services.ExchangeError, "KYC"):
            self.new_request("5000")


class NegotiationTests(Base):
    def approve_kyc(self):
        from accounts.models import KycProfile
        KycProfile.objects.create(user=self.customer, legal_name="C Test", id_type="nida", id_number="1",
                                  date_of_birth="1990-01-01", address="Dar", occupation="Trader",
                                  status="approved", reviewed_by=self.manager)

    def test_band_and_agreement(self):
        self.approve_kyc()
        req = self.new_request("2000")
        with self.assertRaises(services.ExchangeError):
            services.make_offer(req, self.customer, Decimal("2400"))   # far below the band
        offer = services.make_offer(req, self.customer, Decimal("2600"), "Regular client")
        req.refresh_from_db()
        self.assertEqual(req.status, "negotiating")
        with self.assertRaises(services.ExchangeError):
            services.respond_offer(req, offer.pk, self.customer, True)  # cannot accept own offer
        services.respond_offer(req, offer.pk, self.teller, True)
        req.refresh_from_db()
        self.assertEqual(req.status, "approved")
        self.assertEqual(req.agreed_rate, Decimal("2600"))
        self.assertEqual(req.local_amount, Decimal("5200000.00"))

    def test_small_amount_not_negotiable(self):
        req = self.new_request("200")
        with self.assertRaisesMessage(services.ExchangeError, "Negotiation"):
            services.make_offer(req, self.customer, Decimal("2600"))


class DoubleEntryTests(Base):
    def test_reference_settles_one_request_only(self):
        a, b = self.new_request(), self.new_request()
        services.approve(a, self.teller)
        services.approve(b, self.teller)
        services.confirm_funds(a, self.teller, "REF-777")
        with self.assertRaisesMessage(services.ExchangeError, "already been used"):
            services.confirm_funds(b, self.teller, "ref-777")

    def test_confirm_twice_is_refused(self):
        req = self.new_request()
        services.approve(req, self.teller)
        services.confirm_funds(req, self.teller, "REF-1")
        with self.assertRaises(services.ExchangeError):
            services.confirm_funds(req, self.teller2, "REF-2")
        self.assertEqual(Payment.objects.filter(request=req, status="paid").count(), 1)

    def test_database_refuses_second_paid_payment(self):
        req = self.new_request()
        services.approve(req, self.teller)
        services.confirm_funds(req, self.teller, "REF-9")
        with self.assertRaises(IntegrityError), transaction.atomic():
            Payment.objects.create(request=req, gateway="manual", amount=1, currency="TZS", reference="X-1",
                                   status="paid", settled_txid="OTHER", paid_at=timezone.now(), created_by=self.teller)


class DatabaseGuardTests(Base):
    def test_audit_rows_are_immutable_in_the_database(self):
        self.new_request()
        entry = AuditEntry.objects.first()
        with self.assertRaises(Exception), transaction.atomic():
            AuditEntry.objects.filter(pk=entry.pk).update(summary="edited")
        with self.assertRaises(Exception), transaction.atomic():
            AuditEntry.objects.filter(pk=entry.pk).delete()

    def test_closed_request_is_frozen(self):
        req = self.new_request()
        services.cancel(req, self.customer)
        with self.assertRaises(Exception), transaction.atomic():
            ExchangeRequest.objects.filter(pk=req.pk).update(foreign_amount=1)

    def test_rates_are_append_only(self):
        rate = ExchangeRate.objects.first()
        with self.assertRaises(Exception), transaction.atomic():
            ExchangeRate.objects.filter(pk=rate.pk).update(sell_rate=1)


@override_settings(CASHPAY_API_URL="https://pay.example", CASHPAY_MERCHANT_ID="m1",
                   CASHPAY_API_KEY="k1", CASHPAY_WEBHOOK_SECRET=SECRET, ALLOWED_HOSTS=["testserver"])
class WebhookTests(Base):
    def _post(self, payload, secret=SECRET):
        body = json.dumps(payload).encode()
        sig = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
        return self.client.post("/payments/webhook/cashpay/", body, content_type="application/json",
                                HTTP_X_CASHPAY_SIGNATURE=sig)

    def _pending(self):
        req = self.new_request(funding="cashpay")
        services.approve(req, self.teller)
        req.refresh_from_db()
        payment = Payment.objects.create(request=req, gateway="cashpay", amount=req.local_amount, currency="TZS",
                                         reference=f"{req.reference}-P1", created_by=self.customer)
        return req, payment

    def test_valid_forged_and_replayed(self):
        req, payment = self._pending()
        payload = {"event_id": "ev1", "order_reference": payment.reference, "status": "success",
                   "amount": str(payment.amount), "currency": "TZS", "transaction_id": "CP123"}
        self.assertEqual(self._post(payload, secret="wrong").status_code, 403)
        payload["event_id"] = "ev2"
        self.assertEqual(self._post(payload).json()["detail"], "settled")
        req.refresh_from_db()
        self.assertEqual(req.status, "funded")
        self.assertEqual(self._post(payload).json()["detail"], "duplicate ignored")
        payload["event_id"] = "ev3"
        self.assertEqual(self._post(payload).json()["detail"], "not settled")
        self.assertEqual(Payment.objects.filter(request=req, status="paid").count(), 1)
        self.assertEqual(GatewayEvent.objects.count(), 3)

    def test_amount_mismatch_never_settles(self):
        req, payment = self._pending()
        self._post({"event_id": "e9", "order_reference": payment.reference, "status": "success",
                    "amount": "1.00", "currency": "TZS", "transaction_id": "CP9"})
        req.refresh_from_db()
        self.assertEqual(req.status, "approved")

    def test_placeholder_secret_disables_endpoint(self):
        with self.settings(CASHPAY_WEBHOOK_SECRET=""):
            r = self.client.post("/payments/webhook/cashpay/", b"{}", content_type="application/json")
        self.assertEqual(r.status_code, 503)
        self.assertEqual(self.client.get("/payments/webhook/cashpay/").status_code, 405)


class ChatTests(Base):
    def test_resend_with_same_client_id_posts_once(self):
        conv = Conversation.objects.create(customer=self.customer, subject="Hello")
        cid = uuid.uuid4()
        post_message(conv, self.customer, "Hi there", client_id=cid)
        post_message(conv, self.customer, "Hi there", client_id=cid)
        self.assertEqual(conv.messages.count(), 1)

    def test_other_customer_cannot_read_thread(self):
        conv = Conversation.objects.create(customer=self.customer, subject="Private")
        other = make_user("other@x.test")
        self.client.force_login(other)
        with self.settings(ALLOWED_HOSTS=["testserver"]):
            self.assertEqual(self.client.get(f"/chat/{conv.pk}/messages/").status_code, 404)


@override_settings(ALLOWED_HOSTS=["testserver"])
class TreasuryAndReportTests(Base):
    def _fund(self, amount="500"):
        req = self.new_request(amount)
        services.approve(req, self.teller)
        services.confirm_funds(req, self.teller, f"REF-{uuid.uuid4().hex[:6]}")
        req.refresh_from_db()
        return req

    def test_ledger_follows_money_and_blocks_overdraft(self):
        from treasury.models import LedgerEntry, TreasuryAccount
        req = self._fund("500")
        self.assertEqual(TreasuryAccount.objects.get(currency_id="TZS").balance, Decimal("1307500.00"))
        services.mark_paid_out(req, self.teller2, "CASH-1")
        self.assertEqual(TreasuryAccount.objects.get(currency_id="USD").balance, Decimal("999500.00"))
        self.assertEqual(LedgerEntry.objects.filter(request=req).count(), 2)
        LedgerEntry_count = LedgerEntry.objects.count()
        from treasury.services import post
        post("USD", "out", "withdrawal", "999500", self.manager, note="Bank deposit")
        req2 = self._fund("100")
        with self.assertRaisesMessage(services.ExchangeError, "Insufficient USD"):
            services.mark_paid_out(req2, self.teller2, "CASH-2")
        self.assertEqual(LedgerEntry.objects.count(), LedgerEntry_count + 2)

    def test_reports_download_and_access(self):
        self._fund()
        self.client.force_login(self.manager)
        for kind in ("requests", "payments", "ledger", "summary", "balances", "audit"):
            r = self.client.get(f"/reports/{kind}.xlsx")
            self.assertEqual(r.status_code, 200, kind)
            self.assertTrue(r.content.startswith(b"PK"), kind)
        self.client.force_login(self.teller)
        self.assertEqual(self.client.get("/reports/requests.xlsx")["Location"], "/desk/")

    def test_management_portal(self):
        self._fund()
        r = self.client.get("/management/")
        self.assertEqual(r.status_code, 302)
        self.client.force_login(self.manager)
        r = self.client.get("/management/login/?next=/management/")
        self.assertEqual(r["Location"], self.manager.home_url)
        boss = User.objects.create_superuser(email="root@x.test", phone="+255711000999", password="x-Strong-pass-1",
                                             full_name="Root Admin")
        self.client.force_login(boss)
        for url in ("/management/", "/management/accounts/user/", "/management/auth/group/",
                    "/management/exchange/exchangerequest/", "/management/treasury/ledgerentry/",
                    "/management/notifications/emaillog/", "/management/audit/auditentry/",
                    "/management/support/message/"):
            self.assertEqual(self.client.get(url).status_code, 200, url)
        r = self.client.post("/management/exchange/exchangerequest/",
                             {"action": "export_excel", "_selected_action": [str(x) for x in
                                                                             ExchangeRequest.objects.values_list("pk", flat=True)]})
        self.assertTrue(r.content.startswith(b"PK"))
