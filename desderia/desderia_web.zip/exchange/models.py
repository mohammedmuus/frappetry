import secrets
import uuid

from django.conf import settings
from django.db import models
from django.db.models import Q


# ─────────────────────────────────────────────────────────────
# BENEFICIARIES (where the bureau sends the money)
# ─────────────────────────────────────────────────────────────

class Beneficiary(models.Model):
    KIND_BANK = "bank"
    KIND_MOBILE = "mobile"
    KIND_CHOICES = [(KIND_BANK, "Bank account"), (KIND_MOBILE, "Mobile money")]
    NETWORKS = [("mpesa", "Vodacom M-Pesa"), ("mixx", "Mixx by Yas"), ("airtel", "Airtel Money"),
                ("halopesa", "HaloPesa"), ("tpesa", "TTCL T-Pesa")]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    customer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="beneficiaries")
    kind = models.CharField(max_length=8, choices=KIND_CHOICES, default=KIND_BANK)
    label = models.CharField(max_length=60, help_text="A short name you will recognise")
    account_name = models.CharField(max_length=120)
    bank_name = models.CharField(max_length=120, blank=True)
    account_number = models.CharField(max_length=40)
    swift_code = models.CharField(max_length=11, blank=True)
    branch = models.CharField(max_length=80, blank=True)
    mobile_network = models.CharField(max_length=10, choices=NETWORKS, blank=True)
    currency = models.ForeignKey("rates.Currency", on_delete=models.PROTECT, related_name="+")
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["label"]
        verbose_name_plural = "beneficiaries"
        constraints = [
            models.UniqueConstraint(fields=["customer", "kind", "account_number", "currency"],
                                    condition=Q(is_active=True), name="beneficiary_unique_active"),
            models.CheckConstraint(condition=Q(kind="mobile") | ~Q(bank_name=""), name="beneficiary_bank_named"),
            models.CheckConstraint(condition=Q(kind="bank") | ~Q(mobile_network=""),
                                   name="beneficiary_network_named"),
        ]

    def __str__(self):
        tail = self.account_number[-4:]
        where = self.bank_name if self.kind == self.KIND_BANK else self.get_mobile_network_display()
        return f"{self.label} ({where} ending {tail})"


# ─────────────────────────────────────────────────────────────
# EXCHANGE REQUESTS
# ─────────────────────────────────────────────────────────────

def make_reference():
    # Random, not sequential: references cannot be guessed or enumerated.
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "DSD-" + "".join(secrets.choice(alphabet) for _ in range(8))


class ExchangeRequest(models.Model):
    DIR_BUY = "buy"
    DIR_SELL = "sell"
    DIRECTION_CHOICES = [(DIR_BUY, "Buy foreign currency"), (DIR_SELL, "Sell foreign currency")]

    SUBMITTED = "submitted"
    NEGOTIATING = "negotiating"
    APPROVED = "approved"
    FUNDED = "funded"
    PAID_OUT = "paid_out"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    REJECTED = "rejected"
    EXPIRED = "expired"
    STATUS_CHOICES = [
        (SUBMITTED, "Submitted"),
        (NEGOTIATING, "Negotiating"),
        (APPROVED, "Approved, awaiting funds"),
        (FUNDED, "Funds received"),
        (PAID_OUT, "Paid out"),
        (COMPLETED, "Completed"),
        (CANCELLED, "Cancelled"),
        (REJECTED, "Rejected"),
        (EXPIRED, "Expired"),
    ]
    OPEN_STATUSES = (SUBMITTED, NEGOTIATING, APPROVED, FUNDED, PAID_OUT)
    FINAL_STATUSES = (COMPLETED, CANCELLED, REJECTED, EXPIRED)
    RATE_FIXED_STATUSES = (APPROVED, FUNDED, PAID_OUT, COMPLETED)

    FUND_CASHPAY = "cashpay"
    FUND_BANK = "bank_transfer"
    FUND_CASH = "cash"
    FUNDING_CHOICES = [(FUND_CASHPAY, "CashPay"), (FUND_BANK, "Bank transfer"), (FUND_CASH, "Cash at branch")]

    PAY_BANK = "bank_wire"
    PAY_MOBILE = "mobile_money"
    PAY_CASH = "cash_pickup"
    PAYOUT_CHOICES = [(PAY_BANK, "Bank wire"), (PAY_MOBILE, "Mobile money"), (PAY_CASH, "Cash pickup")]

    PURPOSES = [
        ("travel", "Travel"),
        ("education", "School or university fees"),
        ("medical", "Medical treatment"),
        ("trade", "Import or trade payment"),
        ("family", "Family support"),
        ("investment", "Investment"),
        ("savings", "Personal savings"),
        ("other", "Other"),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    reference = models.CharField(max_length=12, unique=True, default=make_reference, editable=False)
    customer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="exchange_requests")
    direction = models.CharField(max_length=4, choices=DIRECTION_CHOICES)
    currency = models.ForeignKey("rates.Currency", on_delete=models.PROTECT, related_name="requests")
    foreign_amount = models.DecimalField(max_digits=14, decimal_places=2)

    rate_snapshot = models.ForeignKey("rates.ExchangeRate", on_delete=models.PROTECT, related_name="+")
    board_rate = models.DecimalField(max_digits=14, decimal_places=4)
    quote_expires_at = models.DateTimeField()
    agreed_rate = models.DecimalField(max_digits=14, decimal_places=4, null=True, blank=True)
    local_amount = models.DecimalField(max_digits=18, decimal_places=2)
    fee_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    funding_method = models.CharField(max_length=16, choices=FUNDING_CHOICES)
    payout_method = models.CharField(max_length=16, choices=PAYOUT_CHOICES)
    beneficiary = models.ForeignKey(Beneficiary, null=True, blank=True, on_delete=models.PROTECT, related_name="requests")
    purpose = models.CharField(max_length=12, choices=PURPOSES)
    source_of_funds = models.CharField(max_length=160)
    customer_note = models.CharField(max_length=500, blank=True)

    status = models.CharField(max_length=12, choices=STATUS_CHOICES, default=SUBMITTED, db_index=True)
    # Client generated key: a retried submit returns the same request instead of a second one.
    idempotency_key = models.UUIDField(default=uuid.uuid4)
    version = models.PositiveIntegerField(default=1)

    assigned_to = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT,
                                    related_name="assigned_requests")
    approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT,
                                    related_name="+")
    approved_at = models.DateTimeField(null=True, blank=True)
    funding_deadline = models.DateTimeField(null=True, blank=True)
    funds_confirmed_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True,
                                           on_delete=models.PROTECT, related_name="+")
    funds_confirmed_at = models.DateTimeField(null=True, blank=True)
    funding_reference = models.CharField(max_length=64, blank=True)
    payout_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT,
                                  related_name="+")
    payout_at = models.DateTimeField(null=True, blank=True)
    payout_reference = models.CharField(max_length=64, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    closed_reason = models.CharField(max_length=255, blank=True)

    external_uuid = models.UUIDField(default=uuid.uuid4, unique=True)
    source_system = models.CharField(max_length=10, default="web")
    last_synced_at = models.DateTimeField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["customer", "status"]), models.Index(fields=["status", "created_at"])]
        constraints = [
            models.UniqueConstraint(fields=["customer", "idempotency_key"], name="request_idempotent"),
            # The same bank, mobile or gateway reference can never fund or pay two requests.
            models.UniqueConstraint(fields=["funding_reference"], condition=~Q(funding_reference=""),
                                    name="request_funding_ref_unique"),
            models.UniqueConstraint(fields=["payout_reference"], condition=~Q(payout_reference=""),
                                    name="request_payout_ref_unique"),
            models.CheckConstraint(condition=Q(foreign_amount__gt=0), name="request_amount_positive"),
            models.CheckConstraint(condition=Q(local_amount__gt=0) & Q(fee_amount__gte=0),
                                   name="request_local_positive"),
            models.CheckConstraint(condition=Q(board_rate__gt=0) & (Q(agreed_rate__isnull=True) | Q(agreed_rate__gt=0)),
                                   name="request_rates_positive"),
            models.CheckConstraint(condition=Q(direction__in=["buy", "sell"]), name="request_direction_valid"),
            models.CheckConstraint(
                condition=Q(status__in=["submitted", "negotiating", "approved", "funded", "paid_out",
                                        "completed", "cancelled", "rejected", "expired"]),
                name="request_status_valid"),
            # Once approved, a rate and an approver must exist, forever.
            models.CheckConstraint(
                condition=~Q(status__in=["approved", "funded", "paid_out", "completed"])
                | (Q(agreed_rate__isnull=False) & Q(approved_by__isnull=False)),
                name="request_approved_has_rate"),
            models.CheckConstraint(
                condition=~Q(status__in=["funded", "paid_out", "completed"])
                | (Q(funds_confirmed_by__isnull=False) & ~Q(funding_reference="")),
                name="request_funded_has_proof"),
            models.CheckConstraint(
                condition=~Q(status__in=["paid_out", "completed"])
                | (Q(payout_by__isnull=False) & ~Q(payout_reference="")),
                name="request_paid_out_has_proof"),
            models.CheckConstraint(
                condition=Q(payout_method="cash_pickup") | Q(beneficiary__isnull=False),
                name="request_transfer_needs_beneficiary"),
        ]

    def __str__(self):
        return self.reference

    @property
    def effective_rate(self):
        return self.agreed_rate or self.board_rate

    @property
    def is_open(self):
        return self.status in self.OPEN_STATUSES

    @property
    def customer_pays(self):
        """What the customer must send to the bureau: (amount, currency code)."""
        if self.direction == self.DIR_BUY:
            return self.local_amount + self.fee_amount, settings.BASE_CURRENCY
        return self.foreign_amount, self.currency_id

    @property
    def customer_receives(self):
        if self.direction == self.DIR_BUY:
            return self.foreign_amount, self.currency_id
        return self.local_amount - self.fee_amount, settings.BASE_CURRENCY

    @property
    def status_tone(self):
        return {
            self.SUBMITTED: "pending", self.NEGOTIATING: "info", self.APPROVED: "info",
            self.FUNDED: "info", self.PAID_OUT: "good", self.COMPLETED: "good",
            self.CANCELLED: "muted", self.REJECTED: "bad", self.EXPIRED: "muted",
        }.get(self.status, "muted")

    @property
    def pending_offer(self):
        return self.offers.filter(status=Offer.PENDING).first()


class Offer(models.Model):
    """One rate proposal in a negotiation. Only one may be pending at a time."""

    PENDING = "pending"
    ACCEPTED = "accepted"
    DECLINED = "declined"
    SUPERSEDED = "superseded"
    WITHDRAWN = "withdrawn"
    STATUS_CHOICES = [(PENDING, "Pending"), (ACCEPTED, "Accepted"), (DECLINED, "Declined"),
                      (SUPERSEDED, "Superseded"), (WITHDRAWN, "Withdrawn")]
    SIDE_CHOICES = [("customer", "Customer"), ("bureau", "Desderia")]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    request = models.ForeignKey(ExchangeRequest, on_delete=models.PROTECT, related_name="offers")
    side = models.CharField(max_length=8, choices=SIDE_CHOICES)
    made_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    rate = models.DecimalField(max_digits=14, decimal_places=4)
    message = models.CharField(max_length=300, blank=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default=PENDING)
    responded_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT,
                                     related_name="+")
    responded_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at"]
        constraints = [
            models.UniqueConstraint(fields=["request"], condition=Q(status="pending"), name="offer_one_pending"),
            models.CheckConstraint(condition=Q(rate__gt=0), name="offer_rate_positive"),
            models.CheckConstraint(condition=Q(side__in=["customer", "bureau"]), name="offer_side_valid"),
        ]

    def __str__(self):
        return f"{self.request.reference} {self.side} {self.rate}"


class StatusEvent(models.Model):
    """Customer facing timeline. The full forensic record lives in audit."""

    request = models.ForeignKey(ExchangeRequest, on_delete=models.PROTECT, related_name="events")
    from_status = models.CharField(max_length=12, blank=True)
    to_status = models.CharField(max_length=12)
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.PROTECT,
                              related_name="+")
    note = models.CharField(max_length=255, blank=True)
    at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["at", "id"]

    def __str__(self):
        return f"{self.request.reference} {self.from_status} to {self.to_status}"

    @property
    def label(self):
        return dict(ExchangeRequest.STATUS_CHOICES).get(self.to_status, self.to_status)

    def save(self, *args, **kwargs):
        if not self._state.adding:
            raise PermissionError("Timeline events are append only")
        super().save(*args, **kwargs)
