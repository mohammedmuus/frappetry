"""
The exchange request state machine. Every change of money state goes
through this module: it locks the row, checks the transition, writes the
timeline and the audit chain in the same transaction, then notifies the
customer after commit.

    submitted -> negotiating -> approved -> funded -> paid_out -> completed
         \\            \\            \\
          +-> rejected / cancelled   +-> cancelled / expired
"""

from datetime import timedelta
from decimal import ROUND_HALF_UP, Decimal

from django.conf import settings
from django.contrib.auth import get_user_model
from django.db import IntegrityError, transaction
from django.utils import timezone

from audit.services import record
from notifications import services as notes
from rates.models import Currency
from support.services import conversation_for_request, post_system
from treasury import services as treasury

from .models import Beneficiary, ExchangeRequest, Offer, StatusEvent

TWO = Decimal("0.01")
FOUR = Decimal("0.0001")
MAX_OPEN_REQUESTS = 5

TRANSITIONS = {
    ExchangeRequest.SUBMITTED: {ExchangeRequest.NEGOTIATING, ExchangeRequest.APPROVED,
                                ExchangeRequest.REJECTED, ExchangeRequest.CANCELLED},
    ExchangeRequest.NEGOTIATING: {ExchangeRequest.APPROVED, ExchangeRequest.REJECTED, ExchangeRequest.CANCELLED},
    ExchangeRequest.APPROVED: {ExchangeRequest.FUNDED, ExchangeRequest.CANCELLED, ExchangeRequest.EXPIRED},
    ExchangeRequest.FUNDED: {ExchangeRequest.PAID_OUT},
    ExchangeRequest.PAID_OUT: {ExchangeRequest.COMPLETED},
}


class ExchangeError(Exception):
    pass


def system_user():
    """Service account that settles gateway payments. It cannot sign in."""
    User = get_user_model()
    user = User.objects.filter(email="system@desderia.internal").first()
    if user is None:
        user = User(email="system@desderia.internal", phone="+000000000000", full_name="Desderia System",
                    role=User.ROLE_ADMIN, is_active=False)
        user.set_unusable_password()
        user.save()
    return user


# ─────────────────────────────────────────────────────────────
# QUOTES
# ─────────────────────────────────────────────────────────────

def live_rate(currency):
    rate = currency.current_rate
    if rate is None:
        raise ExchangeError(f"No live rate is published for {currency.code}.")
    return rate


def board_rate_for(rate, direction):
    # The customer buys foreign currency at our SELL rate, and sells at our BUY rate.
    return rate.sell_rate if direction == ExchangeRequest.DIR_BUY else rate.buy_rate


def local_for(amount, rate):
    return (Decimal(amount) * Decimal(rate)).quantize(TWO, rounding=ROUND_HALF_UP)


def quote(currency, direction, amount):
    rate = live_rate(currency)
    board = board_rate_for(rate, direction)
    amount = Decimal(amount).quantize(TWO)
    return {
        "currency": currency.code,
        "direction": direction,
        "foreign_amount": amount,
        "rate": board,
        "local_amount": local_for(amount, board),
        "rate_id": rate.pk,
        "expires_at": timezone.now() + timedelta(minutes=settings.QUOTE_LOCK_MINUTES),
        "negotiable": amount >= currency.min_negotiable_amount,
    }


# ─────────────────────────────────────────────────────────────
# CREATE
# ─────────────────────────────────────────────────────────────

ALLOWED_FUNDING = {
    ExchangeRequest.DIR_BUY: {ExchangeRequest.FUND_CASHPAY, ExchangeRequest.FUND_BANK, ExchangeRequest.FUND_CASH},
    ExchangeRequest.DIR_SELL: {ExchangeRequest.FUND_BANK, ExchangeRequest.FUND_CASH},
}
ALLOWED_PAYOUT = {
    ExchangeRequest.DIR_BUY: {ExchangeRequest.PAY_BANK, ExchangeRequest.PAY_CASH},
    ExchangeRequest.DIR_SELL: {ExchangeRequest.PAY_BANK, ExchangeRequest.PAY_MOBILE, ExchangeRequest.PAY_CASH},
}


def validate_new(customer, direction, currency, amount, funding_method, payout_method, beneficiary):
    if not customer.is_fully_verified:
        raise ExchangeError("Verify your email and phone number first.")
    if not currency.is_active or currency.code == settings.BASE_CURRENCY:
        raise ExchangeError("This currency is not available.")
    amount = Decimal(amount)
    if amount < currency.min_amount or amount > currency.max_amount:
        raise ExchangeError(f"Amount must be between {currency.min_amount:,.0f} and {currency.max_amount:,.0f} "
                            f"{currency.code}.")
    usd_equiv = amount * currency.usd_value
    if usd_equiv > settings.KYC_UNVERIFIED_LIMIT_USD and not customer.kyc_approved:
        raise ExchangeError(f"Requests above USD {settings.KYC_UNVERIFIED_LIMIT_USD:,} need approved KYC. "
                            "Submit your ID under Account, KYC.")
    if funding_method not in ALLOWED_FUNDING[direction]:
        raise ExchangeError("That funding method is not available for this request.")
    if payout_method not in ALLOWED_PAYOUT[direction]:
        raise ExchangeError("That payout method is not available for this request.")
    if payout_method == ExchangeRequest.PAY_CASH:
        return None
    if beneficiary is None:
        raise ExchangeError("Choose where we should send the money.")
    if beneficiary.customer_id != customer.pk or not beneficiary.is_active:
        raise ExchangeError("Choose one of your saved beneficiaries.")
    payout_currency = currency.code if direction == ExchangeRequest.DIR_BUY else settings.BASE_CURRENCY
    if beneficiary.currency_id != payout_currency:
        raise ExchangeError(f"The beneficiary must hold {payout_currency}.")
    wanted_kind = Beneficiary.KIND_MOBILE if payout_method == ExchangeRequest.PAY_MOBILE else Beneficiary.KIND_BANK
    if beneficiary.kind != wanted_kind:
        raise ExchangeError("The beneficiary type does not match the payout method.")
    return beneficiary


def create_request(customer, *, direction, currency_code, amount, funding_method, payout_method,
                   beneficiary=None, purpose, source_of_funds, note="", idempotency_key=None, source="web"):
    """Returns (request, created). A repeated idempotency key returns the first request."""
    if idempotency_key:
        existing = ExchangeRequest.objects.filter(customer=customer, idempotency_key=idempotency_key).first()
        if existing:
            return existing, False

    currency = Currency.objects.filter(code=currency_code, is_active=True).first()
    if currency is None:
        raise ExchangeError("This currency is not available.")
    beneficiary = validate_new(customer, direction, currency, amount, funding_method, payout_method, beneficiary)
    if ExchangeRequest.objects.filter(customer=customer, status__in=ExchangeRequest.OPEN_STATUSES).count() >= MAX_OPEN_REQUESTS:
        raise ExchangeError(f"You already have {MAX_OPEN_REQUESTS} open requests. Complete or cancel one first.")

    q = quote(currency, direction, amount)
    try:
        with transaction.atomic():
            req = ExchangeRequest(
                customer=customer, direction=direction, currency=currency,
                foreign_amount=q["foreign_amount"], rate_snapshot_id=q["rate_id"], board_rate=q["rate"],
                quote_expires_at=q["expires_at"], local_amount=q["local_amount"],
                funding_method=funding_method, payout_method=payout_method, beneficiary=beneficiary,
                purpose=purpose, source_of_funds=source_of_funds[:160], customer_note=(note or "")[:500],
                source_system=source,
            )
            if idempotency_key:
                req.idempotency_key = idempotency_key
            for _ in range(5):
                try:
                    with transaction.atomic():
                        req.save()
                    break
                except IntegrityError as exc:
                    if "reference" not in str(exc).lower():
                        raise
                    from .models import make_reference
                    req.reference = make_reference()
            StatusEvent.objects.create(request=req, to_status=req.status, actor=customer,
                                       note=f"Quoted at {req.board_rate:,.2f}")
            conv = conversation_for_request(req)
            post_system(conv, f"Request {req.reference} submitted at {req.board_rate:,.2f} "
                              f"for {req.foreign_amount:,.2f} {currency.code}.")
            record("request.created", req, f"{req.reference} {req.get_direction_display()} "
                                           f"{req.foreign_amount} {currency.code} at {req.board_rate}",
                   data={"reference": req.reference, "amount": str(req.foreign_amount), "rate": str(req.board_rate),
                         "local": str(req.local_amount), "funding": funding_method, "payout": payout_method})
            notes.notify_request_status(req)
            notes.notify_staff("request_new", {"customer": customer, "ref": req.reference})
    except IntegrityError:
        existing = ExchangeRequest.objects.filter(customer=customer, idempotency_key=idempotency_key).first()
        if existing:
            return existing, False
        raise
    return req, True


# ─────────────────────────────────────────────────────────────
# TRANSITIONS
# ─────────────────────────────────────────────────────────────

def _lock(req_or_pk):
    pk = getattr(req_or_pk, "pk", req_or_pk)
    return ExchangeRequest.objects.select_for_update().get(pk=pk)


def _guard_staff(req, actor):
    if not actor.is_bureau_staff:
        raise ExchangeError("Only bureau staff can do this.")
    if actor.pk == req.customer_id:
        raise ExchangeError("Staff cannot act on their own request.")


def _move(req, to, actor, note="", audit_data=None):
    if to not in TRANSITIONS.get(req.status, set()):
        raise ExchangeError(f"A request that is {req.get_status_display().lower()} cannot move to {to}.")
    frm = req.status
    req.status = to
    req.version += 1
    req.save()
    StatusEvent.objects.create(request=req, from_status=frm, to_status=to, actor=actor, note=note[:255])
    record(f"request.{to}", req, f"{req.reference} {frm} to {to}" + (f": {note}" if note else ""),
           data={"from": frm, "to": to, **(audit_data or {})}, actor=actor if actor.is_active else None)
    post_system(conversation_for_request(req), f"Status: {req.get_status_display()}." + (f" {note}" if note else ""))
    notes.notify_request_status(req, reason=note)
    return req


def _fix_rate(req, rate, approver):
    req.agreed_rate = Decimal(rate).quantize(FOUR)
    req.local_amount = local_for(req.foreign_amount, req.agreed_rate)
    req.approved_by = approver
    req.approved_at = timezone.now()
    req.funding_deadline = timezone.now() + timedelta(hours=settings.FUNDING_WINDOW_HOURS)


@transaction.atomic
def approve(req, staff):
    req = _lock(req)
    _guard_staff(req, staff)
    if req.status != ExchangeRequest.SUBMITTED:
        raise ExchangeError("Only a submitted request can be approved directly.")
    current = board_rate_for(live_rate(req.currency), req.direction)
    if timezone.now() > req.quote_expires_at and current != req.board_rate:
        # The locked quote lapsed and the market moved: re-quote, do not guess.
        offer = _create_offer(req, staff, "bureau", current,
                              "Your quote expired. This is today's rate for your request.")
        return req, offer
    _fix_rate(req, req.board_rate, staff)
    _move(req, ExchangeRequest.APPROVED, staff, f"Approved at {req.agreed_rate:,.2f}",
          {"rate": str(req.agreed_rate), "local": str(req.local_amount)})
    return req, None


@transaction.atomic
def reject(req, staff, reason):
    req = _lock(req)
    _guard_staff(req, staff)
    if not reason.strip():
        raise ExchangeError("Give the customer a reason.")
    req.offers.filter(status=Offer.PENDING).update(status=Offer.WITHDRAWN, responded_at=timezone.now())
    req.closed_reason = reason[:255]
    return _move(req, ExchangeRequest.REJECTED, staff, reason)


@transaction.atomic
def cancel(req, customer, reason=""):
    req = _lock(req)
    if customer.pk != req.customer_id and not customer.is_bureau_staff:
        raise ExchangeError("Not allowed.")
    if req.payments.filter(status="paid").exists():
        raise ExchangeError("Funds were already received. Contact us to reverse this request.")
    req.offers.filter(status=Offer.PENDING).update(status=Offer.WITHDRAWN, responded_at=timezone.now())
    req.payments.filter(status="pending").update(status="cancelled")
    req.closed_reason = (reason or "Cancelled by customer")[:255]
    return _move(req, ExchangeRequest.CANCELLED, customer, req.closed_reason)


# ─────────────────────────────────────────────────────────────
# NEGOTIATION
# ─────────────────────────────────────────────────────────────

def _create_offer(req, user, side, rate, message):
    rate = Decimal(rate).quantize(FOUR)
    req.offers.filter(status=Offer.PENDING).update(status=Offer.SUPERSEDED, responded_by=user,
                                                    responded_at=timezone.now())
    offer = Offer.objects.create(request=req, side=side, made_by=user, rate=rate, message=(message or "")[:300])
    if req.status == ExchangeRequest.SUBMITTED:
        _move(req, ExchangeRequest.NEGOTIATING, user, "Negotiation opened")
    else:
        req.version += 1
        req.save(update_fields=["version", "updated_at"])
    who = "Desderia" if side == "bureau" else req.customer.first_name
    post_system(conversation_for_request(req),
                f"{who} offered {rate:,.2f}." + (f" Note: {offer.message}" if offer.message else ""))
    record("offer.made", offer, f"{side} offered {rate} on {req.reference}",
           data={"reference": req.reference, "side": side, "rate": str(rate)}, actor=user)
    if side == "bureau":
        notes.notify_offer(req, offer)
    else:
        notes.notify_staff("offer_customer", {"customer": req.customer, "ref": req.reference, "rate": f"{rate:,.2f}"})
    return offer


@transaction.atomic
def make_offer(req, user, rate, message=""):
    req = _lock(req)
    if req.status not in (ExchangeRequest.SUBMITTED, ExchangeRequest.NEGOTIATING):
        raise ExchangeError("Rates can only be negotiated before approval.")
    rate = Decimal(rate)
    board = board_rate_for(live_rate(req.currency), req.direction)
    if user.pk == req.customer_id:
        side = "customer"
        if req.foreign_amount < req.currency.min_negotiable_amount:
            raise ExchangeError(f"Negotiation is available from {req.currency.min_negotiable_amount:,.0f} "
                                f"{req.currency.code}.")
        band = board * req.currency.negotiation_band_pct / Decimal(100)
        if req.direction == ExchangeRequest.DIR_BUY:
            if not (board - band <= rate < board):
                raise ExchangeError(f"Propose a rate between {board - band:,.2f} and {board:,.2f}.")
        else:
            if not (board < rate <= board + band):
                raise ExchangeError(f"Propose a rate between {board:,.2f} and {board + band:,.2f}.")
        if req.offers.filter(side="customer").count() >= 5:
            raise ExchangeError("You have reached the limit of 5 offers on this request. Chat with us instead.")
    elif user.is_bureau_staff:
        _guard_staff(req, user)
        side = "bureau"
        if abs(rate - board) > board * Decimal("0.10"):
            raise ExchangeError("A bureau offer must stay within 10 percent of the board rate.")
    else:
        raise ExchangeError("Not allowed.")
    return _create_offer(req, user, side, rate, message)


@transaction.atomic
def respond_offer(req, offer_id, user, accept):
    req = _lock(req)
    offer = Offer.objects.select_for_update().filter(pk=offer_id, request=req).first()
    if offer is None or offer.status != Offer.PENDING:
        raise ExchangeError("This offer is no longer open.")
    if offer.side == "bureau" and user.pk != req.customer_id:
        raise ExchangeError("Only the customer can answer a bureau offer.")
    if offer.side == "customer":
        _guard_staff(req, user)
    offer.status = Offer.ACCEPTED if accept else Offer.DECLINED
    offer.responded_by = user
    offer.responded_at = timezone.now()
    offer.save()
    record("offer.accepted" if accept else "offer.declined", offer,
           f"Offer {offer.rate} on {req.reference} {'accepted' if accept else 'declined'}",
           data={"reference": req.reference, "rate": str(offer.rate)}, actor=user)
    if not accept:
        post_system(conversation_for_request(req), f"Offer of {offer.rate:,.2f} was declined.")
        return req
    approver = offer.made_by if offer.side == "bureau" else user
    _fix_rate(req, offer.rate, approver)
    return _move(req, ExchangeRequest.APPROVED, user, f"Agreed at {req.agreed_rate:,.2f}",
                 {"rate": str(req.agreed_rate), "local": str(req.local_amount)})


# ─────────────────────────────────────────────────────────────
# MONEY IN, MONEY OUT
# ─────────────────────────────────────────────────────────────

@transaction.atomic
def confirm_funds(req, staff, reference, payment=None, amount=None):
    """Funds arrived. The reference is unique across all requests and payments."""
    from payments.models import Payment

    req = _lock(req)
    if staff.is_active:
        _guard_staff(req, staff)
    reference = (reference or "").strip().upper()
    if not reference:
        raise ExchangeError("Enter the bank, mobile money or receipt reference.")
    if req.status != ExchangeRequest.APPROVED:
        raise ExchangeError("Funds can only be confirmed on an approved request.")
    expected, code = req.customer_pays
    if payment is not None and payment.pk:
        # A gateway charge is in whole shillings (rounded up), so the payment
        # record, not the exact quote, is what the customer was asked to pay.
        expected, code = payment.amount, payment.currency
    if amount is not None:
        try:
            amount = Decimal(str(amount))
        except ArithmeticError:
            raise ExchangeError("Amount is not a number.")
    if amount is not None and amount.quantize(TWO) != Decimal(expected).quantize(TWO):
        raise ExchangeError(f"Amount mismatch: expected {code} {expected:,.2f}.")
    if (ExchangeRequest.objects.filter(funding_reference=reference).exclude(pk=req.pk).exists()
            or Payment.objects.filter(settled_txid=reference).exclude(pk=getattr(payment, "pk", None)).exists()):
        raise ExchangeError("This reference has already been used for another payment.")

    if payment is None:
        payment = req.payments.select_for_update().filter(status=Payment.PENDING).first()
    if payment is None:
        payment = Payment(request=req, gateway=req.funding_method, amount=expected, currency=code,
                          reference=f"{req.reference}-{req.version}", created_by=staff)
    payment.status = Payment.PAID
    payment.settled_txid = reference
    payment.paid_at = timezone.now()
    payment.confirmed_by = staff
    try:
        with transaction.atomic():
            payment.save()
            req.payments.filter(status=Payment.PENDING).exclude(pk=payment.pk).update(status=Payment.CANCELLED)
            req.funding_reference = reference
            req.funds_confirmed_by = staff
            req.funds_confirmed_at = timezone.now()
            treasury.post(code, "in", "customer_in", expected, staff, request=req, reference=reference,
                          note=f"{req.reference} funds received")
            _move(req, ExchangeRequest.FUNDED, staff, f"Funds received, reference {reference}",
                  {"reference": reference, "amount": str(expected), "currency": code,
                   "gateway": payment.gateway})
    except IntegrityError:
        raise ExchangeError("This request or reference was already settled. Nothing was recorded twice.")
    return req


@transaction.atomic
def mark_paid_out(req, staff, reference):
    req = _lock(req)
    _guard_staff(req, staff)
    reference = (reference or "").strip().upper()
    if not reference:
        raise ExchangeError("Enter the wire, mobile money or cash receipt reference.")
    if req.status != ExchangeRequest.FUNDED:
        raise ExchangeError("Only a funded request can be paid out.")
    # Maker checker: on large amounts the person who confirmed the money in
    # may not also release the money out.
    if req.local_amount >= settings.DUAL_CONTROL_THRESHOLD_TZS and req.funds_confirmed_by_id == staff.pk:
        raise ExchangeError("Dual control: a different staff member must release this payout.")
    req.payout_reference = reference
    req.payout_by = staff
    req.payout_at = timezone.now()
    amount, code = req.customer_receives
    try:
        with transaction.atomic():
            treasury.post(code, "out", "payout_out", amount, staff, request=req, reference=reference,
                          note=f"{req.reference} payout")
            _move(req, ExchangeRequest.PAID_OUT, staff, f"Payout reference {reference}", {"reference": reference})
    except treasury.TreasuryError as exc:
        raise ExchangeError(str(exc))
    except IntegrityError:
        raise ExchangeError("This payout reference is already recorded on another request.")
    return req


@transaction.atomic
def complete(req, actor):
    req = _lock(req)
    if actor.pk != req.customer_id:
        _guard_staff(req, actor)
    req.completed_at = timezone.now()
    return _move(req, ExchangeRequest.COMPLETED, actor, "Receipt confirmed")


def expire_stale():
    """Approved requests whose funding window passed. Run every 15 minutes."""
    count = 0
    stale = ExchangeRequest.objects.filter(status=ExchangeRequest.APPROVED, funding_deadline__lt=timezone.now())
    actor = system_user()
    for pk in stale.values_list("pk", flat=True):
        with transaction.atomic():
            req = _lock(pk)
            if req.status != ExchangeRequest.APPROVED or req.payments.filter(status="paid").exists():
                continue
            req.payments.filter(status="pending").update(status="cancelled")
            req.closed_reason = "Funds did not arrive within the funding window."
            _move(req, ExchangeRequest.EXPIRED, actor, req.closed_reason)
            count += 1
    return count
