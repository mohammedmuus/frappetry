import uuid

from django import forms
from django.conf import settings

from accounts.forms import style
from rates.models import Currency

from .models import Beneficiary, ExchangeRequest


class RequestForm(forms.Form):
    direction = forms.ChoiceField(choices=ExchangeRequest.DIRECTION_CHOICES, widget=forms.RadioSelect,
                                  initial=ExchangeRequest.DIR_BUY)
    currency = forms.ModelChoiceField(queryset=Currency.objects.none(), to_field_name="code", empty_label=None)
    amount = forms.DecimalField(max_digits=14, decimal_places=2, min_value=1,
                                widget=forms.NumberInput(attrs={"inputmode": "decimal", "step": "0.01"}))
    funding_method = forms.ChoiceField(choices=ExchangeRequest.FUNDING_CHOICES, label="How you will pay us")
    payout_method = forms.ChoiceField(choices=ExchangeRequest.PAYOUT_CHOICES, label="How you receive")
    beneficiary = forms.ModelChoiceField(queryset=Beneficiary.objects.none(), required=False,
                                         label="Send to", empty_label="Choose a beneficiary")
    purpose = forms.ChoiceField(choices=ExchangeRequest.PURPOSES)
    source_of_funds = forms.CharField(max_length=160, label="Source of funds",
                                      widget=forms.TextInput(attrs={"placeholder": "Salary, business income, savings"}))
    note = forms.CharField(max_length=500, required=False, label="Note for our desk",
                           widget=forms.Textarea(attrs={"rows": 2}))
    idempotency_key = forms.UUIDField(widget=forms.HiddenInput)

    def __init__(self, *args, customer=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["currency"].queryset = Currency.objects.filter(is_active=True).exclude(code=settings.BASE_CURRENCY)
        self.fields["beneficiary"].queryset = Beneficiary.objects.filter(customer=customer, is_active=True)
        if not self.is_bound:
            self.initial["idempotency_key"] = uuid.uuid4()
        style(self)


class OfferForm(forms.Form):
    rate = forms.DecimalField(max_digits=14, decimal_places=4, min_value=0.0001,
                              widget=forms.NumberInput(attrs={"inputmode": "decimal", "step": "0.01"}))
    message = forms.CharField(max_length=300, required=False,
                              widget=forms.TextInput(attrs={"placeholder": "Optional note"}))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        style(self)


class PaidForm(forms.Form):
    reference = forms.CharField(max_length=64, min_length=4, label="Payment reference",
                                widget=forms.TextInput(attrs={"placeholder": "Bank or mobile money reference"}))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        style(self)


class BeneficiaryForm(forms.ModelForm):
    class Meta:
        model = Beneficiary
        fields = ["kind", "label", "currency", "account_name", "bank_name", "account_number", "swift_code",
                  "branch", "mobile_network"]
        labels = {"kind": "Type", "swift_code": "SWIFT or BIC", "mobile_network": "Mobile network",
                  "account_number": "Account or mobile number"}

    def __init__(self, *args, customer=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.customer = customer
        self.fields["currency"].queryset = Currency.objects.filter(is_active=True)
        self.fields["currency"].empty_label = None
        style(self)

    def clean_account_number(self):
        return "".join(self.cleaned_data["account_number"].split()).upper()

    def clean_swift_code(self):
        swift = self.cleaned_data.get("swift_code", "").strip().upper()
        if swift and not (len(swift) in (8, 11) and swift[:6].isalpha() and swift.isalnum()):
            raise forms.ValidationError("A SWIFT code has 8 or 11 letters and digits.")
        return swift

    def clean(self):
        data = super().clean()
        kind = data.get("kind")
        if kind == Beneficiary.KIND_BANK:
            if not data.get("bank_name"):
                self.add_error("bank_name", "Bank name is required.")
            cur = data.get("currency")
            if cur and cur.code != settings.BASE_CURRENCY and not data.get("swift_code"):
                self.add_error("swift_code", "SWIFT code is required for foreign currency accounts.")
            data["mobile_network"] = ""
        elif kind == Beneficiary.KIND_MOBILE:
            number = data.get("account_number", "")
            if number:
                from accounts.models import normalise_phone
                try:
                    e164 = normalise_phone(number)
                    if not e164.startswith("+255"):
                        raise forms.ValidationError("x")
                    data["account_number"] = e164[1:]
                except forms.ValidationError:
                    self.add_error("account_number", "Enter a Tanzanian mobile number, for example 0754 123 456.")
            if not data.get("mobile_network"):
                self.add_error("mobile_network", "Choose the mobile network.")
            cur = data.get("currency")
            if cur and cur.code != settings.BASE_CURRENCY:
                self.add_error("currency", "Mobile money accounts hold TZS only.")
            data["bank_name"] = ""
            data["swift_code"] = ""
        if (self.customer and data.get("account_number") and data.get("currency") and kind and
                Beneficiary.objects.filter(customer=self.customer, kind=kind, is_active=True,
                                           account_number=data["account_number"], currency=data["currency"])
                .exclude(pk=self.instance.pk).exists()):
            raise forms.ValidationError("You already saved this account.")
        return data
