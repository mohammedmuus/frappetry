import json
from decimal import Decimal, InvalidOperation

from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db import IntegrityError, transaction
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from audit.services import record
from desderia.guards import rate_limit
from payments.models import Payment
from payments.services import customer_claims_paid, start_payment
from rates.models import Currency
from support.services import conversation_for_request, mark_read

from . import services
from .forms import BeneficiaryForm, OfferForm, PaidForm, RequestForm
from .models import Beneficiary, ExchangeRequest


def _own_request(request, reference):
    return get_object_or_404(ExchangeRequest.objects.select_related("currency", "beneficiary"),
                             reference=reference, customer=request.user)


@login_required
def dashboard(request):
    reqs = ExchangeRequest.objects.filter(customer=request.user).select_related("currency")
    open_reqs = [r for r in reqs[:50] if r.is_open]
    currencies = Currency.objects.filter(is_active=True).exclude(code=settings.BASE_CURRENCY)
    board = [(c, c.current_rate) for c in currencies]
    return render(request, "exchange_dashboard.html", {
        "open_requests": open_reqs[:5],
        "recent": reqs[:6],
        "board": board,
        "completed_count": reqs.filter(status=ExchangeRequest.COMPLETED).count(),
        "kyc": getattr(request.user, "kyc", None),
    })


@login_required
def request_list(request):
    qs = ExchangeRequest.objects.filter(customer=request.user).select_related("currency")
    status = request.GET.get("status", "")
    if status == "open":
        qs = qs.filter(status__in=ExchangeRequest.OPEN_STATUSES)
    elif status in dict(ExchangeRequest.STATUS_CHOICES):
        qs = qs.filter(status=status)
    page = Paginator(qs, 15).get_page(request.GET.get("page"))
    return render(request, "request_list.html", {"page": page, "status": status,
                                                 "statuses": ExchangeRequest.STATUS_CHOICES})


@login_required
@rate_limit("request_create", limit=10, window=600)
def request_create(request):
    form = RequestForm(request.POST or None, customer=request.user)
    if request.method == "POST" and form.is_valid():
        d = form.cleaned_data
        try:
            req, created = services.create_request(
                request.user, direction=d["direction"], currency_code=d["currency"].code, amount=d["amount"],
                funding_method=d["funding_method"], payout_method=d["payout_method"],
                beneficiary=d.get("beneficiary"), purpose=d["purpose"], source_of_funds=d["source_of_funds"],
                note=d.get("note", ""), idempotency_key=d["idempotency_key"], source="web")
        except services.ExchangeError as exc:
            form.add_error(None, str(exc))
        else:
            if created:
                messages.success(request, f"Request {req.reference} submitted. Rate locked for "
                                          f"{settings.QUOTE_LOCK_MINUTES} minutes while we review it.")
            else:
                messages.info(request, f"Request {req.reference} was already submitted.")
            return redirect("exchange:request_detail", reference=req.reference)
    return render(request, "request_form.html", {
        "form": form,
        "has_beneficiaries": Beneficiary.objects.filter(customer=request.user, is_active=True).exists(),
        "kyc_limit": settings.KYC_UNVERIFIED_LIMIT_USD,
        "funding_json": json.dumps({k: sorted(v) for k, v in services.ALLOWED_FUNDING.items()}),
        "payout_json": json.dumps({k: sorted(v) for k, v in services.ALLOWED_PAYOUT.items()}),
    })


@login_required
@rate_limit("quote", limit=60, window=60)
def quote_json(request):
    """Live converter used by the request form and the home page."""
    currency = Currency.objects.filter(code=request.GET.get("currency", ""), is_active=True).first()
    direction = request.GET.get("direction", "buy")
    try:
        amount = Decimal(request.GET.get("amount", "0"))
    except InvalidOperation:
        amount = Decimal(0)
    if currency is None or direction not in ("buy", "sell") or amount <= 0 or amount > 10_000_000:
        return JsonResponse({"ok": False})
    try:
        q = services.quote(currency, direction, amount)
    except services.ExchangeError as exc:
        return JsonResponse({"ok": False, "error": str(exc)})
    return JsonResponse({"ok": True, "rate": f"{q['rate']:,.2f}", "local": f"{q['local_amount']:,.2f}",
                         "negotiable": q["negotiable"], "min_negotiable": f"{currency.min_negotiable_amount:,.0f}"})


@login_required
def request_detail(request, reference):
    req = _own_request(request, reference)
    conv = conversation_for_request(req)
    mark_read(conv, request.user)
    payment = req.payments.filter(status__in=[Payment.PENDING, Payment.PAID]).first()
    last_failed = req.payments.filter(status=Payment.FAILED).order_by("-created_at").first()
    return render(request, "request_detail.html", {
        "req": req,
        "events": req.events.select_related("actor"),
        "offers": req.offers.select_related("made_by"),
        "pending_offer": req.pending_offer,
        "offer_form": OfferForm(),
        "paid_form": PaidForm(),
        "conv": conv,
        "chat": conv.messages.select_related("sender").order_by("-created_at")[:60][::-1],
        "payment": payment,
        "last_failed": last_failed,
        "bank": settings.BUREAU_BANK_DETAILS,
        "can_negotiate": req.status in (ExchangeRequest.SUBMITTED, ExchangeRequest.NEGOTIATING)
                         and req.foreign_amount >= req.currency.min_negotiable_amount,
    })


@login_required
@rate_limit("status_poll", limit=30, window=60, methods=("GET",))
def request_status_json(request, reference):
    req = _own_request(request, reference)
    return JsonResponse({"status": req.status, "version": req.version})


@login_required
@require_POST
@rate_limit("offer", limit=10, window=600)
def request_offer(request, reference):
    req = _own_request(request, reference)
    form = OfferForm(request.POST)
    if form.is_valid():
        try:
            services.make_offer(req, request.user, form.cleaned_data["rate"], form.cleaned_data["message"])
            messages.success(request, "Your offer was sent to our desk.")
        except services.ExchangeError as exc:
            messages.error(request, str(exc))
    else:
        messages.error(request, "Enter a valid rate.")
    return redirect("exchange:request_detail", reference=reference)


@login_required
@require_POST
@rate_limit("offer_respond", limit=10, window=300)
def request_offer_respond(request, reference, offer_id):
    req = _own_request(request, reference)
    accept = request.POST.get("decision") == "accept"
    try:
        services.respond_offer(req, offer_id, request.user, accept)
        messages.success(request, "Offer accepted. Your rate is fixed." if accept else "Offer declined.")
    except services.ExchangeError as exc:
        messages.error(request, str(exc))
    return redirect("exchange:request_detail", reference=reference)


@login_required
@require_POST
@rate_limit("cancel", limit=10, window=300)
def request_cancel(request, reference):
    req = _own_request(request, reference)
    try:
        services.cancel(req, request.user, request.POST.get("reason", "")[:200])
        messages.success(request, "Request cancelled.")
    except services.ExchangeError as exc:
        messages.error(request, str(exc))
    return redirect("exchange:request_detail", reference=reference)


@login_required
@require_POST
@rate_limit("pay", limit=6, window=300)
def request_pay(request, reference):
    req = _own_request(request, reference)
    try:
        payment, result = start_payment(req, request.user, phone=request.POST.get("phone", ""))
    except services.ExchangeError as exc:
        messages.error(request, str(exc))
        return redirect("exchange:request_detail", reference=reference)
    if result is not None and result.message:
        messages.success(request, result.message)
    return redirect("exchange:request_detail", reference=reference)


@login_required
@require_POST
@rate_limit("paid", limit=6, window=300)
def request_paid(request, reference):
    req = _own_request(request, reference)
    form = PaidForm(request.POST)
    if form.is_valid():
        try:
            customer_claims_paid(req, request.user, form.cleaned_data["reference"])
            messages.success(request, "Thank you. We will confirm your payment shortly.")
        except services.ExchangeError as exc:
            messages.error(request, str(exc))
    else:
        messages.error(request, "Enter the payment reference.")
    return redirect("exchange:request_detail", reference=reference)


@login_required
@require_POST
def request_confirm_receipt(request, reference):
    req = _own_request(request, reference)
    try:
        services.complete(req, request.user)
        messages.success(request, "Thank you for confirming. The request is complete.")
    except services.ExchangeError as exc:
        messages.error(request, str(exc))
    return redirect("exchange:request_detail", reference=reference)


# ─────────────────────────────────────────────────────────────
# BENEFICIARIES
# ─────────────────────────────────────────────────────────────

@login_required
def beneficiary_list(request):
    items = Beneficiary.objects.filter(customer=request.user, is_active=True).select_related("currency")
    return render(request, "beneficiary_list.html", {"items": items})


@login_required
@rate_limit("beneficiary", limit=10, window=600)
def beneficiary_create(request):
    form = BeneficiaryForm(request.POST or None, customer=request.user)
    if request.method == "POST" and form.is_valid():
        try:
            with transaction.atomic():
                ben = form.save(commit=False)
                ben.customer = request.user
                ben.save()
                record("beneficiary.created", ben, f"Beneficiary {ben.label} added",
                       data={"kind": ben.kind, "currency": ben.currency_id, "last4": ben.account_number[-4:]})
        except IntegrityError:
            messages.error(request, "You already saved this account.")
            return redirect("exchange:beneficiary_list")
        messages.success(request, "Beneficiary saved.")
        nxt = request.GET.get("next", "")
        return redirect(nxt if nxt == "/exchange/new/" else "exchange:beneficiary_list")
    return render(request, "beneficiary_form.html", {"form": form})


@login_required
@require_POST
def beneficiary_delete(request, pk):
    ben = get_object_or_404(Beneficiary, pk=pk, customer=request.user, is_active=True)
    # Soft delete: past requests keep pointing at the exact account used.
    Beneficiary.objects.filter(pk=ben.pk).update(is_active=False)
    record("beneficiary.removed", ben, f"Beneficiary {ben.label} removed")
    messages.success(request, "Beneficiary removed.")
    return redirect("exchange:beneficiary_list")
