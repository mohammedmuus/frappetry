from django.contrib import admin

from desderia.admin_mixins import ReadOnlyAdmin

from .models import LedgerEntry, TreasuryAccount


@admin.register(TreasuryAccount)
class TreasuryAccountAdmin(ReadOnlyAdmin, admin.ModelAdmin):
    list_display = ["currency", "balance", "updated_at"]


@admin.register(LedgerEntry)
class LedgerEntryAdmin(ReadOnlyAdmin, admin.ModelAdmin):
    list_display = ["created_at", "account", "kind", "direction", "amount", "balance_after", "request",
                    "reference", "created_by"]
    list_filter = ["account", "kind", "direction"]
    search_fields = ["reference", "note", "request__reference"]
    date_hierarchy = "created_at"
