from datetime import timedelta
from decimal import Decimal, InvalidOperation

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Count, Q, Sum
from django.shortcuts import redirect, render
from django.utils import timezone
from django.utils.dateparse import parse_date

from audit.models import AuditEntry
from audit.services import record
from desderia.guards import rate_limit
from exchange.models import ExchangeRequest
from payments.models import Payment
from rates.models import Currency

from . import excel
from .models import LedgerEntry
from .services import TreasuryError, balances, post

ADJUST_KINDS = {"opening": "in", "topup": "in", "withdrawal": "out", "adjustment_in": "in", "adjustment_out": "out"}


def _is_manager(user):
    return user.is_superuser or user.role in ("manager", "admin")


@login_required
@rate_limit("treasury_adjust", limit=20, window=300)
def balance_view(request):
    if request.method == "POST":
        if not _is_manager(request.user):
            messages.error(request, "Only a manager can record float movements.")
            return redirect("treasury:balances")
        kind = request.POST.get("kind", "")
        code = request.POST.get("currency", "")
        try:
            amount = Decimal(request.POST.get("amount", "").replace(",", ""))
        except InvalidOperation:
            amount = Decimal(0)
        note = request.POST.get("note", "").strip()
        if kind not in ADJUST_KINDS or not Currency.objects.filter(code=code).exists() or amount <= 0 or not note:
            messages.error(request, "Choose a type, currency, a positive amount and a note.")
            return redirect("treasury:balances")
        try:
            post(code, ADJUST_KINDS[kind], kind, amount, request.user, reference=request.POST.get("reference", ""),
                 note=note)
            messages.success(request, "Movement recorded.")
        except TreasuryError as exc:
            messages.error(request, str(exc))
        return redirect("treasury:balances")
    entries = LedgerEntry.objects.select_related("account", "request", "created_by")
    code = request.GET.get("currency", "")
    if code:
        entries = entries.filter(account_id=code)
    page = Paginator(entries, 30).get_page(request.GET.get("page"))
    return render(request, "balances.html", {
        "accounts": balances(), "page": page, "currency": code,
        "currencies": Currency.objects.filter(is_active=True),
        "kinds": [(k, dict(LedgerEntry.KINDS)[k]) for k in ADJUST_KINDS],
        "can_adjust": _is_manager(request.user),
    })


# ─────────────────────────────────────────────────────────────
# REPORTS (manager, admin, auditor)
# ─────────────────────────────────────────────────────────────

def _range(request):
    end = parse_date(request.GET.get("to", "") or "") or timezone.localdate()
    start = parse_date(request.GET.get("from", "") or "") or (end - timedelta(days=30))
    return start, end


@login_required
def reports(request):
    start, end = _range(request)
    qs = ExchangeRequest.objects.filter(created_at__date__gte=start, created_at__date__lte=end)
    summary = (qs.filter(status="completed").values("currency_id", "direction")
               .annotate(n=Count("id"), foreign=Sum("foreign_amount"), local=Sum("local_amount"))
               .order_by("currency_id", "direction"))
    return render(request, "reports.html", {
        "start": start, "end": end, "summary": summary,
        "counts": dict(qs.values_list("status").annotate(n=Count("id"))),
        "accounts": balances(),
    })


@login_required
@rate_limit("report_download", limit=30, window=300, methods=("GET",))
def report_download(request, kind):
    start, end = _range(request)
    scope = f"{start:%d %b %Y} to {end:%d %b %Y}"
    in_range = {"created_at__date__gte": start, "created_at__date__lte": end}
    user = request.user

    if kind == "requests":
        qs = ExchangeRequest.objects.filter(**in_range).select_related("customer", "approved_by", "funds_confirmed_by",
                                                                       "payout_by")
        rows = [(r.reference, r.created_at, r.customer.full_name, r.customer.email, r.customer.phone,
                 r.get_direction_display(), r.currency_id, r.foreign_amount, r.board_rate, r.agreed_rate,
                 r.local_amount, r.get_status_display(), r.get_funding_method_display(),
                 r.get_payout_method_display(), r.funding_reference, r.payout_reference,
                 getattr(r.approved_by, "full_name", ""), getattr(r.funds_confirmed_by, "full_name", ""),
                 getattr(r.payout_by, "full_name", ""), r.get_purpose_display(), r.source_of_funds)
                for r in qs.order_by("created_at")]
        wb = excel.workbook("Exchange requests", scope, [
            "Reference", "Created", "Customer", "Email", "Phone", "Type", "Currency", "Foreign amount",
            "Board rate", "Agreed rate", "TZS amount", "Status", "Funding", "Payout", "Funding ref", "Payout ref",
            "Approved by", "Funds confirmed by", "Paid out by", "Purpose", "Source of funds"],
            rows, money_cols=(7, 8, 9, 10), total_cols=(10,), user=user, personal_data=True)
    elif kind == "payments":
        qs = Payment.objects.filter(**in_range).select_related("request", "confirmed_by")
        rows = [(p.reference, p.request.reference, p.created_at, p.gateway, p.currency, p.amount, p.get_status_display(),
                 p.settled_txid, p.customer_reference, getattr(p.confirmed_by, "full_name", ""), p.paid_at)
                for p in qs.order_by("created_at")]
        wb = excel.workbook("Payments", scope, ["Payment", "Request", "Created", "Gateway", "Currency", "Amount",
                                                "Status", "Settled ref", "Customer ref", "Confirmed by", "Paid at"],
                            rows, money_cols=(5,), user=user)
    elif kind == "ledger":
        qs = LedgerEntry.objects.filter(**in_range).select_related("account", "request", "created_by")
        rows = [(e.created_at, e.account_id, e.get_kind_display(), e.direction.upper(),
                 e.amount if e.direction == "in" else -e.amount, e.balance_after,
                 getattr(e.request, "reference", ""), e.reference, e.note, e.created_by.full_name)
                for e in qs.order_by("created_at", "id")]
        wb = excel.workbook("Treasury ledger", scope, ["Time", "Currency", "Movement", "In or out", "Signed amount",
                                                       "Balance after", "Request", "Reference", "Note", "By"],
                            rows, money_cols=(4, 5), user=user,
                            notes={"Signed amount": "Positive for money in, negative for money out. "
                                                    "Totals mix currencies, so filter by currency before summing."})
    elif kind == "balances":
        rows = [(a.currency_id, a.currency.name, a.balance, a.updated_at) for a in balances()]
        wb = excel.workbook("Currency balances", "Snapshot at export time", ["Currency", "Name", "Balance", "Updated"],
                            rows, money_cols=(2,), user=user)
    elif kind == "summary":
        qs = (ExchangeRequest.objects.filter(status="completed", completed_at__date__gte=start,
                                             completed_at__date__lte=end)
              .values("currency_id", "direction").annotate(n=Count("id"), foreign=Sum("foreign_amount"),
                                                            local=Sum("local_amount")).order_by("currency_id"))
        rows = [(r["currency_id"], "Customer bought" if r["direction"] == "buy" else "Customer sold", r["n"],
                 r["foreign"], r["local"], (r["local"] / r["foreign"]) if r["foreign"] else 0) for r in qs]
        wb = excel.workbook("Completed volume summary", scope, ["Currency", "Side", "Deals", "Foreign volume",
                                                                "TZS volume", "Average rate"],
                            rows, money_cols=(3, 4, 5), total_cols=(4,), user=user)
    elif kind == "audit":
        qs = AuditEntry.objects.filter(at__date__gte=start, at__date__lte=end).order_by("seq")[:50000]
        rows = [(e.seq, e.at, e.actor_label, e.actor_role, e.channel, e.ip_address, e.action,
                 f"{e.object_type} {e.object_id}", e.summary, e.prev_hash, e.hash) for e in qs]
        wb = excel.workbook("Audit trail", scope, ["Seq", "Time", "Actor", "Role", "Channel", "IP", "Action", "Object",
                                                   "Summary", "Previous hash", "Hash"], rows, user=user,
                            personal_data=True, notes={"Integrity": "Each hash covers the entry and the previous "
                                                                    "hash. Run Verify chain in the app to prove it."})
    else:
        messages.error(request, "Unknown report.")
        return redirect("treasury:reports")
    record("export.report", None, f"Report downloaded: {kind} ({scope})", data={"kind": kind, "from": str(start),
                                                                                "to": str(end)})
    return excel.response(wb, kind)
