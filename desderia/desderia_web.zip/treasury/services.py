from decimal import Decimal

from django.db import transaction

from audit.services import record

from .models import LedgerEntry, TreasuryAccount


class TreasuryError(Exception):
    pass


@transaction.atomic
def post(currency_code, direction, kind, amount, actor, request=None, reference="", note=""):
    amount = Decimal(amount)
    if amount <= 0:
        raise TreasuryError("Amount must be positive.")
    TreasuryAccount.objects.get_or_create(currency_id=currency_code)
    account = TreasuryAccount.objects.select_for_update().get(currency_id=currency_code)
    new_balance = account.balance + amount if direction == LedgerEntry.IN else account.balance - amount
    if new_balance < 0:
        raise TreasuryError(f"Insufficient {currency_code} balance ({account.balance:,.2f}). "
                            "Record a float top up first.")
    entry = LedgerEntry.objects.create(account=account, direction=direction, kind=kind, amount=amount,
                                       balance_after=new_balance, request=request, reference=reference[:64],
                                       note=note[:255], created_by=actor)
    TreasuryAccount.objects.filter(pk=account.pk).update(balance=new_balance)
    record(f"ledger.{kind}", entry, f"{currency_code} {'+' if direction == 'in' else '-'}{amount:,.2f} "
                                    f"({entry.get_kind_display()}), balance {new_balance:,.2f}",
           data={"currency": currency_code, "amount": str(amount), "balance": str(new_balance),
                 "reference": reference}, actor=actor if actor.is_active else None)
    return entry


def balances():
    return TreasuryAccount.objects.select_related("currency").order_by("currency__sort_order")
