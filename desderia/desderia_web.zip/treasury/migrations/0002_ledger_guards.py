"""Ledger lines and the email log are append only at the database level."""

from django.db import migrations

TABLES = ["treasury_ledgerentry", "notifications_emaillog"]


def forwards(apps, schema_editor):
    vendor = schema_editor.connection.vendor
    run = schema_editor.execute
    for table in TABLES:
        if vendor == "sqlite":
            for op in ("UPDATE", "DELETE"):
                run(f"CREATE TRIGGER IF NOT EXISTS guard_{table}_{op.lower()} BEFORE {op} ON {table} "
                    f"BEGIN SELECT RAISE(ABORT, '{table} is append only'); END")
        elif vendor == "postgresql":
            run(f"DROP TRIGGER IF EXISTS guard_append_only ON {table}")
            run(f"CREATE TRIGGER guard_append_only BEFORE UPDATE OR DELETE ON {table} "
                f"FOR EACH ROW EXECUTE FUNCTION desderia_refuse('append only')")


def backwards(apps, schema_editor):
    vendor = schema_editor.connection.vendor
    for table in TABLES:
        if vendor == "sqlite":
            for op in ("update", "delete"):
                schema_editor.execute(f"DROP TRIGGER IF EXISTS guard_{table}_{op}")
        elif vendor == "postgresql":
            schema_editor.execute(f"DROP TRIGGER IF EXISTS guard_append_only ON {table}")


class Migration(migrations.Migration):
    dependencies = [
        ("treasury", "0001_initial"),
        ("notifications", "0002_emaillog"),
        ("audit", "0002_database_guards"),
    ]

    operations = [migrations.RunPython(forwards, backwards)]
