"""Brand styled Excel workbooks: ink and gold title band, frozen header,
filters, real SUM formulas, and a notes sheet stating scope and personal data."""

import io
from datetime import date, datetime
from decimal import Decimal

from django.http import HttpResponse
from django.utils import timezone
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

INK = "0C1014"
INK2 = "171D24"
GOLD = "ACA578"
IVORY = "F4F1E6"
STRIPE = "F7F5EE"
FONT = "Arial"
MONEY = '#,##0.00'
thin = Side(style="thin", color="D9D4BF")


def _plain(value):
    if isinstance(value, datetime):
        return timezone.localtime(value).replace(tzinfo=None) if timezone.is_aware(value) else value
    if isinstance(value, Decimal):
        return float(value)
    return value


def workbook(title, subtitle, headers, rows, money_cols=(), total_cols=(), notes=None, user=None,
             personal_data=False, sheet="Report"):
    wb = Workbook()
    ws = wb.active
    ws.title = sheet[:31]
    n = len(headers)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=n)
    c = ws.cell(row=1, column=1, value=f"DESDERIA BUREAU DE CHANGE  |  {title}")
    c.font = Font(name=FONT, size=13, bold=True, color=GOLD)
    c.fill = PatternFill("solid", fgColor=INK)
    c.alignment = Alignment(vertical="center")
    ws.row_dimensions[1].height = 26
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=n)
    stamp = timezone.localtime().strftime("%d %b %Y %H:%M")
    s = ws.cell(row=2, column=1, value=f"{subtitle}  |  {len(rows)} rows  |  exported {stamp}"
                                       + (f" by {user.email}" if user else ""))
    s.font = Font(name=FONT, size=9, color=IVORY)
    s.fill = PatternFill("solid", fgColor=INK2)
    for i, h in enumerate(headers, 1):
        cell = ws.cell(row=3, column=i, value=h)
        cell.font = Font(name=FONT, size=10, bold=True, color=INK)
        cell.fill = PatternFill("solid", fgColor=GOLD)
        cell.alignment = Alignment(wrap_text=True, vertical="center")
        cell.border = Border(bottom=thin)
    widths = [len(h) + 2 for h in headers]
    for r, row in enumerate(rows, 4):
        for i, value in enumerate(row, 1):
            v = _plain(value)
            cell = ws.cell(row=r, column=i, value=v)
            cell.font = Font(name=FONT, size=10)
            cell.border = Border(bottom=thin)
            if (r % 2) == 1:
                cell.fill = PatternFill("solid", fgColor=STRIPE)
            if i - 1 in money_cols:
                cell.number_format = MONEY
            elif isinstance(v, datetime):
                cell.number_format = "dd mmm yyyy hh:mm"
            elif isinstance(v, date):
                cell.number_format = "dd mmm yyyy"
            widths[i - 1] = max(widths[i - 1], min(42, len(str(v if v is not None else "")) + 2))
    last = 3 + len(rows)
    if rows and total_cols:
        t = last + 1
        ws.cell(row=t, column=1, value="Total").font = Font(name=FONT, bold=True)
        for col in total_cols:
            letter = get_column_letter(col + 1)
            cell = ws.cell(row=t, column=col + 1, value=f"=SUM({letter}4:{letter}{last})")
            cell.font = Font(name=FONT, bold=True)
            cell.number_format = MONEY
            cell.border = Border(top=Side(style="medium", color=GOLD))
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A4"
    if rows:
        ws.auto_filter.ref = f"A3:{get_column_letter(n)}{last}"

    info = wb.create_sheet("Notes")
    lines = [("Report", title), ("Scope", subtitle), ("Rows", len(rows)), ("Exported", stamp),
             ("Exported by", user.email if user else "system"),
             ("Personal data", "YES. Contains names, phones or emails. Handle under the privacy policy."
              if personal_data else "No direct personal data.")]
    for k, v in (notes or {}).items():
        lines.append((k, v))
    for r, (k, v) in enumerate(lines, 1):
        info.cell(row=r, column=1, value=k).font = Font(name=FONT, bold=True)
        info.cell(row=r, column=2, value=v).font = Font(name=FONT)
    info.column_dimensions["A"].width = 18
    info.column_dimensions["B"].width = 90
    return wb


def response(wb, slug):
    buf = io.BytesIO()
    wb.save(buf)
    resp = HttpResponse(buf.getvalue(),
                        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    resp["Content-Disposition"] = f'attachment; filename="desderia-{slug}-{timezone.localdate()}.xlsx"'
    return resp
