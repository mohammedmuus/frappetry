from django.urls import path

from . import views

app_name = "treasury"

urlpatterns = [
    path("desk/balances/", views.balance_view, name="balances"),
    path("reports/", views.reports, name="reports"),
    path("reports/<slug:kind>.xlsx", views.report_download, name="download"),
]
