from django.conf import settings
from django.db import models
from django.db.models import Q


class TreasuryAccount(models.Model):
    """Running balance of one currency held by the bureau (till plus bank)."""

    currency = models.OneToOneField("rates.Currency", primary_key=True, on_delete=models.PROTECT,
                                    related_name="treasury")
    balance = models.DecimalField(max_digits=20, decimal_places=2, default=0)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["currency__sort_order"]
        constraints = [models.CheckConstraint(condition=Q(balance__gte=0), name="treasury_never_negative")]

    def __str__(self):
        return f"{self.currency_id} {self.balance:,.2f}"


class LedgerEntry(models.Model):
    """One movement of money. Append only, with the balance after it, so any
    balance at any moment can be proven line by line."""

    IN = "in"
    OUT = "out"
    KINDS = [
        ("customer_in", "Customer funds received"),
        ("payout_out", "Payout to customer"),
        ("opening", "Opening float"),
        ("topup", "Float top up"),
        ("withdrawal", "Float withdrawal"),
        ("adjustment_in", "Adjustment in"),
        ("adjustment_out", "Adjustment out"),
    ]

    account = models.ForeignKey(TreasuryAccount, on_delete=models.PROTECT, related_name="entries")
    direction = models.CharField(max_length=3, choices=[(IN, "In"), (OUT, "Out")])
    kind = models.CharField(max_length=16, choices=KINDS)
    amount = models.DecimalField(max_digits=20, decimal_places=2)
    balance_after = models.DecimalField(max_digits=20, decimal_places=2)
    request = models.ForeignKey("exchange.ExchangeRequest", null=True, blank=True, on_delete=models.PROTECT,
                                related_name="ledger_entries")
    reference = models.CharField(max_length=64, blank=True)
    note = models.CharField(max_length=255, blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["-created_at", "-id"]
        verbose_name_plural = "ledger entries"
        constraints = [
            models.CheckConstraint(condition=Q(amount__gt=0), name="ledger_amount_positive"),
            models.CheckConstraint(condition=Q(balance_after__gte=0), name="ledger_balance_non_negative"),
            # A request can bring money in once and pay it out once. Never twice.
            models.UniqueConstraint(fields=["request", "kind"], condition=Q(request__isnull=False),
                                    name="ledger_one_movement_per_request_kind"),
        ]

    def __str__(self):
        sign = "+" if self.direction == self.IN else "-"
        return f"{self.account_id} {sign}{self.amount:,.2f} {self.get_kind_display()}"
