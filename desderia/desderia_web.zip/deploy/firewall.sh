#!/usr/bin/env bash
# Host firewall: deny everything inbound except SSH (rate limited) and web.
# PostgreSQL and Redis listen on localhost only and are never opened.
set -euo pipefail
ufw --force reset
ufw default deny incoming
ufw default allow outgoing
ufw limit 22/tcp comment "SSH, rate limited"
ufw allow 80/tcp comment "HTTP redirect to HTTPS"
ufw allow 443/tcp comment "HTTPS"
ufw --force enable
ufw status verbose
