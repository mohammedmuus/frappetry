-- Least privilege database roles. Run as the postgres superuser.
-- desderia_owner runs migrations; desderia_app is what the website uses.
CREATE ROLE desderia_owner LOGIN PASSWORD 'change-me-owner';
CREATE ROLE desderia_app LOGIN PASSWORD 'change-me-app' NOSUPERUSER NOCREATEDB NOCREATEROLE;
CREATE DATABASE desderia OWNER desderia_owner;
\c desderia
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO desderia_app;
-- After running migrations as desderia_owner:
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO desderia_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO desderia_app;
-- The app role can never rewrite history, even before the triggers fire.
REVOKE UPDATE, DELETE ON audit_auditentry, treasury_ledgerentry, rates_exchangerate,
    exchange_statusevent, support_message, notifications_emaillog FROM desderia_app;
REVOKE DELETE ON exchange_exchangerequest, payments_payment, payments_gatewayevent, exchange_offer FROM desderia_app;
ALTER ROLE desderia_app SET statement_timeout = '15s';
-- postgresql.conf: listen_addresses = 'localhost', ssl = on
-- pg_hba.conf: hostssl desderia desderia_app 127.0.0.1/32 scram-sha-256
