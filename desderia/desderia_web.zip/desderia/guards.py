"""
Form throttling and duplicate submission guards shared by every app.

Two different problems, two different tools:

- rate_limit: stops flooding. Counts POSTs per user (or per IP when
  anonymous) per scope in a sliding window and answers 429.
- form tokens: stop the same form being saved twice (double click, back
  button resubmit, flaky network retry). Each rendered form carries a
  single use token; the first POST consumes it atomically in the cache,
  any replay of the same token is refused. The database constraints are
  the final net beneath both.
"""

import functools
import secrets
import time

from django.conf import settings
from django.contrib import messages
from django.core.cache import cache
from django.http import JsonResponse
from django.shortcuts import redirect, render

from desderia.middleware import client_ip, security_log


def _actor_key(request):
    user = getattr(request, "user", None)
    if user is not None and user.is_authenticated:
        return f"u{user.pk}"
    return f"ip{client_ip(request)}"


def hit(scope, actor, limit, window):
    """Record one hit. Return True when the actor is over the limit."""
    key = f"rl:{scope}:{actor}"
    now = time.time()
    hits = [t for t in (cache.get(key) or []) if now - t < window]
    if len(hits) >= limit:
        return True
    hits.append(now)
    cache.set(key, hits, window)
    return False


def rate_limit(scope, limit=None, window=None, methods=("POST",)):
    """Per user or per IP throttle for a form view."""
    default_limit, default_window = settings.FORM_RATELIMIT_DEFAULT
    limit = limit or default_limit
    window = window or default_window

    def decorator(view):
        @functools.wraps(view)
        def wrapped(request, *args, **kwargs):
            if request.method in methods and hit(scope, _actor_key(request), limit, window):
                security_log.warning("form_throttled scope=%s actor=%s", scope, _actor_key(request))
                if request.path_info.startswith("/api/") or request.headers.get("Accept", "").startswith("application/json"):
                    return JsonResponse({"detail": "Too many requests. Please slow down."}, status=429)
                response = render(request, "error.html", {
                    "code": 429, "title": "Too many requests",
                    "text": "Please wait a minute and try again."}, status=429)
                response["Retry-After"] = str(window)
                return response
            return view(request, *args, **kwargs)
        return wrapped
    return decorator


# ─────────────────────────────────────────────────────────────
# SINGLE USE FORM TOKENS (no double entries)
# ─────────────────────────────────────────────────────────────

FORM_TOKEN_FIELD = "form_token"
FORM_TOKEN_TTL = 60 * 60 * 2


def issue_form_token(request):
    token = secrets.token_urlsafe(24)
    cache.set(f"ft:{_actor_key(request)}:{token}", 1, FORM_TOKEN_TTL)
    return token


def consume_form_token(request):
    """True exactly once per issued token. cache.delete is the atomic claim."""
    token = request.POST.get(FORM_TOKEN_FIELD, "")
    if not token or len(token) > 64:
        return False
    return bool(cache.delete(f"ft:{_actor_key(request)}:{token}"))


def single_submit(redirect_to=None):
    """Refuse a replayed POST of the same rendered form."""
    def decorator(view):
        @functools.wraps(view)
        def wrapped(request, *args, **kwargs):
            if request.method == "POST" and not consume_form_token(request):
                messages.warning(request, "That form was already submitted. Nothing was saved twice.")
                return redirect(redirect_to or request.path)
            return view(request, *args, **kwargs)
        return wrapped
    return decorator
