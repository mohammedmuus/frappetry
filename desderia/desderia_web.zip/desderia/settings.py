"""
Desderia Bureau De Change - Django settings.

Every secret and host value is read from the environment. Production
refuses to boot without DJANGO_SECRET_KEY, and every transport security
setting is switched on automatically whenever DEBUG is off, so a deploy
cannot forget them.
"""

import os
from pathlib import Path

from django.core.exceptions import ImproperlyConfigured

BASE_DIR = Path(__file__).resolve().parent.parent


# ─────────────────────────────────────────────────────────────
# ENVIRONMENT HELPERS
# ─────────────────────────────────────────────────────────────
# Panel managed hosts write bare names (SECRET_KEY, DEBUG) while this
# project reads DJANGO_ prefixed ones, so both are accepted. Booleans are
# parsed strictly and fall back to the SAFE value, never to True.

def env(*names, default=""):
    for name in names:
        value = os.environ.get(name)
        if value not in (None, ""):
            return value
    return default


def env_bool(*names, default=False):
    raw = str(env(*names, default="")).strip().lower()
    if raw in ("1", "true", "yes", "on"):
        return True
    if raw in ("0", "false", "no", "off"):
        return False
    return default


def env_list(*names, default=""):
    return [item.strip() for item in env(*names, default=default).split(",") if item.strip()]


def _load_dotenv():
    """Read a local .env for development only. Production uses host env vars."""
    path = BASE_DIR / ".env"
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_dotenv()


# ─────────────────────────────────────────────────────────────
# CORE
# ─────────────────────────────────────────────────────────────

DEBUG = env_bool("DJANGO_DEBUG", "DEBUG", default=False)

SECRET_KEY = env("DJANGO_SECRET_KEY", "SECRET_KEY")
if not SECRET_KEY:
    if DEBUG:
        SECRET_KEY = "dev-only-insecure-key-never-use-in-production-0d9f8a7b6c5e"
    else:
        raise ImproperlyConfigured("DJANGO_SECRET_KEY must be set when DEBUG is off")

ALLOWED_HOSTS = env_list("DJANGO_ALLOWED_HOSTS", "ALLOWED_HOSTS",
                         default="localhost,127.0.0.1" if DEBUG else "")
CSRF_TRUSTED_ORIGINS = [
    f"https://{host.lstrip('.')}" for host in ALLOWED_HOSTS if host not in ("localhost", "127.0.0.1")
]

ADMIN_PATH = env("DJANGO_ADMIN_PATH", default="management").strip("/")

SITE_URL = env("DESDERIA_SITE_URL", default="http://localhost:8000").rstrip("/")

INSTALLED_APPS = [
    "desderia.apps.DesderiaAdminConfig",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "django.contrib.humanize",
    "rest_framework",
    "accounts.apps.AccountsConfig",
    "audit.apps.AuditConfig",
    "rates",
    "exchange",
    "payments",
    "desk",
    "api",
    "treasury",
    "support",
    "notifications",
    "pages",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "desderia.middleware.SecurityHeadersMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "desderia.middleware.RequestContextMiddleware",
    "desderia.middleware.LoginRateLimitMiddleware",
    "desderia.middleware.SessionIdleTimeoutMiddleware",
    "desderia.middleware.ModuleAccessMiddleware",
    "desderia.middleware.HtmlMinifyMiddleware",
]

ROOT_URLCONF = "desderia.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "desderia.context_processors.site",
            ],
        },
    },
]

WSGI_APPLICATION = "desderia.wsgi.application"


# ─────────────────────────────────────────────────────────────
# DATABASE (PostgreSQL in production, SQLite for local work)
# ─────────────────────────────────────────────────────────────

if env("DB_NAME"):
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": env("DB_NAME"),
            "USER": env("DB_USER"),
            "PASSWORD": env("DB_PASSWORD"),
            "HOST": env("DB_HOST", default="127.0.0.1"),
            "PORT": env("DB_PORT", default="5432"),
            "CONN_MAX_AGE": 60,
            "CONN_HEALTH_CHECKS": True,
            # Database level guard: a runaway query cannot hold locks forever.
            "OPTIONS": {
                "sslmode": env("DB_SSLMODE", default="require" if not DEBUG else "prefer"),
                "options": "-c statement_timeout=15000 -c lock_timeout=5000",
            },
        }
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": BASE_DIR / "db.sqlite3",
        }
    }

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# Login throttling and OTP counters live here. LocMemCache is per worker,
# so limits are approximate until REDIS_URL points at a shared Redis.
if env("REDIS_URL"):
    CACHES = {
        "default": {
            "BACKEND": "django.core.cache.backends.redis.RedisCache",
            "LOCATION": env("REDIS_URL"),
        }
    }
else:
    CACHES = {"default": {"BACKEND": "django.core.cache.backends.locmem.LocMemCache"}}


# ─────────────────────────────────────────────────────────────
# AUTHENTICATION
# ─────────────────────────────────────────────────────────────

AUTH_USER_MODEL = "accounts.User"
AUTHENTICATION_BACKENDS = ["accounts.backends.EmailBackend"]

PASSWORD_HASHERS = [
    "django.contrib.auth.hashers.Argon2PasswordHasher",
    "django.contrib.auth.hashers.PBKDF2PasswordHasher",
]

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator", "OPTIONS": {"min_length": 10}},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LOGIN_URL = "/auth/login/"
LOGIN_REDIRECT_URL = "/exchange/"
LOGOUT_REDIRECT_URL = "/auth/login/"

LOGIN_RATELIMIT_USER_ATTEMPTS = 5
LOGIN_RATELIMIT_IP_ATTEMPTS = 10
LOGIN_RATELIMIT_WINDOW = 300
LOGIN_RATELIMIT_LOCKOUT = 300

# Generic form throttle (register, quote, offers, uploads, contact)
FORM_RATELIMIT_DEFAULT = (20, 60)   # 20 posts per 60 seconds per user or IP

# One time codes (email verification, phone verification, login step two)
OTP_TTL_SECONDS = 600
OTP_MAX_ATTEMPTS = 5
OTP_RESEND_COOLDOWN = 60

SESSION_COOKIE_AGE = 60 * 60 * 8
SESSION_IDLE_TIMEOUT = int(env("SESSION_IDLE_TIMEOUT", default="1800"))
SESSION_EXPIRE_AT_BROWSER_CLOSE = True
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = "Lax"
CSRF_COOKIE_SAMESITE = "Lax"

# Mobile API tokens expire. DRF stock tokens never do, which is a hole.
API_TOKEN_TTL_HOURS = int(env("API_TOKEN_TTL_HOURS", default="72"))


# ─────────────────────────────────────────────────────────────
# BUSINESS RULES
# ─────────────────────────────────────────────────────────────

BASE_CURRENCY = "TZS"
QUOTE_LOCK_MINUTES = 10
# Above this foreign amount (in USD equivalent) KYC must be approved.
KYC_UNVERIFIED_LIMIT_USD = 1000
# Payouts at or above this local amount need a second staff member.
DUAL_CONTROL_THRESHOLD_TZS = int(env("DUAL_CONTROL_THRESHOLD_TZS", default="5000000"))
# Requests not funded within this window expire.
FUNDING_WINDOW_HOURS = 24


# ─────────────────────────────────────────────────────────────
# PAYMENTS (CashPay adapter, disabled until real credentials exist)
# ─────────────────────────────────────────────────────────────

CASHPAY_API_URL = env("CASHPAY_API_URL")
CASHPAY_MERCHANT_ID = env("CASHPAY_MERCHANT_ID")
CASHPAY_API_KEY = env("CASHPAY_API_KEY")
CASHPAY_WEBHOOK_SECRET = env("CASHPAY_WEBHOOK_SECRET")

BUREAU_BANK_DETAILS = {
    "bank": env("BUREAU_BANK_NAME", default="Set BUREAU_BANK_NAME"),
    "account_name": env("BUREAU_ACCOUNT_NAME", default="Desderia Bureau De Change Ltd"),
    "account_number_tzs": env("BUREAU_ACCOUNT_TZS", default="Set BUREAU_ACCOUNT_TZS"),
    "account_number_usd": env("BUREAU_ACCOUNT_USD", default="Set BUREAU_ACCOUNT_USD"),
    "swift": env("BUREAU_SWIFT", default="Set BUREAU_SWIFT"),
}


# ─────────────────────────────────────────────────────────────
# EMAIL AND SMS
# ─────────────────────────────────────────────────────────────

# Every email passes through the logging wrapper, which records it in EmailLog.
EMAIL_BACKEND = "notifications.mail.LoggingEmailBackend"
REAL_EMAIL_BACKEND = env("EMAIL_BACKEND", default="django.core.mail.backends.console.EmailBackend")
EMAIL_HOST = env("EMAIL_HOST")
EMAIL_PORT = int(env("EMAIL_PORT", default="587"))
EMAIL_HOST_USER = env("EMAIL_HOST_USER")
EMAIL_HOST_PASSWORD = env("EMAIL_HOST_PASSWORD")
EMAIL_USE_TLS = env_bool("EMAIL_USE_TLS", default=True)
BUREAU_DESK_EMAIL = env("BUREAU_DESK_EMAIL")
DEFAULT_FROM_EMAIL = env("DEFAULT_FROM_EMAIL", default="Desderia <no-reply@desderia.co.tz>")

# "console" prints codes to the log. Replace with a provider class path.
SMS_BACKEND = env("SMS_BACKEND", default="accounts.sms.ConsoleSmsBackend")
SMS_API_URL = env("SMS_API_URL")
SMS_API_KEY = env("SMS_API_KEY")
SMS_SENDER_ID = env("SMS_SENDER_ID", default="DESDERIA")


# ─────────────────────────────────────────────────────────────
# REST FRAMEWORK (mobile app)
# ─────────────────────────────────────────────────────────────

REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": ["api.authentication.ExpiringTokenAuthentication"],
    "DEFAULT_PERMISSION_CLASSES": ["rest_framework.permissions.IsAuthenticated"],
    "DEFAULT_RENDERER_CLASSES": ["rest_framework.renderers.JSONRenderer"],
    "DEFAULT_PARSER_CLASSES": [
        "rest_framework.parsers.JSONParser",
        "rest_framework.parsers.MultiPartParser",
    ],
    "DEFAULT_THROTTLE_CLASSES": [
        "rest_framework.throttling.AnonRateThrottle",
        "rest_framework.throttling.UserRateThrottle",
    ],
    "DEFAULT_THROTTLE_RATES": {
        "anon": "30/min",
        "user": "120/min",
        "auth": "10/min",
        "otp": "6/min",
        "write": "30/min",
    },
    "DEFAULT_PAGINATION_CLASS": "rest_framework.pagination.PageNumberPagination",
    "PAGE_SIZE": 20,
    "EXCEPTION_HANDLER": "api.views.exception_handler",
}


# ─────────────────────────────────────────────────────────────
# I18N, STATIC, MEDIA
# ─────────────────────────────────────────────────────────────

LANGUAGE_CODE = "en-gb"
TIME_ZONE = "Africa/Dar_es_Salaam"
USE_I18N = True
USE_TZ = True

# CDN: point DESDERIA_CDN_URL at a pull zone (Cloudflare, BunnyCDN,
# CloudFront) whose origin is this site's /static/. Hashed file names from
# the manifest storage make every asset safely cacheable for a year.
CDN_URL = env("DESDERIA_CDN_URL").rstrip("/")
STATIC_URL = f"{CDN_URL}/static/" if CDN_URL else "/static/"
WHITENOISE_MAX_AGE = 31536000 if not DEBUG else 0
STATIC_ROOT = BASE_DIR / "staticfiles"
STATICFILES_DIRS = [BASE_DIR / "static"]
STORAGES = {
    "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
    "staticfiles": {
        "BACKEND": "whitenoise.storage.CompressedManifestStaticFilesStorage"
        if not DEBUG else "django.contrib.staticfiles.storage.StaticFilesStorage",
    },
}

# KYC documents are private. They are never served from a public URL;
# a view checks ownership and streams the file.
MEDIA_ROOT = BASE_DIR / "private_media"
MEDIA_URL = "/private-media-not-public/"
FILE_UPLOAD_MAX_MEMORY_SIZE = 5 * 1024 * 1024
DATA_UPLOAD_MAX_MEMORY_SIZE = 6 * 1024 * 1024
KYC_MAX_UPLOAD_BYTES = 5 * 1024 * 1024


# ─────────────────────────────────────────────────────────────
# TRANSPORT SECURITY (automatic whenever DEBUG is off)
# ─────────────────────────────────────────────────────────────

X_FRAME_OPTIONS = "DENY"
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_REFERRER_POLICY = "strict-origin-when-cross-origin"
SECURE_CROSS_ORIGIN_OPENER_POLICY = "same-origin"

if not DEBUG:
    SECURE_SSL_REDIRECT = env_bool("SECURE_SSL_REDIRECT", default=True)
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SESSION_COOKIE_NAME = "__Secure-dsd-session"
    CSRF_COOKIE_NAME = "__Secure-dsd-csrf"
    SECURE_HSTS_SECONDS = 31536000
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_HSTS_PRELOAD = True


# ─────────────────────────────────────────────────────────────
# LOGGING
# ─────────────────────────────────────────────────────────────

LOG_DIR = Path(env("DESDERIA_LOG_DIR", default=str(BASE_DIR / "logs")))
LOG_DIR.mkdir(parents=True, exist_ok=True)

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "plain": {"format": "%(asctime)s %(levelname)s %(name)s %(message)s"},
    },
    "handlers": {
        "console": {"class": "logging.StreamHandler", "formatter": "plain"},
        "security_file": {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": LOG_DIR / "security.log",
            "maxBytes": 5 * 1024 * 1024,
            "backupCount": 10,
            "formatter": "plain",
        },
    },
    "loggers": {
        "django.security": {"handlers": ["console", "security_file"], "level": "WARNING"},
        "desderia.security": {"handlers": ["console", "security_file"], "level": "INFO", "propagate": False},
        "desderia": {"handlers": ["console"], "level": "INFO"},
    },
}
