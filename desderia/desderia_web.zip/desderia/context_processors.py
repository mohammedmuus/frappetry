from django.conf import settings


def site(request):
    user = getattr(request, "user", None)
    unread = 0
    if user is not None and user.is_authenticated:
        unread = user.notifications.filter(read_at__isnull=True).count()
    return {
        "csp_nonce": getattr(request, "csp_nonce", ""),
        "is_debug": settings.DEBUG,
        "unread_notifications": unread,
        "asset_version": "1",
    }
