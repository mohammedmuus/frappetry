from django.contrib.admin.apps import AdminConfig


class DesderiaAdminConfig(AdminConfig):
    default_site = "desderia.admin_site.DesderiaAdminSite"
