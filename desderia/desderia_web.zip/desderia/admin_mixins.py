class ReadOnlyAdmin:
    """Records that only the business services may write (money, audit, history)."""

    def has_add_permission(self, request, obj=None):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


class SuperuserOnlyAdmin:
    """Any staff holding change_user could otherwise tick is_superuser on themselves."""

    def has_module_permission(self, request):
        return request.user.is_superuser

    def has_view_permission(self, request, obj=None):
        return request.user.is_superuser

    def has_add_permission(self, request, obj=None):
        return request.user.is_superuser

    def has_change_permission(self, request, obj=None):
        return request.user.is_superuser

    def has_delete_permission(self, request, obj=None):
        return False


class NoDeleteAdmin:
    def has_delete_permission(self, request, obj=None):
        return False
