from django.conf import settings
from django.contrib import admin
from django.urls import include, path

from pages import views as page_views


urlpatterns = [
    path(f"{settings.ADMIN_PATH}/", admin.site.urls),
    path("", include(("pages.urls", "pages"), namespace="pages")),
    path("", include(("accounts.urls", "accounts"), namespace="accounts")),
    path("", include(("support.urls", "support"), namespace="support")),
    path("", include(("treasury.urls", "treasury"), namespace="treasury")),
    path("rates/", include(("rates.urls", "rates"), namespace="rates")),
    path("exchange/", include(("exchange.urls", "exchange"), namespace="exchange")),
    path("desk/", include(("desk.urls", "desk"), namespace="desk")),
    path("audit/", include(("audit.urls", "audit"), namespace="audit")),
    path("payments/", include(("payments.urls", "payments"), namespace="payments")),
    path("notifications/", include(("notifications.urls", "notifications"), namespace="notifications")),
    path("api/v1/", include(("api.urls", "api"), namespace="api")),
    path("robots.txt", page_views.robots),
    path("manifest.webmanifest", page_views.manifest),
]

handler404 = "desderia.errors.not_found"
handler500 = "desderia.errors.server_error"
handler403 = "desderia.errors.forbidden"
