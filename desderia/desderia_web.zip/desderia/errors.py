from django.shortcuts import render


def not_found(request, exception=None):
    return render(request, "error.html", {"code": 404, "title": "Page not found",
                                          "text": "The page you asked for does not exist."}, status=404)


def forbidden(request, exception=None):
    return render(request, "error.html", {"code": 403, "title": "Not allowed",
                                          "text": "You do not have access to this page."}, status=403)


def server_error(request):
    return render(request, "error.html", {"code": 500, "title": "Something went wrong",
                                          "text": "Our team has been notified. Please try again shortly."}, status=500)
