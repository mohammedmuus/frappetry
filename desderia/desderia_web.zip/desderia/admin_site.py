from urllib.parse import urlencode

from django.contrib import admin
from django.shortcuts import redirect


class DesderiaAdminSite(admin.AdminSite):
    """Management portal at /management/ in the Desderia theme.

    Its own password form is never used: sign in goes through the main
    two step login (password plus one time code, rate limited), then
    returns here.
    """

    site_header = "Desderia management"
    site_title = "Desderia management"
    index_title = "Everything in one place"
    enable_nav_sidebar = True

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.add_action(export_excel, "export_excel")

    def has_permission(self, request):
        user = request.user
        return bool(user.is_active and user.is_staff and (user.is_superuser or user.role == "admin"))

    def login(self, request, extra_context=None):
        if request.user.is_authenticated and not self.has_permission(request):
            return redirect(request.user.home_url)
        nxt = request.GET.get("next") or request.path.rsplit("login/", 1)[0]
        return redirect("/auth/login/?" + urlencode({"next": nxt}))


SECRET_FIELDS = {"password", "key_hash", "code_hash"}


def export_excel(modeladmin, request, queryset):
    """Site wide action: download exactly the selected rows, every field."""
    from audit.services import record
    from treasury import excel

    model = queryset.model
    fields = [f for f in model._meta.concrete_fields if f.name not in SECRET_FIELDS]
    headers = [str(f.verbose_name).capitalize() for f in fields]
    rows = []
    for obj in queryset[:20000]:
        row = []
        for f in fields:
            value = getattr(obj, f.attname)
            if f.choices:
                value = getattr(obj, f"get_{f.name}_display")()
            elif value is not None and not isinstance(value, (int, float, str, bool)) and not hasattr(value, "year") \
                    and not hasattr(value, "as_tuple"):
                value = str(value)
            row.append(value)
        rows.append(row)
    title = str(model._meta.verbose_name_plural).capitalize()
    wb = excel.workbook(title, "Rows selected in management", headers, rows, user=request.user, personal_data=True)
    record("export.admin", None, f"Management export: {title} ({len(rows)} rows)",
           data={"model": model._meta.label})
    return excel.response(wb, model._meta.model_name)


export_excel.short_description = "Download selected as Excel"
