"""
Request pipeline guards for Desderia.

Order in settings.MIDDLEWARE matters: everything that reads request.user
sits after AuthenticationMiddleware and MessageMiddleware.
"""

import json
import logging
import os
import re
import secrets
import threading
import time

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import logout as auth_logout
from django.contrib.auth.signals import user_logged_in, user_login_failed
from django.contrib.auth.views import redirect_to_login
from django.core.cache import cache
from django.dispatch import receiver
from django.http import JsonResponse
from django.shortcuts import redirect

security_log = logging.getLogger("desderia.security")

_local = threading.local()

# The admin lives on a non default path (DJANGO_ADMIN_PATH) to cut scanner noise.
ADMIN_PREFIX = "/" + os.environ.get("DJANGO_ADMIN_PATH", "management").strip("/") + "/"


def client_ip(request):
    """First X-Forwarded-For hop when behind the proxy, else REMOTE_ADDR."""
    if request is None:
        return ""
    forwarded = request.META.get("HTTP_X_FORWARDED_FOR", "")
    if forwarded:
        return forwarded.split(",")[0].strip()[:45]
    return request.META.get("REMOTE_ADDR", "")[:45]


def current_request():
    return getattr(_local, "request", None)


# ─────────────────────────────────────────────────────────────
# REQUEST CONTEXT (feeds the audit trail with actor, IP and agent)
# ─────────────────────────────────────────────────────────────

class RequestContextMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        _local.request = request
        try:
            return self.get_response(request)
        finally:
            _local.request = None


# ─────────────────────────────────────────────────────────────
# SECURITY HEADERS AND STRICT NONCE CSP
# ─────────────────────────────────────────────────────────────
# No inline event handlers exist anywhere in the templates; every behaviour
# lives in static/js/app.js using delegated listeners on data- attributes,
# so script-src never needs 'unsafe-inline'.

class SecurityHeadersMiddleware:
    PRIVATE_PREFIXES = ("/exchange/", "/desk/", "/audit/", "/account/", "/auth/", "/chat/",
                        "/notifications/", "/reports/", ADMIN_PREFIX, "/api/", "/payments/")

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        request.csp_nonce = secrets.token_urlsafe(16)
        response = self.get_response(request)
        path = request.path_info

        cdn = getattr(settings, "CDN_URL", "")
        asset_src = f"'self' {cdn}".strip()
        if not path.startswith(ADMIN_PREFIX):
            nonce = request.csp_nonce
            response["Content-Security-Policy"] = "; ".join([
                "default-src 'self'",
                f"script-src {asset_src} 'nonce-{nonce}'",
                f"style-src {asset_src}",
                f"img-src {asset_src} data:",
                f"font-src {asset_src}",
                "connect-src 'self'",
                "object-src 'none'",
                "frame-src 'none'",
                "frame-ancestors 'none'",
                "form-action 'self'",
                "base-uri 'self'",
                "manifest-src 'self'",
                "upgrade-insecure-requests" if not settings.DEBUG else "block-all-mixed-content",
            ])
        response["Permissions-Policy"] = (
            "camera=(), microphone=(), geolocation=(), payment=(), usb=(), "
            "accelerometer=(), gyroscope=(), magnetometer=(), interest-cohort=()"
        )
        response["Cross-Origin-Opener-Policy"] = "same-origin"
        response["Cross-Origin-Resource-Policy"] = "same-site"
        response["X-Permitted-Cross-Domain-Policies"] = "none"
        if path.startswith(self.PRIVATE_PREFIXES):
            response["X-Robots-Tag"] = "noindex, nofollow"
            # Money pages must never be served from a shared or back cache.
            response["Cache-Control"] = "no-store, private"
        return response


# ─────────────────────────────────────────────────────────────
# LOGIN RATE LIMITING (web and API, driven by auth signals)
# ─────────────────────────────────────────────────────────────

LOGIN_PATHS = ("/auth/login/", "/api/v1/auth/login/")


def _fail_keys(username, ip):
    keys = []
    if username:
        keys.append(f"loginfail:user:{str(username).strip().lower()}")
    if ip:
        keys.append(f"loginfail:ip:{ip}")
    return keys


@receiver(user_login_failed)
def _record_login_failure(sender, credentials, request=None, **kwargs):
    window = settings.LOGIN_RATELIMIT_WINDOW
    username = (credentials or {}).get("username", "") or (credentials or {}).get("email", "")
    ip = client_ip(request)
    now = time.time()
    for key in _fail_keys(username, ip):
        attempts = [t for t in (cache.get(key) or []) if now - t < window]
        attempts.append(now)
        cache.set(key, attempts, window + settings.LOGIN_RATELIMIT_LOCKOUT)
    security_log.warning("login_failed user=%s ip=%s", username, ip)


@receiver(user_logged_in)
def _clear_login_failures(sender, request, user, **kwargs):
    for key in _fail_keys(user.get_username(), client_ip(request)):
        cache.delete(key)


def login_locked_out(username, ip):
    """Return seconds left on a lockout, or 0 when the attempt may proceed."""
    window = settings.LOGIN_RATELIMIT_WINDOW
    lockout = settings.LOGIN_RATELIMIT_LOCKOUT
    now = time.time()
    checks = []
    if username:
        checks.append((f"loginfail:user:{username.strip().lower()}", settings.LOGIN_RATELIMIT_USER_ATTEMPTS))
    if ip:
        checks.append((f"loginfail:ip:{ip}", settings.LOGIN_RATELIMIT_IP_ATTEMPTS))
    for key, limit in checks:
        attempts = [t for t in (cache.get(key) or []) if now - t < window + lockout]
        if len(attempts) >= limit:
            wait = int(lockout - (now - max(attempts)))
            if wait > 0:
                return wait
    return 0


class LoginRateLimitMiddleware:
    """Blocks login POSTs after repeated failures. GET of the page stays open."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.method == "POST" and request.path_info in LOGIN_PATHS:
            username = self._username(request)
            wait = login_locked_out(username, client_ip(request))
            if wait:
                security_log.warning("login_locked user=%s ip=%s", username, client_ip(request))
                return self._lockout_response(request, wait)
        return self.get_response(request)

    @staticmethod
    def _username(request):
        if request.path_info.startswith("/api/"):
            try:
                body = json.loads(request.body or b"{}")
                return str(body.get("email", ""))[:254]
            except (ValueError, UnicodeDecodeError):
                return ""
        return request.POST.get("username", "")[:254]

    @staticmethod
    def _lockout_response(request, wait):
        if request.path_info.startswith("/api/"):
            return JsonResponse(
                {"detail": "Too many failed login attempts. Try again later.", "retry_after": wait},
                status=429,
            )
        from django.shortcuts import render
        minutes = max(1, (wait + 59) // 60)
        response = render(request, "error.html", {
            "code": 429, "title": "Too many failed sign in attempts",
            "text": f"Access is locked for about {minutes} minute(s). Please try again later."}, status=429)
        response["Retry-After"] = str(wait)
        return response


# ─────────────────────────────────────────────────────────────
# IDLE SESSION TIMEOUT
# ─────────────────────────────────────────────────────────────

class SessionIdleTimeoutMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        user = getattr(request, "user", None)
        if user is not None and user.is_authenticated:
            now = int(time.time())
            last = request.session.get("last_seen", now)
            if now - last > settings.SESSION_IDLE_TIMEOUT:
                auth_logout(request)
                messages.info(request, "You were signed out after a period of inactivity.")
                return redirect_to_login(request.get_full_path())
            if now - last > 30:
                request.session["last_seen"] = now
        return self.get_response(request)


# ─────────────────────────────────────────────────────────────
# MODULE ACCESS (server side authorization and login wall)
# ─────────────────────────────────────────────────────────────
# Hiding a menu link is not authorization. Every protected prefix is
# checked here on every request, so a typed URL is stopped exactly like a
# hidden link, and a view that forgot @login_required is still covered.

class ModuleAccessMiddleware:
    STAFF = {"teller", "manager", "admin"}
    # Most specific prefixes first. None means any signed in user.
    PROTECTED = (
        ("/desk/rates/", {"manager", "admin"}),
        ("/desk/", {"teller", "manager", "admin"}),
        ("/audit/", {"auditor", "manager", "admin"}),
        ("/reports/", {"auditor", "manager", "admin"}),
        ("/exchange/", {"customer"}),
        ("/account/", None),
        ("/chat/", None),
        ("/notifications/", None),
    )
    # Customers must finish email and phone verification before trading.
    VERIFIED_ONLY = ("/exchange/",)

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        denial = self.deny_if_blocked(request)
        if denial is not None:
            return denial
        return self.get_response(request)

    def deny_if_blocked(self, request):
        path = request.path_info
        rule = next((r for r in self.PROTECTED if path.startswith(r[0])), None)
        if rule is None:
            return None

        user = getattr(request, "user", None)
        if user is None or not user.is_authenticated:
            return redirect_to_login(request.get_full_path())

        if not user.is_active:
            auth_logout(request)
            return redirect_to_login(request.get_full_path())

        if path.startswith(self.VERIFIED_ONLY) and not user.is_fully_verified:
            messages.info(request, "Please verify your email and phone number to continue.")
            return redirect("accounts:verify")

        prefix, roles = rule
        if roles is None or user.is_superuser or user.role in roles:
            return None

        home = user.home_url
        if path.rstrip("/") == home.rstrip("/"):
            return None
        security_log.warning("access_denied user=%s path=%s", user.email, path)
        messages.error(request, "You are not allowed to visit this page. Please contact the administrator.")
        return redirect(home)


# ─────────────────────────────────────────────────────────────
# HTML MINIFICATION (fast pages, smaller transfers)
# ─────────────────────────────────────────────────────────────

_PRESERVE = re.compile(r"(<(pre|textarea|script|style)\b.*?</\2>)", re.S | re.I)
_COMMENT = re.compile(r"<!--(?!\[if).*?-->", re.S)
_BETWEEN = re.compile(r">\s{2,}<")
_SPACES = re.compile(r"[ \t]{2,}")
_LINES = re.compile(r"\n\s*\n+")


def minify_html(html):
    parts = _PRESERVE.split(html)
    out = []
    i = 0
    while i < len(parts):
        chunk = parts[i]
        if i % 3 == 0:
            chunk = _COMMENT.sub("", chunk)
            chunk = _BETWEEN.sub("> <", chunk)
            chunk = _SPACES.sub(" ", chunk)
            chunk = _LINES.sub("\n", chunk)
            out.append(chunk)
            i += 1
        else:
            out.append(chunk)
            i += 2
    return "".join(out)


class HtmlMinifyMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        if (
            response.status_code == 200
            and not getattr(response, "streaming", False)
            and response.get("Content-Type", "").startswith("text/html")
            and not request.path_info.startswith(ADMIN_PREFIX)
        ):
            response.content = minify_html(response.content.decode("utf-8")).encode("utf-8")
            response["Content-Length"] = str(len(response.content))
        return response
