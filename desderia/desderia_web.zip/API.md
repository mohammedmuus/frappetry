# How the mobile app connects to the server

The Flutter app is a client of the Django REST API under `/api/v1/`. There is no separate backend for mobile: both apps share one database, one rule engine (`exchange/services.py`), one audit trail and one notification system. A request made on the phone appears on the desk instantly, and a desk action appears in the app on the next refresh.

```
 Flutter app  ──HTTPS + Bearer token──►  Nginx  ──►  Django /api/v1/  ──►  services  ──►  PostgreSQL
 (Android, iOS)                                        same rules as the web site
```

## 1. Point the app at the server

The base URL is compiled into the app:

```bash
# Production build
flutter build apk --release --dart-define=API_BASE_URL=https://desderia.co.tz/api/v1
flutter build ipa --release --dart-define=API_BASE_URL=https://desderia.co.tz/api/v1

# Development against your laptop
python manage.py runserver 0.0.0.0:8000
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:8000/api/v1    # Android emulator
flutter run --dart-define=API_BASE_URL=http://127.0.0.1:8000/api/v1   # iOS simulator
```

Release builds refuse an `http://` URL. Android release builds also block cleartext traffic at the OS level. For a phone on your Wi-Fi during development use your laptop's LAN IP and add it to `DJANGO_ALLOWED_HOSTS`.

No CORS setup is needed: native apps are not browsers.

## 2. Authentication

Tokens are random 40 byte keys. The server stores only a SHA-256 hash. They expire after `API_TOKEN_TTL_HOURS` (72 by default), are revoked on sign out and on password change, and can be revoked per device from the web account page or the management portal. The app keeps the token in the iOS Keychain or Android Keystore.

Send it on every call:

```
Authorization: Bearer <token>
```

### Sign in (two steps)

```
POST /api/v1/auth/login/            {"email", "password", "channel": "email"|"sms", "device_name"}
  -> {"otp_required": true, "challenge": "...", "channel": "email"}
POST /api/v1/auth/login/verify/     {"challenge", "code", "device_name"}
  -> {"token": "...", "user": {...}}
POST /api/v1/auth/login/resend/     {"challenge"}
```

The challenge is signed and valid for 10 minutes. If the account email is not yet verified, step one returns `{"token", "verification_required": true}` so the app can show the verification screen.

### Register and verify

```
POST /api/v1/auth/register/   {"full_name", "email", "phone", "password", "accept_terms": true, "device_name"}
  -> 201 {"token", "user"}     (codes are sent to the email and by SMS)
POST /api/v1/auth/verify/     {"which": "email"|"phone", "code"}      -> {"user"}
POST /api/v1/auth/verify/     {"which": "email"|"phone", "resend": true}
POST /api/v1/auth/password-reset/   {"email"}   (always the same answer, no account probing)
POST /api/v1/auth/logout/
```

## 3. Endpoints

| Method and path | Purpose |
|---|---|
| `GET me/`, `PATCH me/` | Profile, verification flags, KYC status, unread count. PATCH accepts `full_name`, `notify_email` |
| `GET rates/` | Live board (public) |
| `GET options/` | Currencies, allowed funding and payout methods per direction, labels, purposes, networks, ID types, limits |
| `GET quote/?currency=USD&direction=buy&amount=1000` | Live quote |
| `GET requests/` (`?status=open`) | The customer's requests |
| `POST requests/` | New request. Body below |
| `GET requests/<ref>/` | Full detail with offers, timeline, payment (`status`, `payer_phone`, `pushed_at`, `failure_reason`), bank details, chat id |
| `POST requests/<ref>/offer/` | `{"rate", "message"}` propose a rate |
| `POST requests/<ref>/respond/` | `{"offer_id", "accept": true|false}` answer a Desderia offer |
| `POST requests/<ref>/pay/` | `{"phone"}` CashPay: send a USSD prompt to that M-Pesa, Mixx by Yas or Airtel Money number (defaults to the account phone). Bank and cash: open the payment record. Poll the request detail to see it become `funded` |
| `POST requests/<ref>/paid/` | `{"reference"}` customer reports a bank transfer reference (not used for CashPay, which confirms itself) |
| `POST requests/<ref>/cancel/` | `{"reason"}` |
| `POST requests/<ref>/received/` | Customer confirms the payout arrived |
| `GET, POST beneficiaries/`, `DELETE beneficiaries/<id>/` | Saved payout accounts |
| `GET, POST conversations/` | Support threads. POST `{"subject", "body"}` |
| `GET conversations/<id>/messages/?after=<iso>` | New messages since a time (the app polls every 4 seconds while open) |
| `POST conversations/<id>/messages/` | `{"body", "client_id"}` |
| `GET notifications/`, `POST notifications/` | List, or mark all read |
| `GET kyc/`, `POST kyc/` (multipart) | Identity documents, field `id_document` is the photo |
| `GET health/` | Liveness check |

New request body:

```json
{
  "direction": "buy",
  "currency": "USD",
  "amount": "1000.00",
  "funding_method": "bank_transfer",
  "payout_method": "bank_wire",
  "beneficiary": "uuid-or-null",
  "purpose": "travel",
  "source_of_funds": "Salary",
  "note": "",
  "idempotency_key": "uuid generated once per form"
}
```

Sending the same `idempotency_key` again returns the original request with status 200 instead of creating a second one. The app generates one key each time the form is opened, so a double tap or a timeout retry can never create two requests.

## 4. Errors

Every error has a readable `detail` the app shows as is:

```json
{"detail": "Requests above USD 1,000 need approved KYC. Submit your ID under Account, KYC."}
```

| Status | Meaning in the app |
|---|---|
| 400 | Rule broken (amount, band, state). Show `detail` |
| 401 | Token missing, expired or revoked. The app clears it and returns to sign in |
| 403 | Not verified yet, or a staff account (staff never trade through the customer app) |
| 404 | Not yours or does not exist |
| 429 | Too many attempts. `retry_after` seconds may be included |

## 5. Rate limits

| Scope | Limit |
|---|---|
| Sign in, register, password reset | 10 per minute per IP, plus the account lockout (5 failures) |
| Code verification and resend | 6 per minute |
| Any write (POST, PATCH, DELETE) | 30 per minute per user |
| Anonymous reads | 30 per minute |
| Signed in reads | 120 per minute |

Nginx adds a second layer (`deploy/nginx-desderia.conf`).

## 6. Push notifications (optional next step)

The app polls when screens are open and every status change is emailed. For phone push, add Firebase Cloud Messaging: store each device's FCM token on `ApiToken`, and send a push inside `notifications/services.py::notify` next to the email. No other code changes are needed because every event already flows through that one function.
