import hashlib
import secrets
from datetime import timedelta

from django.conf import settings
from django.utils import timezone
from rest_framework import exceptions
from rest_framework.authentication import BaseAuthentication, get_authorization_header

from accounts.models import ApiToken
from desderia.middleware import client_ip


def hash_key(key):
    return hashlib.sha256(key.encode()).hexdigest()


def issue_token(user, device_name="", request=None):
    key = secrets.token_urlsafe(40)
    token = ApiToken.objects.create(
        user=user, key_hash=hash_key(key), device_name=(device_name or "")[:80],
        expires_at=timezone.now() + timedelta(hours=settings.API_TOKEN_TTL_HOURS),
        ip_address=client_ip(request) or None,
    )
    return key, token


class ExpiringTokenAuthentication(BaseAuthentication):
    keyword = b"bearer"

    def authenticate(self, request):
        auth = get_authorization_header(request).split()
        if not auth or auth[0].lower() != self.keyword:
            return None
        if len(auth) != 2:
            raise exceptions.AuthenticationFailed("Invalid token header.")
        try:
            key = auth[1].decode()
        except UnicodeError:
            raise exceptions.AuthenticationFailed("Invalid token header.")
        token = ApiToken.objects.select_related("user").filter(key_hash=hash_key(key)).first()
        if token is None or not token.is_valid or not token.user.is_active:
            raise exceptions.AuthenticationFailed("Session expired. Please sign in again.")
        now = timezone.now()
        if token.last_used_at is None or (now - token.last_used_at).total_seconds() > 300:
            ApiToken.objects.filter(pk=token.pk).update(last_used_at=now)
        request.api_token = token
        return token.user, token

    def authenticate_header(self, request):
        return "Bearer"
