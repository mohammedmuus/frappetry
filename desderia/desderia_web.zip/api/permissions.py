from rest_framework.permissions import BasePermission


class IsVerifiedCustomer(BasePermission):
    message = "Verify your email and phone number first."

    def has_permission(self, request, view):
        user = request.user
        # Staff never trade through the customer channel (conflict of interest).
        return bool(user and user.is_authenticated and user.is_fully_verified and user.is_customer)
