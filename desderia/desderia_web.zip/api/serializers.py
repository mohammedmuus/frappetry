from django.conf import settings
from rest_framework import serializers

from accounts.models import KycProfile, User
from exchange.models import Beneficiary, ExchangeRequest, Offer, StatusEvent
from notifications.models import Notification
from support.models import Conversation


class UserSerializer(serializers.ModelSerializer):
    email_verified = serializers.SerializerMethodField()
    phone_verified = serializers.SerializerMethodField()
    kyc_status = serializers.SerializerMethodField()
    unread_notifications = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ["id", "email", "phone", "full_name", "role", "notify_email", "email_verified",
                  "phone_verified", "kyc_status", "unread_notifications", "date_joined"]
        read_only_fields = ["id", "email", "phone", "role", "date_joined"]

    def get_email_verified(self, obj):
        return obj.email_verified_at is not None

    def get_phone_verified(self, obj):
        return obj.phone_verified_at is not None

    def get_kyc_status(self, obj):
        kyc = getattr(obj, "kyc", None)
        return kyc.status if kyc else KycProfile.STATUS_NONE

    def get_unread_notifications(self, obj):
        return obj.notifications.filter(read_at__isnull=True).count()


class BeneficiarySerializer(serializers.ModelSerializer):
    display = serializers.CharField(source="__str__", read_only=True)

    class Meta:
        model = Beneficiary
        fields = ["id", "kind", "label", "currency", "account_name", "bank_name", "account_number",
                  "swift_code", "branch", "mobile_network", "display", "created_at"]
        read_only_fields = ["id", "created_at"]

    def validate(self, data):
        # Same rules as the web form, kept in one place.
        from exchange.forms import BeneficiaryForm
        form = BeneficiaryForm(data={**{k: (v.code if hasattr(v, "code") else v) for k, v in data.items()}},
                               customer=self.context["request"].user)
        if not form.is_valid():
            raise serializers.ValidationError({k: [str(e) for e in v] for k, v in form.errors.items()})
        cleaned = form.cleaned_data
        return {k: cleaned.get(k, v) for k, v in data.items()}


class OfferSerializer(serializers.ModelSerializer):
    class Meta:
        model = Offer
        fields = ["id", "side", "rate", "message", "status", "created_at", "responded_at"]


class EventSerializer(serializers.ModelSerializer):
    label = serializers.CharField(read_only=True)

    class Meta:
        model = StatusEvent
        fields = ["to_status", "label", "note", "at"]


class RequestListSerializer(serializers.ModelSerializer):
    status_label = serializers.CharField(source="get_status_display", read_only=True)
    direction_label = serializers.CharField(source="get_direction_display", read_only=True)
    effective_rate = serializers.DecimalField(max_digits=14, decimal_places=4, read_only=True)

    class Meta:
        model = ExchangeRequest
        fields = ["reference", "direction", "direction_label", "currency", "foreign_amount", "effective_rate",
                  "local_amount", "status", "status_label", "status_tone", "created_at"]


class RequestDetailSerializer(RequestListSerializer):
    offers = OfferSerializer(many=True, read_only=True)
    events = EventSerializer(many=True, read_only=True)
    beneficiary = BeneficiarySerializer(read_only=True)
    pay_amount = serializers.SerializerMethodField()
    receive_amount = serializers.SerializerMethodField()
    conversation_id = serializers.SerializerMethodField()
    payment = serializers.SerializerMethodField()
    bank_details = serializers.SerializerMethodField()
    can_negotiate = serializers.SerializerMethodField()

    class Meta(RequestListSerializer.Meta):
        fields = RequestListSerializer.Meta.fields + [
            "board_rate", "agreed_rate", "quote_expires_at", "fee_amount", "funding_method", "payout_method",
            "purpose", "source_of_funds", "customer_note", "funding_deadline", "funding_reference",
            "payout_reference", "closed_reason", "offers", "events", "beneficiary", "pay_amount",
            "receive_amount", "conversation_id", "payment", "bank_details", "can_negotiate"]

    def get_pay_amount(self, obj):
        amount, code = obj.customer_pays
        return {"amount": str(amount), "currency": code}

    def get_receive_amount(self, obj):
        amount, code = obj.customer_receives
        return {"amount": str(amount), "currency": code}

    def get_conversation_id(self, obj):
        conv = Conversation.objects.filter(request=obj).only("id").first()
        return str(conv.pk) if conv else None

    def get_payment(self, obj):
        p = obj.payments.filter(status__in=["pending", "paid"]).first() or obj.payments.order_by("-created_at").first()
        if not p:
            return None
        return {"reference": p.reference, "status": p.status, "gateway": p.gateway,
                "customer_reference": p.customer_reference, "payer_phone": p.payer_phone,
                "pushed_at": p.pushed_at, "provider": p.provider, "failure_reason": p.failure_reason}

    def get_bank_details(self, obj):
        if obj.funding_method != ExchangeRequest.FUND_BANK:
            return None
        return settings.BUREAU_BANK_DETAILS

    def get_can_negotiate(self, obj):
        return (obj.status in (ExchangeRequest.SUBMITTED, ExchangeRequest.NEGOTIATING)
                and obj.foreign_amount >= obj.currency.min_negotiable_amount)


class RequestCreateSerializer(serializers.Serializer):
    direction = serializers.ChoiceField(choices=ExchangeRequest.DIRECTION_CHOICES)
    currency = serializers.CharField(max_length=3)
    amount = serializers.DecimalField(max_digits=14, decimal_places=2, min_value=1)
    funding_method = serializers.ChoiceField(choices=ExchangeRequest.FUNDING_CHOICES)
    payout_method = serializers.ChoiceField(choices=ExchangeRequest.PAYOUT_CHOICES)
    beneficiary = serializers.UUIDField(required=False, allow_null=True)
    purpose = serializers.ChoiceField(choices=ExchangeRequest.PURPOSES)
    source_of_funds = serializers.CharField(max_length=160)
    note = serializers.CharField(max_length=500, required=False, allow_blank=True)
    idempotency_key = serializers.UUIDField()


class ConversationSerializer(serializers.ModelSerializer):
    unread = serializers.SerializerMethodField()
    reference = serializers.SerializerMethodField()

    class Meta:
        model = Conversation
        fields = ["id", "subject", "status", "last_message_at", "unread", "reference"]

    def get_unread(self, obj):
        return obj.unread_for(self.context["request"].user)

    def get_reference(self, obj):
        return obj.request.reference if obj.request_id else None


class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields = ["id", "event", "title", "body", "link", "read_at", "created_at"]


class KycSerializer(serializers.ModelSerializer):
    class Meta:
        model = KycProfile
        fields = ["legal_name", "id_type", "id_number", "nationality", "date_of_birth", "address", "occupation",
                  "id_document", "status", "review_note", "submitted_at"]
        read_only_fields = ["status", "review_note", "submitted_at"]
        extra_kwargs = {"id_document": {"write_only": True}}
