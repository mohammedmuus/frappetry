"""The exact call sequence the Flutter app makes, end to end."""

import io
import re
import uuid
from decimal import Decimal

from django.core import mail
from django.core.cache import cache
from django.test import TestCase, override_settings
from django.utils import timezone
from PIL import Image

from accounts.models import KycProfile, OneTimeCode, User
from rates.models import Currency, ExchangeRate


def code_for(user, purpose):
    """Read the code the way a customer would: from the last email or SMS log line."""
    for msg in reversed(mail.outbox):
        m = re.search(r"\b(\d{6})\b", msg.body)
        if m and msg.to == [user.email]:
            return m.group(1)
    return None


@override_settings(ALLOWED_HOSTS=["testserver"], SMS_BACKEND="api.tests.CaptureSms")
class MobileFlowTests(TestCase):
    def setUp(self):
        cache.clear()
        CaptureSms.sent.clear()
        boss = User.objects.create_user(email="m@x.test", phone="+255700000009", password="x", full_name="M", role="manager")
        Currency.objects.create(code="TZS", name="Tanzanian Shilling")
        usd = Currency.objects.create(code="USD", name="US Dollar")
        ExchangeRate.objects.create(currency=usd, buy_rate=Decimal("2575"), sell_rate=Decimal("2615"),
                                    effective_at=timezone.now(), set_by=boss)

    def call(self, method, path, data=None, token=None, **extra):
        kwargs = {"content_type": "application/json"} if method in ("post", "patch") and not extra.get("multipart") else {}
        extra.pop("multipart", None)
        if token:
            kwargs["HTTP_AUTHORIZATION"] = f"Bearer {token}"
        fn = getattr(self.client, method)
        return fn(f"/api/v1/{path}", data if data is not None else ({} if method != "get" else None), **kwargs, **extra)

    def test_full_mobile_journey(self):
        # Register
        r = self.call("post", "auth/register/", {"full_name": "Asha Mobile", "email": "asha@x.test", "phone": "0755111222",
                                                 "password": "Very-strong-pass-9", "accept_terms": True,
                                                 "device_name": "Android app"})
        self.assertEqual(r.status_code, 201, r.content)
        token = r.json()["token"]
        user = User.objects.get(email="asha@x.test")
        # Trading is blocked until verified
        self.assertEqual(self.call("get", "requests/", token=token).status_code, 403)
        # Verify email and phone
        r = self.call("post", "auth/verify/", {"which": "email", "code": code_for(user, "email")}, token=token)
        self.assertEqual(r.status_code, 200, r.content)
        sms_code = re.search(r"\b(\d{6})\b", CaptureSms.sent[-1]).group(1)
        r = self.call("post", "auth/verify/", {"which": "phone", "code": sms_code}, token=token)
        self.assertTrue(r.json()["user"]["phone_verified"])
        # Sign out, then the two step sign in
        self.call("post", "auth/logout/", token=token)
        self.assertEqual(self.call("get", "me/", token=token).status_code, 401)
        r = self.call("post", "auth/login/", {"email": "asha@x.test", "password": "Very-strong-pass-9"})
        challenge = r.json()["challenge"]
        r = self.call("post", "auth/login/verify/", {"challenge": challenge, "code": code_for(user, "login")})
        token = r.json()["token"]
        # Reference data and quote
        self.assertEqual(self.call("get", "options/", token=token).json()["base"], "TZS")
        q = self.call("get", "quote/", token=token, QUERY_STRING="currency=USD&direction=buy&amount=500").json()
        self.assertEqual(q["local_amount"], "1307500.00")
        # Create a request twice with one key: one row
        body = {"direction": "buy", "currency": "USD", "amount": "500", "funding_method": "bank_transfer",
                "payout_method": "cash_pickup", "purpose": "travel", "source_of_funds": "Salary",
                "idempotency_key": str(uuid.uuid4())}
        r1 = self.call("post", "requests/", body, token=token)
        r2 = self.call("post", "requests/", body, token=token)
        self.assertEqual((r1.status_code, r2.status_code), (201, 200))
        ref = r1.json()["reference"]
        self.assertEqual(r1.json()["reference"], r2.json()["reference"])
        # Chat on the request thread, resend is idempotent
        conv = r1.json()["conversation_id"]
        cid = str(uuid.uuid4())
        self.call("post", f"conversations/{conv}/messages/", {"body": "Hello desk", "client_id": cid}, token=token)
        self.call("post", f"conversations/{conv}/messages/", {"body": "Hello desk", "client_id": cid}, token=token)
        msgs = self.call("get", f"conversations/{conv}/messages/", token=token).json()["messages"]
        self.assertEqual(len([m for m in msgs if m["body"] == "Hello desk"]), 1)
        # Notifications exist for the submission
        self.assertTrue(self.call("get", "notifications/", token=token).json()["results"])
        # Cancel through the action endpoint
        r = self.call("post", f"requests/{ref}/cancel/", {"reason": "Changed plans"}, token=token)
        self.assertEqual(r.json()["status"], "cancelled")
        # KYC upload (multipart)
        buf = io.BytesIO()
        Image.new("RGB", (60, 40), (200, 200, 200)).save(buf, "PNG")
        buf.name = "id.png"
        buf.seek(0)
        r = self.client.post("/api/v1/kyc/", {"legal_name": "Asha Mobile", "id_type": "nida", "id_number": "123-456",
                                              "nationality": "Tanzanian", "date_of_birth": "1990-05-01",
                                              "address": "Arusha", "occupation": "Teacher", "id_document": buf},
                             HTTP_AUTHORIZATION=f"Bearer {token}")
        self.assertEqual(r.status_code, 201, r.content)
        self.assertEqual(KycProfile.objects.get(user=user).status, "pending")

    def test_staff_cannot_trade_through_the_app(self):
        teller = User.objects.create_user(email="t@x.test", phone="+255700000010", password="Very-strong-pass-9",
                                          full_name="T", role="teller", email_verified_at=timezone.now(),
                                          phone_verified_at=timezone.now())
        from api.authentication import issue_token
        key, _ = issue_token(teller)
        self.assertEqual(self.call("get", "requests/", token=key).status_code, 403)

    def test_expired_token_is_refused(self):
        u = User.objects.create_user(email="e@x.test", phone="+255700000011", password="p", full_name="E")
        from api.authentication import issue_token
        key, tok = issue_token(u)
        type(tok).objects.filter(pk=tok.pk).update(expires_at=timezone.now())
        self.assertEqual(self.call("get", "me/", token=key).status_code, 401)


class CaptureSms:
    sent = []

    def send(self, phone, text):
        CaptureSms.sent.append(text)
        return True
