"""
REST API for the Desderia mobile app. Every money action calls the same
service layer the web uses, so rules, locks, audit and notifications are
identical on both channels.
"""

import time
import uuid
from decimal import Decimal

from django.conf import settings
from django.contrib.auth import authenticate
from django.contrib.auth.forms import PasswordResetForm
from django.core import signing
from django.core.exceptions import ValidationError as DjangoValidationError
from django.db import IntegrityError, transaction
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.utils.dateparse import parse_datetime
from rest_framework.decorators import api_view, permission_classes, throttle_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import exception_handler as drf_exception_handler

from accounts import otp
from accounts.forms import KycForm, RegisterForm
from accounts.models import KycProfile, OneTimeCode, User
from audit.services import record
from exchange import services
from exchange.models import Beneficiary, ExchangeRequest
from payments.services import customer_claims_paid, start_payment
from rates.models import Currency
from rates.views import board
from support.models import Conversation
from support.services import ChatError, can_access, conversation_for_request, mark_read, post_message, serialise

from .authentication import issue_token
from .permissions import IsVerifiedCustomer
from .serializers import (BeneficiarySerializer, ConversationSerializer, KycSerializer, NotificationSerializer,
                          RequestCreateSerializer, RequestDetailSerializer, RequestListSerializer, UserSerializer)
from .throttles import AuthThrottle, OtpThrottle, WriteThrottle

CHALLENGE_SALT = "desderia.api.2fa"


def exception_handler(exc, context):
    response = drf_exception_handler(exc, context)
    if response is None and isinstance(exc, services.ExchangeError):
        return Response({"detail": str(exc)}, status=400)
    if response is None and isinstance(exc, DjangoValidationError):
        return Response({"detail": " ".join(exc.messages)}, status=400)
    return response


def _err(message, code=400):
    return Response({"detail": message}, status=code)


def _form_errors(form):
    errors = {k: [str(e) for e in v] for k, v in form.errors.items()}
    first = next(iter(errors.values()), ["Check the form."])[0]
    return Response({"detail": first, "errors": errors}, status=400)


# ─────────────────────────────────────────────────────────────
# AUTH
# ─────────────────────────────────────────────────────────────

@api_view(["POST"])
@permission_classes([AllowAny])
@throttle_classes([AuthThrottle])
def register(request):
    data = request.data
    # The app has no bot trap fields; throttling and verification gate it.
    form = RegisterForm(data={
        "full_name": data.get("full_name", ""), "email": data.get("email", ""), "phone": data.get("phone", ""),
        "password1": data.get("password", ""), "password2": data.get("password", ""),
        "accept_terms": data.get("accept_terms", False),
        "started": signing.dumps(int(time.time()) - 60, salt="form-start"),
    })
    if not form.is_valid():
        return _form_errors(form)
    try:
        with transaction.atomic():
            user = form.save()
            record("account.registered", user, f"New customer {user.email} (app)", actor=user, channel="api")
    except IntegrityError:
        return _err("This email or phone number is already registered.")
    for purpose, channel in ((OneTimeCode.PURPOSE_EMAIL, "email"), (OneTimeCode.PURPOSE_PHONE, "sms")):
        try:
            otp.issue(user, purpose, channel=channel, request=request)
        except otp.OtpError:
            pass
    key, _ = issue_token(user, data.get("device_name", ""), request)
    return Response({"token": key, "user": UserSerializer(user).data}, status=201)



@api_view(["POST"])
@permission_classes([AllowAny])
@throttle_classes([AuthThrottle])
def login(request):
    email = str(request.data.get("email", "")).strip().lower()[:254]
    password = str(request.data.get("password", ""))[:128]
    user = authenticate(request._request, username=email, password=password)
    if user is None:
        return _err("Email or password is not correct.", 401)
    if not user.email_verified_at:
        key, _ = issue_token(user, request.data.get("device_name", ""), request)
        return Response({"token": key, "verification_required": True, "user": UserSerializer(user).data})
    channel = "sms" if request.data.get("channel") == "sms" and user.phone_verified_at else "email"
    try:
        otp.issue(user, OneTimeCode.PURPOSE_LOGIN, channel=channel, request=request)
    except otp.OtpError:
        pass
    challenge = signing.dumps({"uid": str(user.pk), "n": uuid.uuid4().hex, "ch": channel}, salt=CHALLENGE_SALT)
    return Response({"otp_required": True, "challenge": challenge, "channel": channel})



def _challenge_user(challenge):
    try:
        data = signing.loads(challenge or "", salt=CHALLENGE_SALT, max_age=600)
    except signing.BadSignature:
        return None, None
    return User.objects.filter(pk=data.get("uid"), is_active=True).first(), data.get("ch", "email")


@api_view(["POST"])
@permission_classes([AllowAny])
@throttle_classes([OtpThrottle])
def login_verify(request):
    user, _ = _challenge_user(request.data.get("challenge"))
    if user is None:
        return _err("Your sign in expired. Please start again.", 401)
    try:
        otp.verify(user, OneTimeCode.PURPOSE_LOGIN, str(request.data.get("code", "")), request=request)
    except otp.OtpError as exc:
        return _err(str(exc))
    key, _ = issue_token(user, request.data.get("device_name", ""), request)
    User.objects.filter(pk=user.pk).update(last_login=timezone.now())
    record("auth.login", user, f"{user.email} signed in (app)", actor=user, channel="api")
    return Response({"token": key, "user": UserSerializer(user).data})


@api_view(["POST"])
@permission_classes([AllowAny])
@throttle_classes([OtpThrottle])
def login_resend(request):
    user, channel = _challenge_user(request.data.get("challenge"))
    if user is None:
        return _err("Your sign in expired. Please start again.", 401)
    try:
        otp.issue(user, OneTimeCode.PURPOSE_LOGIN, channel=channel, request=request)
    except otp.OtpError as exc:
        return _err(str(exc), 429)
    return Response({"detail": "A new code was sent."})


@api_view(["POST"])
def logout(request):
    token = getattr(request, "api_token", None)
    if token is not None:
        type(token).objects.filter(pk=token.pk).update(revoked_at=timezone.now())
    record("auth.logout", request.user, f"{request.user.email} signed out (app)")
    return Response({"detail": "Signed out."})


@api_view(["POST"])
@permission_classes([AllowAny])
@throttle_classes([AuthThrottle])
def password_reset(request):
    form = PasswordResetForm(data={"email": request.data.get("email", "")})
    if form.is_valid():
        form.save(request=request._request, use_https=not settings.DEBUG,
                  email_template_name="password_reset_email.txt",
                  subject_template_name="password_reset_subject.txt")
    # Same answer whether or not the email exists: no account enumeration.
    return Response({"detail": "If that email has an account, a reset link is on its way."})



@api_view(["POST"])
@throttle_classes([OtpThrottle])
def verify(request):
    which = request.data.get("which")
    if which not in ("email", "phone"):
        return _err("Choose email or phone.")
    purpose = OneTimeCode.PURPOSE_EMAIL if which == "email" else OneTimeCode.PURPOSE_PHONE
    user = request.user
    if request.data.get("resend"):
        try:
            otp.issue(user, purpose, channel="email" if which == "email" else "sms", request=request)
        except otp.OtpError as exc:
            return _err(str(exc), 429)
        return Response({"detail": "A new code was sent."})
    try:
        otp.verify(user, purpose, str(request.data.get("code", "")), request=request)
    except otp.OtpError as exc:
        return _err(str(exc))
    field = "email_verified_at" if which == "email" else "phone_verified_at"
    User.objects.filter(pk=user.pk, **{f"{field}__isnull": True}).update(**{field: timezone.now()})
    record(f"account.{which}_verified", user, f"{which.title()} verified for {user.email} (app)")
    user.refresh_from_db()
    return Response({"user": UserSerializer(user).data})


@api_view(["GET", "PATCH"])
def me(request):
    user = request.user
    if request.method == "PATCH":
        ser = UserSerializer(user, data=request.data, partial=True)
        ser.is_valid(raise_exception=True)
        ser.save()
        record("account.profile_updated", user, "Profile updated (app)")
    return Response(UserSerializer(user).data)


# ─────────────────────────────────────────────────────────────
# REFERENCE DATA, RATES AND QUOTES
# ─────────────────────────────────────────────────────────────

@api_view(["GET"])
@permission_classes([AllowAny])
def rates(request):
    rows = board()
    return Response({"base": settings.BASE_CURRENCY, "rates": [
        {**r, "buy": str(r["buy"]), "sell": str(r["sell"]), "updated": r["updated"].isoformat(),
         "min_negotiable": str(r["min_negotiable"])} for r in rows]})


@api_view(["GET"])
def options(request):
    return Response({
        "currencies": [{"code": c.code, "name": c.name, "min": str(c.min_amount), "max": str(c.max_amount),
                        "min_negotiable": str(c.min_negotiable_amount)}
                       for c in Currency.objects.filter(is_active=True)],
        "base": settings.BASE_CURRENCY,
        "directions": ExchangeRequest.DIRECTION_CHOICES,
        "funding": {d: sorted(v) for d, v in services.ALLOWED_FUNDING.items()},
        "payout": {d: sorted(v) for d, v in services.ALLOWED_PAYOUT.items()},
        "funding_labels": dict(ExchangeRequest.FUNDING_CHOICES),
        "payout_labels": dict(ExchangeRequest.PAYOUT_CHOICES),
        "purposes": ExchangeRequest.PURPOSES,
        "networks": Beneficiary.NETWORKS,
        "id_types": KycProfile.ID_TYPES,
        "kyc_limit_usd": settings.KYC_UNVERIFIED_LIMIT_USD,
        "quote_lock_minutes": settings.QUOTE_LOCK_MINUTES,
    })


@api_view(["GET"])
def quote(request):
    currency = get_object_or_404(Currency, code=request.query_params.get("currency", ""), is_active=True)
    direction = request.query_params.get("direction", "buy")
    if direction not in ("buy", "sell"):
        return _err("Unknown direction.")
    try:
        amount = Decimal(request.query_params.get("amount", "0"))
    except ArithmeticError:
        return _err("Enter a valid amount.")
    if amount <= 0 or amount > 10_000_000:
        return _err("Enter a valid amount.")
    q = services.quote(currency, direction, amount)
    return Response({k: (str(v) if not isinstance(v, bool) else v) for k, v in q.items()})


# ─────────────────────────────────────────────────────────────
# EXCHANGE REQUESTS
# ─────────────────────────────────────────────────────────────

def _own(request, reference):
    return get_object_or_404(ExchangeRequest.objects.select_related("currency", "beneficiary"),
                             reference=reference, customer=request.user)


@api_view(["GET", "POST"])
@permission_classes([IsVerifiedCustomer])
@throttle_classes([WriteThrottle])
def requests_view(request):
    if request.method == "GET":
        qs = ExchangeRequest.objects.filter(customer=request.user).select_related("currency")
        if request.query_params.get("status") == "open":
            qs = qs.filter(status__in=ExchangeRequest.OPEN_STATUSES)
        page = qs[:50]
        return Response({"results": RequestListSerializer(page, many=True).data})
    ser = RequestCreateSerializer(data=request.data)
    ser.is_valid(raise_exception=True)
    d = ser.validated_data
    beneficiary = None
    if d.get("beneficiary"):
        beneficiary = Beneficiary.objects.filter(pk=d["beneficiary"], customer=request.user, is_active=True).first()
        if beneficiary is None:
            return _err("Choose one of your saved beneficiaries.")
    req, created = services.create_request(
        request.user, direction=d["direction"], currency_code=d["currency"].upper(), amount=d["amount"],
        funding_method=d["funding_method"], payout_method=d["payout_method"], beneficiary=beneficiary,
        purpose=d["purpose"], source_of_funds=d["source_of_funds"], note=d.get("note", ""),
        idempotency_key=d["idempotency_key"], source="mobile")
    return Response(RequestDetailSerializer(req).data, status=201 if created else 200)


@api_view(["GET"])
@permission_classes([IsVerifiedCustomer])
def request_detail(request, reference):
    req = _own(request, reference)
    return Response(RequestDetailSerializer(req).data)


@api_view(["POST"])
@permission_classes([IsVerifiedCustomer])
@throttle_classes([WriteThrottle])
def request_action(request, reference, action):
    req = _own(request, reference)
    data = request.data
    if action == "offer":
        try:
                rate = Decimal(str(data.get("rate", "")))
        except ArithmeticError:
            return _err("Enter a valid rate.")
        services.make_offer(req, request.user, rate, str(data.get("message", ""))[:300])
    elif action == "respond":
        try:
            offer_id = uuid.UUID(str(data.get("offer_id", "")))
        except ValueError:
            return _err("Unknown offer.")
        services.respond_offer(req, offer_id, request.user, bool(data.get("accept")))
    elif action == "cancel":
        services.cancel(req, request.user, str(data.get("reason", ""))[:200])
    elif action == "pay":
        start_payment(req, request.user, phone=str(data.get("phone", ""))[:20])
    elif action == "paid":
        customer_claims_paid(req, request.user, str(data.get("reference", "")))
    elif action == "received":
        services.complete(req, request.user)
    else:
        return _err("Unknown action.", 404)
    req.refresh_from_db()
    return Response(RequestDetailSerializer(req).data)


# ─────────────────────────────────────────────────────────────
# BENEFICIARIES
# ─────────────────────────────────────────────────────────────

@api_view(["GET", "POST"])
@throttle_classes([WriteThrottle])
def beneficiaries(request):
    if request.method == "GET":
        qs = Beneficiary.objects.filter(customer=request.user, is_active=True)
        return Response({"results": BeneficiarySerializer(qs, many=True).data})
    ser = BeneficiarySerializer(data=request.data, context={"request": request})
    ser.is_valid(raise_exception=True)
    try:
        with transaction.atomic():
            ben = ser.save(customer=request.user)
            record("beneficiary.created", ben, f"Beneficiary {ben.label} added (app)",
                   data={"kind": ben.kind, "currency": ben.currency_id, "last4": ben.account_number[-4:]})
    except IntegrityError:
        return _err("You already saved this account.")
    return Response(BeneficiarySerializer(ben).data, status=201)


@api_view(["DELETE"])
def beneficiary_delete(request, pk):
    ben = get_object_or_404(Beneficiary, pk=pk, customer=request.user, is_active=True)
    Beneficiary.objects.filter(pk=ben.pk).update(is_active=False)
    record("beneficiary.removed", ben, f"Beneficiary {ben.label} removed (app)")
    return Response(status=204)


# ─────────────────────────────────────────────────────────────
# CHAT
# ─────────────────────────────────────────────────────────────

@api_view(["GET", "POST"])
@throttle_classes([WriteThrottle])
def conversations(request):
    if request.method == "GET":
        qs = Conversation.objects.filter(customer=request.user).select_related("request")[:50]
        return Response({"results": ConversationSerializer(qs, many=True, context={"request": request}).data})
    subject = str(request.data.get("subject", "")).strip()[:120]
    body = str(request.data.get("body", "")).strip()
    if not subject or not body:
        return _err("Add a subject and a message.")
    conv = Conversation.objects.create(customer=request.user, subject=subject)
    record("chat.opened", conv, f"Support conversation opened: {subject} (app)")
    try:
        post_message(conv, request.user, body)
    except ChatError as exc:
        return _err(str(exc))
    return Response(ConversationSerializer(conv, context={"request": request}).data, status=201)


@api_view(["GET", "POST"])
@throttle_classes([WriteThrottle])
def conversation_messages(request, pk):
    conv = get_object_or_404(Conversation, pk=pk)
    if not can_access(request.user, conv):
        return _err("Not found.", 404)
    if request.method == "POST":
        try:
            client_id = uuid.UUID(str(request.data.get("client_id", "")))
        except ValueError:
            client_id = None
        try:
            msg, _ = post_message(conv, request.user, str(request.data.get("body", "")), client_id=client_id)
        except ChatError as exc:
            return _err(str(exc))
        return Response(serialise(msg, request.user), status=201)
    qs = conv.messages.select_related("sender")
    after = parse_datetime(request.query_params.get("after", "") or "")
    if after:
        qs = qs.filter(created_at__gt=after)
    msgs = list(qs.order_by("-created_at")[:80])[::-1]
    mark_read(conv, request.user)
    return Response({"subject": conv.subject, "status": conv.status,
                     "messages": [serialise(m, request.user) for m in msgs]})


@api_view(["GET"])
@permission_classes([IsVerifiedCustomer])
def request_conversation(request, reference):
    req = _own(request, reference)
    conv = conversation_for_request(req)
    return Response({"id": str(conv.pk)})


# ─────────────────────────────────────────────────────────────
# NOTIFICATIONS AND KYC
# ─────────────────────────────────────────────────────────────

@api_view(["GET", "POST"])
def notifications(request):
    if request.method == "POST":
        request.user.notifications.filter(read_at__isnull=True).update(read_at=timezone.now())
    qs = request.user.notifications.all()[:60]
    return Response({"results": NotificationSerializer(qs, many=True).data})


@api_view(["GET", "POST"])
@throttle_classes([WriteThrottle])
def kyc(request):
    instance = KycProfile.objects.filter(user=request.user).first()
    if request.method == "GET":
        if instance is None:
            return Response({"status": KycProfile.STATUS_NONE})
        return Response(KycSerializer(instance).data)
    if instance and instance.status == KycProfile.STATUS_APPROVED:
        return _err("Your KYC is already approved.")
    form = KycForm(request.data, request.FILES, instance=instance)
    if not form.is_valid():
        return _form_errors(form)
    try:
        with transaction.atomic():
            obj = form.save(commit=False)
            obj.user = request.user
            obj.status = KycProfile.STATUS_PENDING
            obj.reviewed_by = None
            obj.reviewed_at = None
            obj.save()
            record("kyc.submitted", obj, f"KYC submitted by {request.user.email} (app)")
    except IntegrityError:
        return _err("This ID document is already linked to another account.")
    from notifications.services import notify_staff
    notify_staff("kyc_submitted", {"customer": request.user})
    return Response(KycSerializer(obj).data, status=201)


@api_view(["GET"])
@permission_classes([AllowAny])
def health(request):
    return Response({"ok": True, "time": timezone.now().isoformat()})

