from django.urls import path

from . import views

app_name = "api"

urlpatterns = [
    path("health/", views.health, name="health"),
    path("auth/register/", views.register, name="register"),
    path("auth/login/", views.login, name="login"),
    path("auth/login/verify/", views.login_verify, name="login_verify"),
    path("auth/login/resend/", views.login_resend, name="login_resend"),
    path("auth/logout/", views.logout, name="logout"),
    path("auth/password-reset/", views.password_reset, name="password_reset"),
    path("auth/verify/", views.verify, name="verify"),
    path("me/", views.me, name="me"),
    path("rates/", views.rates, name="rates"),
    path("options/", views.options, name="options"),
    path("quote/", views.quote, name="quote"),
    path("requests/", views.requests_view, name="requests"),
    path("requests/<str:reference>/", views.request_detail, name="request_detail"),
    path("requests/<str:reference>/conversation/", views.request_conversation, name="request_conversation"),
    path("requests/<str:reference>/<slug:action>/", views.request_action, name="request_action"),
    path("beneficiaries/", views.beneficiaries, name="beneficiaries"),
    path("beneficiaries/<uuid:pk>/", views.beneficiary_delete, name="beneficiary_delete"),
    path("conversations/", views.conversations, name="conversations"),
    path("conversations/<uuid:pk>/messages/", views.conversation_messages, name="conversation_messages"),
    path("notifications/", views.notifications, name="notifications"),
    path("kyc/", views.kyc, name="kyc"),
]
