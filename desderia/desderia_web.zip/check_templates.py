"""Guards that manage.py check cannot see. Run before every deploy; exit 1 on any hit.

1. multi line {# #} comments (they render as visible text)
2. inline event handlers (blocked by the strict CSP)
3. inline style attributes (blocked by the strict CSP)
4. emojis, em dashes and en dashes anywhere in source (house style)
"""

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SKIP = {"staticfiles", "node_modules", ".git", "logs", "private_media", "__pycache__"}
MULTILINE = re.compile(r"\{#\s(?:(?!#\}).)*?\n(?:(?!#\}).)*?#\}", re.S)
HANDLER = re.compile(r"\son(click|change|submit|load|error|input|keyup|keydown|focus|blur)\s*=", re.I)
STYLE_ATTR = re.compile(r"<[a-z][^>]*\sstyle\s*=", re.I)
BANNED = re.compile("[–—\U0001F300-\U0001FAFF☀-➿]")


def files(patterns):
    for pattern in patterns:
        for path in ROOT.rglob(pattern):
            if not SKIP.intersection(path.parts):
                yield path


def main():
    problems = []
    for path in files(["*.html"]):
        text = path.read_text(encoding="utf-8")
        rel = path.relative_to(ROOT)
        if MULTILINE.search(text):
            problems.append(f"{rel}: multi line {{# #}} comment")
        if HANDLER.search(text):
            problems.append(f"{rel}: inline event handler")
        if "templates/email/" not in str(rel).replace("\\", "/") and STYLE_ATTR.search(text):
            problems.append(f"{rel}: inline style attribute")
    for path in files(["*.html", "*.py", "*.css", "*.js", "*.txt", "*.md"]):
        if path.name == "check_templates.py":
            continue
        for n, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if BANNED.search(line):
                problems.append(f"{path.relative_to(ROOT)}:{n}: emoji or long dash")
    for p in problems:
        print(p)
    print("Template guard: " + ("FAILED" if problems else "clean"))
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
