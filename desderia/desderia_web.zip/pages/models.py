from django.db import models
from django.db.models import Q


class ContactMessage(models.Model):
    """Public contact desk. Every message gets an automatic acknowledgement."""

    TOPICS = [
        ("rates", "Rates and quotes"),
        ("account", "My account"),
        ("transfer", "A transfer or request"),
        ("business", "Corporate and bulk exchange"),
        ("other", "Something else"),
    ]
    STATUS = [("new", "New"), ("answered", "Answered"), ("spam", "Spam")]

    name = models.CharField(max_length=120)
    email = models.EmailField()
    phone = models.CharField(max_length=20, blank=True)
    topic = models.CharField(max_length=10, choices=TOPICS, default="rates")
    message = models.TextField(max_length=2000)
    status = models.CharField(max_length=10, choices=STATUS, default="new")
    ticket = models.CharField(max_length=12, unique=True)
    ip_address = models.CharField(max_length=45, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        constraints = [models.CheckConstraint(condition=Q(status__in=["new", "answered", "spam"]),
                                              name="contact_status_valid")]

    def __str__(self):
        return f"{self.ticket} {self.name}"
