import secrets

from django.contrib import messages
from django.db import IntegrityError, transaction
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.views.decorators.cache import cache_control

from desderia.guards import rate_limit
from desderia.middleware import client_ip
from notifications.services import notify_staff, send_contact_ack
from rates.views import board

from .forms import ContactForm


def home(request):
    return render(request, "home.html", {"rows": board()})


@rate_limit("contact", limit=3, window=900)
def contact(request):
    form = ContactForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        for _ in range(3):
            try:
                with transaction.atomic():
                    msg = form.save(commit=False)
                    msg.ticket = "CT-" + secrets.token_hex(4).upper()
                    msg.ip_address = client_ip(request)
                    msg.save()
                    # Store first, then notify: a mail failure never loses a message.
                    send_contact_ack(msg)
                    notify_staff("contact", {"name": msg.name, "topic": msg.get_topic_display(),
                                             "ticket": msg.ticket})
                break
            except IntegrityError:
                continue
        messages.success(request, "Thank you. We emailed you a confirmation with your ticket number.")
        return redirect("pages:contact")
    return render(request, "contact.html", {"form": form})


def about(request):
    return render(request, "about.html")


def terms(request):
    return render(request, "terms.html")


def privacy(request):
    return render(request, "privacy.html")


@cache_control(public=True, max_age=86400)
def robots(request):
    body = ("User-agent: *\nDisallow: /exchange/\nDisallow: /desk/\nDisallow: /audit/\nDisallow: /account/\n"
            "Disallow: /auth/\nDisallow: /admin/\nDisallow: /api/\n")
    return HttpResponse(body, content_type="text/plain")


@cache_control(public=True, max_age=86400)
def manifest(request):
    import json
    from django.templatetags.static import static
    data = {
        "name": "Desderia Bureau De Change", "short_name": "Desderia", "start_url": "/exchange/",
        "display": "standalone", "background_color": "#0c1014", "theme_color": "#0c1014",
        "icons": [{"src": static("img/icon-192.png"), "sizes": "192x192", "type": "image/png"},
                  {"src": static("img/icon-512.png"), "sizes": "512x512", "type": "image/png"}],
    }
    return HttpResponse(json.dumps(data), content_type="application/manifest+json")
