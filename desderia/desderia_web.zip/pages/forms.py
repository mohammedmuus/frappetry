from django import forms

from accounts.forms import BotTrapMixin, style

from .models import ContactMessage


class ContactForm(BotTrapMixin, forms.ModelForm):
    class Meta:
        model = ContactMessage
        # status and ticket are never accepted from the visitor.
        fields = ["name", "email", "phone", "topic", "message"]
        widgets = {"message": forms.Textarea(attrs={"rows": 4})}
        labels = {"phone": "Phone (optional)"}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        style(self)

    def clean_name(self):
        name = self.cleaned_data["name"]
        if any(c in name for c in "\r\n<>"):
            raise forms.ValidationError("Enter a plain name.")
        return name.strip()

    def clean_message(self):
        msg = self.cleaned_data["message"].strip()
        if msg.lower().count("http") > 2:
            raise forms.ValidationError("Please remove the links from your message.")
        return msg
