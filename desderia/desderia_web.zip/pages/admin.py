from django.contrib import admin

from desderia.admin_mixins import NoDeleteAdmin

from .models import ContactMessage


@admin.register(ContactMessage)
class ContactMessageAdmin(NoDeleteAdmin, admin.ModelAdmin):
    list_display = ["ticket", "name", "email", "phone", "topic", "status", "created_at"]
    list_filter = ["status", "topic"]
    search_fields = ["ticket", "name", "email", "message"]
    readonly_fields = ["name", "email", "phone", "topic", "message", "ticket", "ip_address", "created_at"]
    date_hierarchy = "created_at"
    actions = ["mark_answered", "mark_spam"]

    def has_add_permission(self, request):
        return False

    @admin.action(description="Mark as answered")
    def mark_answered(self, request, queryset):
        queryset.update(status="answered")

    @admin.action(description="Mark as spam")
    def mark_spam(self, request, queryset):
        queryset.update(status="spam")
